# v1.12 — Mission Alarm Veykano

- 139 language choices preserved; English remains the base UI language.
- English text dictionary expanded from 488 to 659 keys, and more direct Java UI texts routed through localized lookup.
- Yoga, sit-up, calorie and snooze options now localized via `localize`.
- Selected-language day-of-week and sleep-chart label fixes.
- Added automatic completeness audits; other 138 locale choices are NOT fully translated. Incomplete locales use English fallback.
- No features removed, no package ID change, no new APK.
