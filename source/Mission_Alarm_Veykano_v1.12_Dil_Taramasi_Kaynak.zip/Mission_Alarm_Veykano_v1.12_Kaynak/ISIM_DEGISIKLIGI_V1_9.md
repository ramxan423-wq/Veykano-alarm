# Mission Alarm Veykano — 1.9

Android görünen ad, ana sayfa, profil Hakkında, uyku bildirimi, tema ön izlemesi ve Google Play için uygulama adı yenilendi.
`applicationId=com.wakemission.alarm` ve Java paketleri güncelleme/kurulum uyumluluğu için değiştirilmedi.
Önceki görevler, özellikler ve Ayarlar temizliği korundu.
Bu bir Android Studio kaynak kodu ZIP dosyasıdır. APK/AAB oluşturulmadı veya gerçek telefonda test edilmedi.
