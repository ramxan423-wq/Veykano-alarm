# WakeMission v1.5 kaynak değişiklikleri

- Bağımsız **Yatak Toplama** görevi: alarm düzenleme, görev listesi, fotoğrafla örnek yatak görüntüsü eşleştirmesi.
- Yatak referansı yalnızca cihazda saklanan görüntü özellikleridir; hiçbir fotoğraf sunucuya yüklenmez. Benzerlik gerçek yatağın toplandığını kesin olarak kanıtlamaz.
- Uyku kaydı durunca yeni **Gece Ses Zaman Çizelgesi**: olayların gerçek saatleri, horlama/öksürük/kabus/diğer ses satırları ve işarete dokunarak ses dinleme.
- Kısa, ses eşiğine göre tutulan WAV dosyaları cihaz içindedir; otomatik horlama/öksürük sınıfları yalnızca **olası** sinyal şekli tahminleridir, tıbbi veya kesin doğrulama değildir. Kullanıcı etiketleri manuel düzeltebilir.
- Kabus ses kaydından otomatik tespit edilmez. Kullanıcı kabusu not edip olay saatini elle seçebilir ve ilgili ses olayını elle kabusla ilişkilendirebilir.
- Var olan uyku günlüğü, görevler, menüler, renk paleti ve simgeler korunur.
- APK/AAB derlenmedi. Android gerçek cihaz ve kamera/mikrofon testleri gereklidir.
