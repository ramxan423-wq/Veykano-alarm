package com.wakemission.alarm;

/** Rough calorie estimate from repetition count, assumed tempo and MET, not a measurement. */
public final class CalorieEstimate {
    private CalorieEstimate(){}
    public static final String SITUP="SITUP",SQUAT="SQUAT",PUSHUP="PUSHUP";
    public static String safeActivity(String activity){
        return SQUAT.equals(activity)||PUSHUP.equals(activity)?activity:SITUP;
    }
    public static int safeWeight(int value){return value>=30&&value<=250?value:70;}
    public static int safeGoal(int value){return value==1||value==3?value:2;}
    public static double estimate(int completedRepetitions,int weightKg,String activity){
        // kcal/min ≈ MET * 3.5 * kg / 200; assumed 3.5–4.0 seconds/rep.
        if(completedRepetitions<=0)return 0;
        int kg=safeWeight(weightKg);
        String kind=safeActivity(activity);
        double met=SQUAT.equals(kind)?5.0:PUSHUP.equals(kind)?7.0:3.8;
        double secondsPerRep=SQUAT.equals(kind)?3.5:4.0;
        return Math.max(0,completedRepetitions*met*3.5*kg*secondsPerRep/12000.0);
    }
}
