package com.wakemission.alarm;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.MediaPlayer;
import java.io.File;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.*;

public final class MainActivity extends Activity {
    private LinearLayout screen;
    private String section="home";
    private MediaPlayer sleepPlayer;
    private static final int SLEEP_MIC_PERMISSION=731;
    private String bedtime="23:00", wakeTime="07:00";
    private int introStep=0;
    private int promoStep=0;
    private boolean languageDialogActive=false;
    private String introGoal="Ertelemeyi bırakmak", introMission=AlarmItem.PUSHUP;

    @Override public void onCreate(Bundle state){super.onCreate(state);AppTheme.apply(this);
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},100);
        AlarmScheduler.scheduleAll(this);
        if(needsIntroFlow()){
            showFirstRunFlow();return;
        }
        render();
    }
    @Override protected void onDestroy(){
        if(sleepPlayer!=null){sleepPlayer.release();sleepPlayer=null;}
        super.onDestroy();
    }
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==SLEEP_MIC_PERMISSION){
            if(grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED)startSleepRecording();
            else Toast.makeText(this,I18n.tr(this,"Mikrofon izni olmadan uyku ses kaydı yapılamaz."),Toast.LENGTH_LONG).show();
            section="sleep";render();
        }
    }
    @Override protected void onResume(){super.onResume();AppTheme.apply(this);
        if(needsIntroFlow())showFirstRunFlow();
        else render();
    }
    private boolean needsIntroFlow(){
        android.content.SharedPreferences pref=getSharedPreferences("onboarding",MODE_PRIVATE);
        return !pref.getBoolean("language_chosen",false)||!pref.getBoolean("promo_seen",false)||!pref.getBoolean("done",false);
    }
    /** First-run: language picker, three feature previews, then preserve existing alarm setup. */
    private void showFirstRunFlow(){
        android.content.SharedPreferences pref=getSharedPreferences("onboarding",MODE_PRIVATE);
        if(!pref.getBoolean("language_chosen",false)){
            if(!languageDialogActive){
                languageDialogActive=true;
                showPromo();
                showLanguagePicker(true);
            }
            return;
        }
        if(!pref.getBoolean("promo_seen",false)){
            promoStep=Math.min(2,Math.max(0,pref.getInt("promo_step",0)));
            showPromo();return;
        }
        if(pref.getBoolean("done",false))render();else showWelcome();
    }
    private void showPromo(){
        AppTheme.apply(this);
        ScrollView scroll=new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Ui.BG);
        LinearLayout root=Ui.column(this);
        root.setPadding(Ui.dp(this,23),Ui.dp(this,26),Ui.dp(this,23),Ui.dp(this,26));
        scroll.addView(root);
        LinearLayout top=Ui.row(this);
        top.addView(Ui.text(this,"Mission Alarm Veykano",19,Ui.WHITE,true),new LinearLayout.LayoutParams(0,-2,1));
        TextView lang=Ui.text(this,"🌐  "+LanguageCatalog.label(I18n.selected(this)),13,Ui.PEACH,true);
        lang.setPadding(Ui.dp(this,6),Ui.dp(this,10),Ui.dp(this,6),Ui.dp(this,10));
        lang.setOnClickListener(v->showLanguagePicker(false));top.addView(lang);root.addView(top);
        Ui.space(root,25);
        LinearLayout dots=Ui.row(this);dots.setGravity(Gravity.CENTER);
        for(int i=0;i<3;i++){
            View dot=new View(this);dot.setBackground(Ui.shape(i==promoStep?Ui.PEACH:Ui.OUTLINE,7,this));
            LinearLayout.LayoutParams dp=new LinearLayout.LayoutParams(Ui.dp(this,i==promoStep?45:20),Ui.dp(this,6));
            dp.setMargins(Ui.dp(this,4),0,Ui.dp(this,4),0);dots.addView(dot,dp);
        }
        root.addView(dots);Ui.space(root,24);
        PromoIllustrationView art=new PromoIllustrationView(this,promoStep);
        root.addView(art,new LinearLayout.LayoutParams(-1,Ui.dp(this,274)));
        Ui.space(root,25);
        String[] titles={"Wake up with camera missions", "Move, stretch and feel stronger", "Understand your sleep"};
        String[] desc={
            "Finish your alarm with camera-verified push-ups and photo missions. Your morning starts with action.",
            "Choose yoga, sit-ups, squats or calorie goals. Each mission is designed for an active start.",
            "Review sleep recordings, snoring and cough markers on a timeline. Keep your daily wake-up streak."};
        String[] details={
            "Camera push-ups   •   Photo missions", "Yoga   •   Sit-ups   •   Squats   •   Calories", "Sleep insights   •   Sound timeline   •   Alarm"};
        root.addView(Ui.text(this,titles[promoStep],28,Ui.WHITE,true));Ui.space(root,11);
        root.addView(Ui.text(this,desc[promoStep],15,Ui.MUTED,false));Ui.space(root,18);
        LinearLayout chip=Ui.card(this);
        chip.addView(Ui.text(this,details[promoStep],13,Ui.PEACH,true));root.addView(chip);
        Ui.space(root,22);
        Button next=Ui.button(this,promoStep==2?"Get started":"Continue  →",true);
        root.addView(next,Ui.matchMargins(this,9));
        next.setOnClickListener(v->{
            if(promoStep<2){promoStep++;getSharedPreferences("onboarding",MODE_PRIVATE).edit().putInt("promo_step",promoStep).apply();showPromo();}
            else finishPromo();
        });
        Button secondary=Ui.button(this,promoStep==0?"Skip introduction":"← Back",false);
        root.addView(secondary);
        secondary.setOnClickListener(v->{if(promoStep>0){promoStep--;getSharedPreferences("onboarding",MODE_PRIVATE).edit().putInt("promo_step",promoStep).apply();showPromo();}else finishPromo();});
        setContentView(scroll);
    }
    private void finishPromo(){
        getSharedPreferences("onboarding",MODE_PRIVATE).edit().putBoolean("promo_seen",true).remove("promo_step").apply();
        if(getSharedPreferences("onboarding",MODE_PRIVATE).getBoolean("done",false))render();
        else {introStep=0;showWelcome();}
    }
    private void showLanguagePicker(boolean firstRun){
        // Searching 100+ options is essential on small phones; the list is filtered locally.
        LinearLayout body=Ui.column(this);
        int p=Ui.dp(this,16);body.setPadding(p,p,p,Ui.dp(this,7));
        EditText search=new EditText(this);search.setSingleLine(true);
        search.setTextSize(16);search.setHint(I18n.tr(this,"Search language / Dil ara"));
        body.addView(search,new LinearLayout.LayoutParams(-1,Ui.dp(this,54)));
        ListView list=new ListView(this);
        final java.util.ArrayList<String> visible=new java.util.ArrayList<>(java.util.Arrays.asList(LanguageCatalog.CODES));
        final ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,new java.util.ArrayList<String>()){
            @Override public View getView(int position,View convertView,android.view.ViewGroup parent){
                TextView tv=(TextView)super.getView(position,convertView,parent);
                String code=visible.get(position);tv.setText(LanguageCatalog.label(code)+(LanguageCatalog.isTranslated(code)?"":"  ·  English fallback"));
                tv.setTextSize(15);tv.setPadding(Ui.dp(MainActivity.this,11),Ui.dp(MainActivity.this,12),Ui.dp(MainActivity.this,8),Ui.dp(MainActivity.this,12));
                return tv;
            }
        };
        for(String code:visible)adapter.add(LanguageCatalog.label(code));
        list.setAdapter(adapter);
        body.addView(list,new LinearLayout.LayoutParams(-1,Ui.dp(this,380)));
        TextView disclaimer=Ui.text(this,"English is the default. Languages without a completed translation temporarily use English.",12,Ui.MUTED,false);
        body.addView(disclaimer);
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle(I18n.tr(this,"Choose your language ("+LanguageCatalog.CODES.length+")")).setView(body).create();
        dlg.setCancelable(!firstRun);
        list.setOnItemClickListener((parent,view,position,id)->{
            if(position<0||position>=visible.size())return;
            String code=visible.get(position);
            getSharedPreferences("display_settings",MODE_PRIVATE).edit().putString("language",code).apply();
            if(firstRun)getSharedPreferences("onboarding",MODE_PRIVATE).edit().putBoolean("language_chosen",true).apply();
            languageDialogActive=false;dlg.dismiss();
            if(firstRun)showFirstRunFlow();else recreate();
        });
        search.addTextChangedListener(new android.text.TextWatcher(){
            public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            public void onTextChanged(CharSequence s,int start,int before,int count){
                visible.clear();String query=s.toString().toLowerCase(java.util.Locale.ROOT).trim();
                for(String code:LanguageCatalog.CODES){
                    String match=LanguageCatalog.label(code).toLowerCase(java.util.Locale.ROOT);
                    if(match.contains(query)||code.toLowerCase(java.util.Locale.ROOT).contains(query))visible.add(code);
                }
                adapter.clear();for(String code:visible)adapter.add(LanguageCatalog.label(code));
                adapter.notifyDataSetChanged();
            }
            public void afterTextChanged(android.text.Editable s){}
        });
        dlg.show();
    }
    private void showWelcome(){
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);sc.setBackgroundColor(Ui.BG);
        LinearLayout root=Ui.column(this);
        root.setPadding(Ui.dp(this,25),Ui.dp(this,34),Ui.dp(this,25),Ui.dp(this,34));sc.addView(root);
        TextView brand=Ui.text(this,"☀  Mission Alarm Veykano",20,Ui.WHITE,true);root.addView(brand);Ui.space(root,22);
        LinearLayout progress=Ui.row(this);
        for(int i=0;i<4;i++){
            View line=new View(this);line.setBackground(Ui.shape(i<=introStep?Ui.PEACH:Ui.OUTLINE,3,this));
            LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(0,Ui.dp(this,5),1);
            if(i>0)q.leftMargin=Ui.dp(this,6);progress.addView(line,q);
        }
        root.addView(progress);Ui.space(root,32);
        String[] titles={"Sabahların değişsin.","Sabah uyanmakta en çok ne zor?","Sana uygun bir görev seçelim.","Yeni sabah rutinin hazır!"};
        String[] descriptions={"Kişisel uyanma planını birkaç dokunuşla oluşturalım.",
            "Seçimine göre başlangıç hedefini ayarlayalım.",
            "Alarm ancak seçtiğin görevi tamamladığında kapanır.",
            "Hedefini ve alarmını istediğin zaman değiştirebilirsin. Abonelik zorunlu değil."};
        root.addView(Ui.text(this,titles[Math.min(introStep,3)],33,Ui.WHITE,true));Ui.space(root,12);
        root.addView(Ui.text(this,descriptions[Math.min(introStep,3)],16,Ui.MUTED,false));Ui.space(root,26);
        if(introStep==0){
            addIntroOption(root,"☀  Erken ve dinç uyanmak",()->{introGoal="Erken ve dinç uyanmak";introStep++;showWelcome();});
            addIntroOption(root,"⏰  İşe veya okula yetişmek",()->{introGoal="İşe veya okula yetişmek";introStep++;showWelcome();});
            addIntroOption(root,"🌿  Daha iyi bir uyku düzeni",()->{introGoal="Uyku düzenimi takip etmek";introStep++;showWelcome();});
        }else if(introStep==1){
            addIntroOption(root,"💤  Alarmı duyamıyorum",()->{introGoal="Derin uykudan uyanmak";introStep++;showWelcome();});
            addIntroOption(root,"↻  Sürekli erteliyorum",()->{introGoal="Ertelemeyi bırakmak";introStep++;showWelcome();});
            addIntroOption(root,"⚡  Sabah enerjim düşük",()->{introGoal="Sabah enerjimi yükseltmek";introStep++;showWelcome();});
        }else if(introStep==2){
            addIntroOption(root,"◉  Kamerayla şınav",()->{introMission=AlarmItem.PUSHUP;introStep++;showWelcome();});
            addIntroOption(root,"▣  Gökyüzü fotoğrafı",()->{introMission=AlarmItem.PHOTO;introStep++;showWelcome();});
            addIntroOption(root,"◈  Hafıza oyunu",()->{introMission=AlarmItem.MEMORY;introStep++;showWelcome();});
            addIntroOption(root,"＋  Matematik görevi",()->{introMission=AlarmItem.MATH;introStep++;showWelcome();});
        }else{
            LinearLayout summary=Ui.card(this);
            summary.addView(Ui.text(this,"☀  SABAH PLANIM",14,Ui.PEACH,true));Ui.space(summary,12);
            summary.addView(Ui.text(this,introGoal,21,Ui.WHITE,true));Ui.space(summary,7);
            summary.addView(Ui.text(this,"İlk görevin: "+I18n.tr(this,AlarmItem.missionName(introMission)),14,Ui.MUTED,false));
            root.addView(summary);Ui.space(root,18);
            Button start=Ui.button(this,"İlk alarmımı kur  →",true);root.addView(start);
            start.setOnClickListener(v->{finishWelcome();startActivity(new Intent(this,AlarmEditorActivity.class).putExtra("mission",introMission));});
        }
        Ui.space(root,24);
        Button skip=Ui.button(this,introStep>0?"‹  Önceki adım":"Şimdilik geç",false);root.addView(skip);
        skip.setOnClickListener(v->{if(introStep>0){introStep--;showWelcome();}else finishWelcome();});
        if(introStep>0){Ui.space(root,8);TextView later=Ui.text(this,"Kurulumu geç",13,Ui.MUTED,false);
            later.setGravity(Gravity.CENTER);later.setPadding(0,Ui.dp(this,12),0,Ui.dp(this,12));root.addView(later);later.setOnClickListener(v->finishWelcome());}
        setContentView(sc);
    }
    private void finishWelcome(){
        getSharedPreferences("onboarding",MODE_PRIVATE).edit().putBoolean("done",true).putString("goal",introGoal).apply();
        section="home";render();
    }
    private void addIntroOption(LinearLayout root,String text,Runnable action){
        LinearLayout card=Ui.card(this);card.setPadding(Ui.dp(this,19),Ui.dp(this,20),Ui.dp(this,15),Ui.dp(this,20));
        LinearLayout row=Ui.row(this);row.addView(Ui.text(this,text,17,Ui.WHITE,true),new LinearLayout.LayoutParams(0,-2,1));
        row.addView(Ui.text(this,"›",24,Ui.MUTED,false));card.addView(row);root.addView(card,Ui.matchMargins(this,12));
        card.setOnClickListener(v->action.run());
    }
    private void render(){
        AppTheme.apply(this);
        android.widget.FrameLayout container=new android.widget.FrameLayout(this);
        container.setBackgroundColor(Ui.BG);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setVerticalScrollBarEnabled(false);
        LinearLayout host=Ui.column(this);host.setPadding(Ui.dp(this,17),Ui.dp(this,11),Ui.dp(this,17),Ui.dp(this,83));
        scroll.addView(host);screen=host;
        header();
        switch(section){
            case "home":showHome();break;
            case "missions":showMissions();break;
            case "insights":case "history":showHistory();break;
            case "milestones":case "achievements":showAchievements();break;
            case "profile":showProfile();break;
            case "sleep":showSleep();break;
            case "settings":showSettings();break;
            default:showAlarms();break;
        }
        container.addView(scroll,new android.widget.FrameLayout.LayoutParams(-1,-1));
        android.widget.FrameLayout.LayoutParams floating=new android.widget.FrameLayout.LayoutParams(-1,Ui.dp(this,62),Gravity.BOTTOM);
        floating.setMargins(Ui.dp(this,0),0,Ui.dp(this,0),0);
        container.addView(bottomNav(),floating);
        setContentView(container);
    }
    private void header(){
        if("home".equals(section)){
            LinearLayout row=Ui.row(this);
            row.addView(Ui.text(this,"Mission Alarm Veykano",23,Ui.WHITE,true),new LinearLayout.LayoutParams(0,-2,1));
            ReferenceIconView gear=new ReferenceIconView(this,"settings",Ui.WHITE);
            gear.setContentDescription(I18n.tr(this,"Ayarlar"));
            gear.setOnClickListener(v->{section="settings";render();});
            row.addView(gear,new LinearLayout.LayoutParams(Ui.dp(this,31),Ui.dp(this,31)));
            screen.addView(row);Ui.space(screen,16);return;
        }
        if("missions".equals(section)||"settings".equals(section)){
            LinearLayout row=Ui.row(this);
            TextView back=Ui.text(this,"‹",32,Ui.WHITE,false);back.setPadding(0,0,Ui.dp(this,16),0);
            back.setOnClickListener(v->{section="home";render();});row.addView(back);
            TextView center=Ui.text(this,"missions".equals(section)?"Görev Seç":"Ayarlar",19,Ui.WHITE,true);
            center.setGravity(Gravity.CENTER);row.addView(center,new LinearLayout.LayoutParams(0,-2,1));
            row.addView(new View(this),new LinearLayout.LayoutParams(Ui.dp(this,46),1));screen.addView(row);
            Ui.space(screen,16);return;
        }
        String title="Alarmlar";
        switch(section){case "insights":case "history":title="İstatistikler";break;
            case "sleep":title="Uyku Analizi";break;
            case "profile":title="Profil";break;
            case "milestones":case "achievements":title="Başarılar";break;}
        LinearLayout row=Ui.row(this);
        row.addView(Ui.text(this,title,25,Ui.WHITE,true),new LinearLayout.LayoutParams(0,-2,1));
        if("alarms".equals(section)){
            TextView plus=Ui.text(this,"+",30,Ui.WHITE,false);plus.setPadding(Ui.dp(this,10),0,Ui.dp(this,7),0);
            plus.setOnClickListener(v->startActivity(new Intent(this,AlarmEditorActivity.class)));row.addView(plus);
        }
        screen.addView(row);Ui.space(screen,16);
    }

    private LinearLayout bottomNav(){
        LinearLayout nav=Ui.row(this);nav.setGravity(Gravity.CENTER);
        nav.setPadding(Ui.dp(this,7),Ui.dp(this,7),Ui.dp(this,7),Ui.dp(this,4));
        nav.setBackground(Ui.shape(Ui.NAV,0,this));
        String[][] tabs={{"home","Ana Sayfa","home"},{"alarms","Alarmlar","alarm"},
            {"insights","Analizler","stats"},{"profile","Profil","person"}};
        for(String[] tab:tabs){
            boolean selected=section.equals(tab[0])||"history".equals(section)&&"insights".equals(tab[0])
                ||"sleep".equals(section)&&"insights".equals(tab[0])||"settings".equals(section)&&"profile".equals(tab[0]);
            LinearLayout item=Ui.column(this);item.setGravity(Gravity.CENTER);item.setClickable(true);
            int color=selected?0xFFE49E03:0xFF32343B;
            FrameLayout iconHolder=new FrameLayout(this);
            if(selected)iconHolder.setBackground(Ui.shape(0xFFFFD949,50,this));
            NavIconView icon=new NavIconView(this,tab[2],0xFF202020);
            iconHolder.addView(icon,new FrameLayout.LayoutParams(Ui.dp(this,20),Ui.dp(this,20),Gravity.CENTER));
            item.addView(iconHolder,new LinearLayout.LayoutParams(Ui.dp(this,30),Ui.dp(this,30)));
            Ui.space(item,2);
            TextView label=Ui.text(this,tab[1],10,color,selected);label.setGravity(Gravity.CENTER);label.setSingleLine(true);
            item.addView(label);item.setContentDescription(tab[1]);
            nav.addView(item,new LinearLayout.LayoutParams(0,-1,1));
            item.setOnClickListener(v->{section=tab[0];render();});
        }
        return nav;
    }

    private void showHome(){
        addWeekStrip();Ui.space(screen,12);
        Achievements stats=Achievements.from(AlarmRepository.history(this));
        LinearLayout streak=Ui.card(this);streak.setPadding(Ui.dp(this,17),Ui.dp(this,14),Ui.dp(this,14),Ui.dp(this,14));
        LinearLayout strip=Ui.row(this);
        strip.addView(Ui.text(this,"🔥",29,Ui.PEACH,true));Ui.spaceHoriz(strip,12);
        LinearLayout content=Ui.column(this);
        LinearLayout heading=Ui.row(this);heading.addView(Ui.text(this,String.valueOf(stats.streak),31,Ui.WHITE,true));
        Ui.spaceHoriz(heading,7);heading.addView(Ui.text(this,"günlük uyanma serisi",13,Ui.WHITE,true));content.addView(heading);
        content.addView(Ui.text(this,"Harika gidiyorsun!",12,Ui.MUTED,false));strip.addView(content);streak.addView(strip);
        screen.addView(streak,Ui.matchMargins(this,13));
        List<AlarmItem> alarms=AlarmRepository.list(this);AlarmItem next=null;long min=Long.MAX_VALUE;
        for(AlarmItem a:alarms)if(a.enabled)try{long t=AlarmTimeLogic.nextTriggerMillis(a.hour,a.minute,a.daysMask,System.currentTimeMillis(),TimeZone.getDefault());if(t<min){min=t;next=a;}}catch(Exception ignored){}
        LinearLayout card=Ui.column(this);card.setPadding(Ui.dp(this,20),Ui.dp(this,16),Ui.dp(this,20),Ui.dp(this,17));
        card.setBackground(Ui.shape(0xFF242628,18,this));
        card.addView(Ui.text(this,"Sıradaki Alarm",13,0xFFFFFFFF,false));Ui.space(card,8);
        LinearLayout middle=Ui.row(this);
        middle.addView(Ui.text(this,next==null?"--:--":next.timeText(),36,0xFFFFFFFF,true),new LinearLayout.LayoutParams(0,-2,1));
        final AlarmItem chosen=next;
        if(next!=null){ReferenceToggleView sw=new ReferenceToggleView(this);sw.setChecked(next.enabled);sw.setOnCheckedChangeListener(on->{chosen.enabled=on;AlarmScheduler.cancel(this,chosen.id);AlarmRepository.put(this,chosen);if(on)AlarmScheduler.schedule(this,chosen);render();});middle.addView(sw,new LinearLayout.LayoutParams(Ui.dp(this,51),Ui.dp(this,37)));}
        else {TextView plus=Ui.text(this,"+",27,Ui.PEACH,true);middle.addView(plus);plus.setOnClickListener(v->startActivity(new Intent(this,AlarmEditorActivity.class)));}
        card.addView(middle);Ui.space(card,7);
        String details=next==null?"Henüz alarm yok • Alarm Ekle":next.repeatText(this)+" • "+I18n.tr(this,AlarmItem.missionName(next.mission));
        card.addView(Ui.text(this,details+"     ›",13,0xFFF8F8F8,false));
        card.setOnClickListener(v->{Intent i=new Intent(this,AlarmEditorActivity.class);if(chosen!=null)i.putExtra("alarm_id",chosen.id);startActivity(i);});
        screen.addView(card,Ui.matchMargins(this,12));
        LinearLayout first=Ui.row(this);
        addReferenceShortcut(first,"plus","Alarm Ekle",()->startActivity(new Intent(this,AlarmEditorActivity.class)));
        addReferenceShortcut(first,"dumbbell","Görevler",()->{section="missions";render();});
        screen.addView(first,Ui.matchMargins(this,9));
        LinearLayout second=Ui.row(this);
        addReferenceShortcut(second,"moon","Uyku Analizi",()->{section="sleep";render();});
        addReferenceShortcut(second,"bars","İstatistikler",()->{section="insights";render();});
        screen.addView(second,Ui.matchMargins(this,10));
    }
    private void addReferenceShortcut(LinearLayout parent,String iconName,String title,Runnable onClick){
        LinearLayout tile=Ui.column(this);tile.setGravity(Gravity.CENTER);
        tile.setBackground(Ui.shape(Ui.PANEL,18,this));tile.setClickable(true);
        FrameLayout iconHolder=new FrameLayout(this);
        if("plus".equals(iconName))iconHolder.setBackground(Ui.shape(Ui.PEACH,10,this));
        ReferenceIconView drawing=new ReferenceIconView(this,iconName,0xFF101010);
        FrameLayout.LayoutParams dp=new FrameLayout.LayoutParams(Ui.dp(this,31),Ui.dp(this,31),Gravity.CENTER);
        iconHolder.addView(drawing,dp);
        tile.addView(iconHolder,new LinearLayout.LayoutParams(Ui.dp(this,39),Ui.dp(this,38)));
        Ui.space(tile,6);
        TextView label=Ui.text(this,title,13,Ui.WHITE,true);label.setGravity(Gravity.CENTER);
        tile.addView(label);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,Ui.dp(this,91),1);
        lp.rightMargin=Ui.dp(this,7);parent.addView(tile,lp);tile.setOnClickListener(v->onClick.run());
    }

    private void addWeekStrip(){
        JSONArray history=AlarmRepository.history(this);HashSet<String> completed=new HashSet<>();
        SimpleDateFormat dateFmt=new SimpleDateFormat("yyyy-MM-dd",Locale.ROOT);
        for(int i=0;i<history.length();i++){JSONObject h=history.optJSONObject(i);
            if(h!=null&&"Görev tamamlandı".equals(h.optString("result")))completed.add(dateFmt.format(new Date(h.optLong("time"))));}
        LinearLayout week=Ui.row(this);week.setGravity(Gravity.CENTER);
        String[] days={"P","S","Ç","P","C","C","P"};Calendar today=Calendar.getInstance();
        Calendar monday=(Calendar)today.clone();int offset=(today.get(Calendar.DAY_OF_WEEK)+5)%7;monday.add(Calendar.DAY_OF_YEAR,-offset);
        for(int i=0;i<7;i++){
            Calendar date=(Calendar)monday.clone();date.add(Calendar.DAY_OF_YEAR,i);
            boolean active=date.get(Calendar.DAY_OF_YEAR)==today.get(Calendar.DAY_OF_YEAR)&&date.get(Calendar.YEAR)==today.get(Calendar.YEAR);
            boolean completedDay=completed.contains(dateFmt.format(date.getTime()));
            LinearLayout item=Ui.column(this);item.setGravity(Gravity.CENTER);
            item.addView(Ui.text(this,days[i],11,Ui.WHITE,false));Ui.space(item,6);
            TextView day=Ui.text(this,completedDay?"✓":String.valueOf(date.get(Calendar.DAY_OF_MONTH)),13,Ui.WHITE,true);
            day.setGravity(Gravity.CENTER);if(active)day.setBackground(Ui.shape(Ui.PEACH,24,this));
            item.addView(day,new LinearLayout.LayoutParams(Ui.dp(this,31),Ui.dp(this,31)));
            week.addView(item,new LinearLayout.LayoutParams(0,-2,1));
        }
        screen.addView(week);
    }
    private void shortcutTile(LinearLayout parent,String symbol,String title,String subtitle,Runnable click){
        LinearLayout tile=Ui.card(this);
        tile.addView(Ui.text(this,symbol,27,Ui.PEACH,true));Ui.space(tile,12);
        tile.addView(Ui.text(this,title,16,Ui.WHITE,true));Ui.space(tile,4);
        tile.addView(Ui.text(this,subtitle,11,Ui.MUTED,false));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,Ui.dp(this,138),1);
        p.rightMargin=Ui.dp(this,6);parent.addView(tile,p);tile.setOnClickListener(v->click.run());
    }
    private void showMissions(){
        TextView subtitle=Ui.text(this,"Uyanmak için tamamlaman gereken görevi seç.",12,Ui.MUTED,false);
        subtitle.setGravity(Gravity.CENTER);screen.addView(subtitle);Ui.space(screen,17);
        String[][] missions={
           {AlarmItem.PUSHUP,"Şınav","Fiziksel görev","dumbbell"},
           {AlarmItem.SQUAT,"Squat","Fiziksel görev","squat"},
           {AlarmItem.YOGA,"Yoga Modu","Pozu kamerada koru","yoga"},
           {AlarmItem.SITUP,"Mekik Modu","Kamerayla mekik say","situp"},
           {AlarmItem.CALORIE,"Kalori Modu","Tahmini yakılan kalori","calorie"},
           {AlarmItem.PHOTO,"Fotoğraf","Belirli bir yerin fotoğrafını çek","camera"},
           {AlarmItem.BED,"Yatak Toplama","Yatağını topla, kamerayla göster","camera"},
           {AlarmItem.MATH,"Matematik","Rastgele işlemleri çöz","calculator"},
           {AlarmItem.QR,"QR Kod","Belirli bir QR kodu okut","qr"},
           {AlarmItem.WALK,"Yürüme","Belirli adım sayısına ulaş","steps"},
           {AlarmItem.VOICE,"Ses Kaydı","Belirli bir cümleyi söyle","mic"},
           {AlarmItem.TYPE,"Dokunmatik","Ekrandaki nesnelere dokun","touch"},
           {AlarmItem.MEMORY,"Hafıza","Kartları hatırla","◈"},
           {AlarmItem.SHAKE,"Sallama","Telefonu hareket ettir","↔"},
           {AlarmItem.CHAIN,"Görev Zinciri","Birden fazla görevi tamamla","◇"}};
        TextView cameraTest=Ui.text(this,"◎  Kamerayla şınavı test et  ›",14,Ui.WHITE,true);
        cameraTest.setGravity(Gravity.CENTER);
        cameraTest.setPadding(0,Ui.dp(this,12),0,Ui.dp(this,12));
        cameraTest.setBackground(Ui.stroked(Ui.PANEL,13,Ui.PEACH,this));
        cameraTest.setContentDescription(I18n.tr(this,"Gerçek kamera ile 20 şınav görevi test et"));
        cameraTest.setOnClickListener(v->startActivity(new Intent(this,CameraExerciseActivity.class)
            .putExtra(CameraExerciseActivity.EXTRA_KIND,"PUSHUP")
            .putExtra(CameraExerciseActivity.EXTRA_TARGET,20)));
        screen.addView(cameraTest,Ui.matchMargins(this,15));
        for(int i=0;i<missions.length;i+=2){LinearLayout row=Ui.row(this);row.setGravity(Gravity.TOP);
            addMissionTile(row,missions[i]);if(i+1<missions.length)addMissionTile(row,missions[i+1]);
            else row.addView(new View(this),new LinearLayout.LayoutParams(0,1,1));
            screen.addView(row,Ui.matchMargins(this,9));}
    }

    private void addMissionTile(LinearLayout parent,String[] m){
        LinearLayout tile=Ui.column(this);tile.setGravity(Gravity.CENTER);
        tile.setBackground(Ui.shape(Ui.PANEL,18,this));
        tile.setPadding(Ui.dp(this,8),Ui.dp(this,11),Ui.dp(this,8),Ui.dp(this,8));
        if(AlarmItem.PUSHUP.equals(m[0]))tile.setBackground(Ui.stroked(Ui.PANEL,18,Ui.PEACH,this));
        String glyph=m[3];
        if(glyph.equals("dumbbell")||glyph.equals("squat")||glyph.equals("camera")||glyph.equals("calculator")
            ||glyph.equals("qr")||glyph.equals("yoga")||glyph.equals("situp")||glyph.equals("calorie")||glyph.equals("steps")||glyph.equals("mic")||glyph.equals("touch")){
            ReferenceIconView icon=new ReferenceIconView(this,glyph,0xFF101010);
            tile.addView(icon,new LinearLayout.LayoutParams(Ui.dp(this,38),Ui.dp(this,38)));
        }else{
            TextView fallback=Ui.text(this,glyph,26,Ui.WHITE,true);fallback.setGravity(Gravity.CENTER);
            tile.addView(fallback,new LinearLayout.LayoutParams(-1,Ui.dp(this,38)));
        }
        Ui.space(tile,6);
        TextView title=Ui.text(this,m[1],15,Ui.WHITE,true);title.setGravity(Gravity.CENTER);tile.addView(title);
        Ui.space(tile,5);
        TextView desc=Ui.text(this,m[2],11,Ui.MUTED,false);desc.setGravity(Gravity.CENTER);
        desc.setMaxLines(2);tile.addView(desc);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,Ui.dp(this,126),1);
        lp.rightMargin=Ui.dp(this,7);parent.addView(tile,lp);
        tile.setOnClickListener(v->startActivity(new Intent(this,AlarmEditorActivity.class).putExtra("mission",m[0])));
    }

    private void showAchievements(){
        Achievements a=Achievements.from(AlarmRepository.history(this));
        LinearLayout hero=Ui.card(this);hero.setGravity(Gravity.CENTER_HORIZONTAL);
        hero.addView(Ui.text(this,"🏆",46,Ui.PEACH,true));Ui.space(hero,6);
        hero.addView(Ui.text(this,"Her sabah bir başarı",22,Ui.WHITE,true));
        hero.addView(Ui.text(this,"Görevleri tamamladıkça yeni rozetler kazan",13,Ui.MUTED,false));
        screen.addView(hero,Ui.matchMargins(this,18));
        LinearLayout badges=Ui.row(this);
        shortcutTile(badges,"🏅","İlk adım",a.completed>=1?"Kazanıldı ✓":"1 görev gerekli",()->{});
        shortcutTile(badges,"🔥","Üç gün",a.streak>=3?"Kazanıldı ✓":"3 günlük seri",()->{});
        screen.addView(badges,Ui.matchMargins(this,10));
        LinearLayout badges2=Ui.row(this);
        shortcutTile(badges2,"⭐","10 görev",a.completed>=10?"Kazanıldı ✓":"10 başarılı alarm",()->{});
        shortcutTile(badges2,"⚡","Hızlı uyan",a.underMinute>=5?"Kazanıldı ✓":"5 hızlı görev",()->{});
        screen.addView(badges2,Ui.matchMargins(this,15));
        sectionCard("🏆 Başarı rozetleri",a.badges());
        sectionCard("🔥 Günlük seri",a.streak+" gün");
        sectionCard("✓ Başarılı uyanış",a.completed+" tamamlanan alarm");
        sectionCard("⚡ Hızlı uyanış",a.underMinute+" görev bir dakikadan kısa sürede tamamlandı.");
        screen.addView(Ui.text(this,"SON 7 GÜN",13,Ui.PEACH,true));
        screen.addView(new SevenDayChart(this,a.lastSeven),Ui.matchMargins(this,12));
    }
    private void showAlarms(){
        List<AlarmItem> alarms=AlarmRepository.list(this);
        Collections.sort(alarms,Comparator.comparingInt(a->a.hour*60+a.minute));
        if(alarms.isEmpty()){
            LinearLayout empty=Ui.card(this);
            empty.addView(Ui.text(this,"Henüz bir alarm kurulmadı",17,Ui.WHITE,true));Ui.space(empty,9);
            empty.addView(Ui.text(this,"Sağ üstteki + işaretine dokunarak alarm ekle.",13,Ui.MUTED,false));
            screen.addView(empty,Ui.matchMargins(this,12));
        }else{
            LinearLayout group=Ui.column(this);group.setBackground(Ui.shape(Ui.PANEL,18,this));
            for(int i=0;i<alarms.size();i++){
                alarmCard(group,alarms.get(i));
                if(i<alarms.size()-1){View line=new View(this);line.setBackgroundColor(Ui.OUTLINE);
                    LinearLayout.LayoutParams rule=new LinearLayout.LayoutParams(-1,Ui.dp(this,1));
                    rule.leftMargin=Ui.dp(this,17);rule.rightMargin=Ui.dp(this,17);group.addView(line,rule);}
            }
            screen.addView(group,Ui.matchMargins(this,14));
        }
        TextView add=Ui.text(this,"+  Alarm Ekle",13,Ui.MUTED,true);
        add.setGravity(Gravity.CENTER);add.setPadding(0,Ui.dp(this,12),0,Ui.dp(this,12));
        screen.addView(add,Ui.matchMargins(this,8));
        add.setOnClickListener(v->startActivity(new Intent(this,AlarmEditorActivity.class)));
        TextView extra=Ui.text(this,"Test alarmı kur  ›",11,Ui.MUTED,false);extra.setGravity(Gravity.CENTER);
        screen.addView(extra);extra.setOnClickListener(v->testAlarm());
    }

    private void alarmCard(LinearLayout group,AlarmItem alarm){
        LinearLayout row=Ui.row(this);row.setPadding(Ui.dp(this,17),Ui.dp(this,15),Ui.dp(this,13),Ui.dp(this,15));
        LinearLayout content=Ui.column(this);
        content.addView(Ui.text(this,alarm.timeText(),24,Ui.WHITE,true));Ui.space(content,4);
        content.addView(Ui.text(this,alarm.repeatText(this)+" • "+I18n.tr(this,AlarmItem.missionName(alarm.mission)),11,Ui.MUTED,false));
        row.addView(content,new LinearLayout.LayoutParams(0,-2,1));
        ReferenceToggleView toggle=new ReferenceToggleView(this);toggle.setChecked(alarm.enabled);
        row.addView(toggle,new LinearLayout.LayoutParams(Ui.dp(this,51),Ui.dp(this,37)));
        toggle.setOnCheckedChangeListener(on->{
            alarm.enabled=on;AlarmScheduler.cancel(this,alarm.id);AlarmRepository.put(this,alarm);
            if(on&&!AlarmScheduler.schedule(this,alarm))Toast.makeText(this,I18n.tr(this,"Alarm izinlerini kontrol et."),Toast.LENGTH_LONG).show();render();
        });
        TextView edit=Ui.text(this,"⋮",22,Ui.MUTED,false);edit.setPadding(Ui.dp(this,8),0,0,0);
        edit.setOnClickListener(v->startActivity(new Intent(this,AlarmEditorActivity.class).putExtra("alarm_id",alarm.id)));
        row.addView(edit);row.setOnClickListener(v->startActivity(new Intent(this,AlarmEditorActivity.class).putExtra("alarm_id",alarm.id)));
        group.addView(row);
    }

    private void testAlarm(){
        Calendar c=Calendar.getInstance();c.add(Calendar.MINUTE,2);
        AlarmItem a=new AlarmItem();a.id=AlarmRepository.nextId(this);a.hour=c.get(Calendar.HOUR_OF_DAY);a.minute=c.get(Calendar.MINUTE);
        a.title="Deneme alarmı";a.daysMask=0;a.challengeCount=1;a.snoozeMax=0;
        AlarmRepository.put(this,a);
        if(AlarmScheduler.schedule(this,a))Toast.makeText(this,I18n.tr(this,"Deneme alarmı ayarlandı"),Toast.LENGTH_LONG).show();
        else {a.enabled=false;AlarmRepository.put(this,a);
            new AlertDialog.Builder(this).setTitle(I18n.tr(this,"İzin gerekli"))
              .setMessage(I18n.tr(this,"Alarmı planlayamadık. Cihaz alarm izinlerini kontrol et."))
              .setPositiveButton(I18n.tr(this,"Tamam"),null).show();}
        render();
    }
    private void showHistory(){
        JSONArray history=AlarmRepository.history(this);Achievements a=Achievements.from(history);
        LinearLayout tabs=Ui.row(this);String[] titles={"Haftalık","Aylık","Tümü"};
        for(int i=0;i<3;i++){
            TextView item=Ui.text(this,titles[i],12,Ui.WHITE,i==0);item.setGravity(Gravity.CENTER);
            if(i==0)item.setBackground(Ui.shape(Ui.PEACH,25,this));
            tabs.addView(item,new LinearLayout.LayoutParams(0,Ui.dp(this,32),1));
        }screen.addView(tabs,Ui.matchMargins(this,15));
        int good=a.completed,total=history.length();int ratio=total==0?0:Math.min(100,100*good/Math.max(1,total));
        LinearLayout hero=Ui.card(this);hero.addView(Ui.text(this,"Uyanma Oranı",13,Ui.WHITE,false));
        hero.addView(Ui.text(this,"%"+ratio,33,Ui.WHITE,true));Ui.space(hero,9);
        hero.addView(new SevenDayChart(this,a.lastSeven),new LinearLayout.LayoutParams(-1,Ui.dp(this,140)));
        screen.addView(hero,Ui.matchMargins(this,11));
        LinearLayout one=Ui.row(this);
        referenceMetric(one,"Uyanma Serisi",a.streak+" gün","🔥");
        referenceMetric(one,"Tamamlanan Görev",String.valueOf(a.completed),"✓");
        screen.addView(one,Ui.matchMargins(this,10));
        LinearLayout two=Ui.row(this);
        int sleepMins=0;JSONArray nights=AlarmRepository.sleepHistory(this);
        for(int i=0;i<nights.length();i++){JSONObject n=nights.optJSONObject(i);if(n==null)continue;
            try{int mm=minutes(n.optString("wake","07:00"))-minutes(n.optString("sleep","23:00"));if(mm<0)mm+=1440;sleepMins+=mm;}catch(Exception ignored){}}
        referenceMetric(two,"Toplam Uyku Süresi",(sleepMins/60)+" sa "+(sleepMins%60)+" dk","☾");
        referenceMetric(two,"Kaçırılan Alarm",String.valueOf(Math.max(0,total-good)),"✕");
        screen.addView(two,Ui.matchMargins(this,13));
        TextView sleep=Ui.text(this,"Uyku Analizine Git   ›",13,Ui.WHITE,true);screen.addView(sleep);
        sleep.setOnClickListener(v->{section="sleep";render();});
        screen.addView(Ui.text(this,"İstatistikler gerçek cihaz kayıtlarından hesaplanır.",11,Ui.MUTED,false));
    }
    private void referenceMetric(LinearLayout parent,String title,String value,String icon){
        LinearLayout tile=Ui.card(this);tile.setPadding(Ui.dp(this,13),Ui.dp(this,15),Ui.dp(this,12),Ui.dp(this,13));
        tile.addView(Ui.text(this,title,12,Ui.WHITE,false));Ui.space(tile,9);
        LinearLayout row=Ui.row(this);row.addView(Ui.text(this,value,20,Ui.WHITE,true),new LinearLayout.LayoutParams(0,-2,1));
        row.addView(Ui.text(this,icon,22,Ui.PEACH,true));tile.addView(row);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,Ui.dp(this,99),1);lp.rightMargin=Ui.dp(this,6);parent.addView(tile,lp);
    }

    private void metric(LinearLayout parent,String emoji,int amount,String label){
        LinearLayout card=Ui.card(this);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);
        p.rightMargin=Ui.dp(this,5);parent.addView(card,p);
        card.addView(Ui.text(this,emoji+" "+amount,20,Ui.WHITE,true));
        card.addView(Ui.text(this,label,11,Ui.MUTED,false));
    }
    private void showSleep(){
        SleepRecordStore.recoverInterrupted(this,SleepAudioService.isRunning());
        final boolean running=SleepAudioService.isRunning();
        LinearLayout tabs=Ui.row(this);
        String[] sleepTabs={"Genel","Kayıtlar","Kabuslar"};
        for(int i=0;i<sleepTabs.length;i++){
            TextView t=Ui.text(this,sleepTabs[i],12,Ui.WHITE,i==0);t.setGravity(Gravity.CENTER);
            if(i==0)t.setBackground(Ui.shape(Ui.PEACH,24,this));
            tabs.addView(t,new LinearLayout.LayoutParams(0,Ui.dp(this,32),1));
            final int idx=i;t.setOnClickListener(v->{
                if(idx==1){new AlertDialog.Builder(this).setTitle(I18n.tr(this,"Uyku Kayıtları"))
                    .setMessage(I18n.tr(this,"Ses kayıtlarını aşağıdaki Son Kayıtlar bölümünde görüntüleyebilirsin."))
                    .setPositiveButton(I18n.tr(this,"Tamam"),null).show();}
                else if(idx==2)askNightmare();
            });
        }
        screen.addView(tabs,Ui.matchMargins(this,13));
        JSONArray sleepHistory=AlarmRepository.sleepHistory(this);
        long minutesTotal=0;int validNights=0;
        for(int i=0;i<sleepHistory.length();i++){
            JSONObject n=sleepHistory.optJSONObject(i);if(n==null)continue;
            try{int mm=minutes(n.optString("wake","07:00"))-minutes(n.optString("sleep","23:00"));
                if(mm<0)mm+=1440;minutesTotal+=mm;validNights++;}catch(Exception ignored){}
        }
        LinearLayout summary=Ui.card(this);
        summary.addView(Ui.text(this,"Ortalama Uyku Süresi",13,Ui.WHITE,false));Ui.space(summary,5);
        summary.addView(Ui.text(this,validNights==0?"Henüz kayıt yok":(minutesTotal/validNights/60)+" sa "+(minutesTotal/validNights%60)+" dk",23,Ui.WHITE,true));
        Ui.space(summary,7);
        int[] sleepHours=new int[7];
        for(int i=0;i<Math.min(7,sleepHistory.length());i++){
            JSONObject n=sleepHistory.optJSONObject(i);if(n==null)continue;
            try{int mm=minutes(n.optString("wake","07:00"))-minutes(n.optString("sleep","23:00"));
                if(mm<0)mm+=1440;sleepHours[6-i]=Math.min(12,mm/60);}catch(Exception ignored){}
        }
        summary.addView(new SleepWeekChart(this,sleepHours),new LinearLayout.LayoutParams(-1,Ui.dp(this,83)));
        screen.addView(summary,Ui.matchMargins(this,13));
        LinearLayout recentHeader=Ui.row(this);
        recentHeader.addView(Ui.text(this,"Son Kayıtlar",19,Ui.WHITE,true),new LinearLayout.LayoutParams(0,-2,1));
        TextView viewAll=Ui.text(this,"Tümünü Gör",12,Ui.MUTED,false);
        viewAll.setPadding(Ui.dp(this,8),Ui.dp(this,5),Ui.dp(this,8),Ui.dp(this,5));
        viewAll.setBackground(Ui.shape(Ui.SECONDARY,18,this));recentHeader.addView(viewAll);
        viewAll.setOnClickListener(v->Toast.makeText(this,I18n.tr(this,"Mevcut kayıtlar aşağıda listeleniyor."),Toast.LENGTH_SHORT).show());
        screen.addView(recentHeader,Ui.matchMargins(this,10));
        JSONArray sessions=SleepRecordStore.sessions(this);
        if(sessions.length()==0){
            sectionCard("Henüz ses kaydı yok","Gece kaydını başlatınca tespit edilen ses olayları burada görünecek. "
                    +"Kabus notları da bu bölümde tutulacak.");
        }
        SimpleDateFormat df=new SimpleDateFormat("dd MMM yyyy  HH:mm",I18n.locale(this));
        for(int i=0;i<Math.min(20,sessions.length());i++){
            JSONObject session=sessions.optJSONObject(i);if(session==null)continue;
            long id=session.optLong("id"),from=session.optLong("started"),to=session.optLong("ended");
            JSONArray events=session.optJSONArray("events");
            int count=events==null?0:events.length();
            LinearLayout card=Ui.card(this);
            card.addView(Ui.text(this,df.format(new Date(from)),18,Ui.WHITE,true));Ui.space(card,5);
            String length=to>from?String.format(I18n.locale(this)," • %d sa %d dk",(to-from)/3600000,(to-from)%3600000/60000):"";
            card.addView(Ui.text(this,("recording".equals(session.optString("status"))?"● Kayıt sürüyor":
                     "manual".equals(session.optString("status"))?"Kabus notu":"Gece kaydı")
                    +length+" • "+count+" olay",13,Ui.MUTED,false));
            if(events!=null && to>from && !"recording".equals(session.optString("status"))
                && !"manual".equals(session.optString("status"))){
                Ui.space(card,12);
                card.addView(Ui.text(this,"GECE SES ZAMAN ÇİZELGESİ",12,Ui.PEACH,true));
                Ui.space(card,7);
                SleepTimelineView graph=new SleepTimelineView(this,from,to,events,(event)->{
                    String path=event.optString("file");
                    if(!path.isEmpty())playSleepClip(path);
                    else if(!event.optString("note").isEmpty())
                        new AlertDialog.Builder(this).setTitle(I18n.tr(this,"Kabus notu"))
                            .setMessage(event.optString("note")).setPositiveButton(I18n.tr(this,"Tamam"),null).show();
                });
                card.addView(graph,new LinearLayout.LayoutParams(-1,Ui.dp(this,218)));
                Ui.space(card,4);
                card.addView(Ui.text(this,"Noktaya dokunarak sesi dinle. Horlama/öksürük otomatik tahmindir; doğrulamak için dinle.",12,Ui.MUTED,false));
            }
            if(events!=null){
                for(int j=0;j<Math.min(35,events.length());j++){
                    JSONObject event=events.optJSONObject(j);if(event==null)continue;
                    Ui.space(card,9);
                    LinearLayout ev=Ui.column(this);
                    String type=event.optString("type","Ses olayı");
                    String when=new SimpleDateFormat("HH:mm:ss",I18n.locale(this)).format(new Date(event.optLong("at")));
                    ev.addView(Ui.text(this,type+"  •  "+when,14,Ui.WHITE,true));
                    String note=event.optString("note");
                    if(!note.isEmpty())ev.addView(Ui.text(this,note,13,Ui.MUTED,false));
                    String path=event.optString("file");
                    if(!path.isEmpty()){
                        LinearLayout controls=Ui.row(this);
                        Button play=Ui.button(this,"▶ Dinle",false);
                        controls.addView(play,new LinearLayout.LayoutParams(0,Ui.dp(this,46),1));
                        play.setOnClickListener(v->playSleepClip(path));
                        Button tag=Ui.button(this,"Etiketle",false);
                        LinearLayout.LayoutParams tagParams=new LinearLayout.LayoutParams(0,Ui.dp(this,46),1);
                        tagParams.leftMargin=Ui.dp(this,8);controls.addView(tag,tagParams);
                        tag.setOnClickListener(v->labelSleepEvent(id,event.optString("id"),type));
                        ev.addView(controls);
                    }
                    card.addView(ev);
                }
                if(events.length()>35)card.addView(Ui.text(this,"İlk 35 olay gösteriliyor.",12,Ui.MUTED,false));
            }
            Ui.space(card,10);
            if(!(running && id==SleepRecordStore.latestRecordingId(this))){
                Button delete=Ui.button(this,"Bu geceyi ve seslerini sil",false);
                card.addView(delete);delete.setOnClickListener(v->confirmDeleteSleep(id));
            }
            screen.addView(card,Ui.matchMargins(this,12));
        }
        // Recording controls stay available after the reference-styled recent events list.
        LinearLayout record=Ui.card(this);
        record.addView(Ui.text(this,"Gece ses kaydı",20,Ui.WHITE,true));Ui.space(record,7);
        record.addView(Ui.text(this,running?"● Mikrofon açık • Kayıt sürüyor":"Mikrofon kapalı • Kayıt başlatılmadı",
                15,running?Ui.GREEN:Ui.MUTED,true));Ui.space(record,8);
        record.addView(Ui.text(this,"Ses eşiğini aşan anlar kısa WAV olarak yalnızca cihazda saklanır. "
              +"Sesin ritmine göre olası horlama/öksürük işaretlenir; kesin tespit değildir. Kabuslar sadece kullanıcı tarafından bildirilir.",
              13,Ui.MUTED,false));Ui.space(record,12);
        Button toggle=Ui.button(this,running?"■  Gece kaydını durdur":"●  Gece kaydını başlat",!running);
        record.addView(toggle);
        toggle.setOnClickListener(v->{
            if(SleepAudioService.isRunning()){
                Intent stop=new Intent(this,SleepAudioService.class).setAction(SleepAudioService.STOP);
                startService(stop);Toast.makeText(this,I18n.tr(this,"Kayıt durduruluyor"),Toast.LENGTH_SHORT).show();
            }else if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},SLEEP_MIC_PERMISSION);
            }else startSleepRecording();
            section="sleep";render();
            new android.os.Handler(getMainLooper()).postDelayed(()->{
                if(!isFinishing() && "sleep".equals(section))render();
            },900);
        });
        Ui.space(record,11);
        Button nightmare=Ui.button(this,"+  Kabus kaydı ekle",false);record.addView(nightmare);
        nightmare.setOnClickListener(v->askNightmare());
        screen.addView(record,Ui.matchMargins(this,17));

        Ui.space(screen,11);
        screen.addView(Ui.text(this,"MANUEL UYKU GÜNLÜĞÜ",13,Ui.PEACH,true));Ui.space(screen,9);
        LinearLayout manual=Ui.card(this);
        manual.addView(Ui.text(this,"Yatma ve kalkma saati",18,Ui.WHITE,true));Ui.space(manual,7);
        manual.addView(Ui.text(this,"Uyku süresini kendin kaydet. Uyku evreleri ölçülmez.",13,Ui.MUTED,false));
        Ui.space(manual,10);
        Button bed=Ui.button(this,"Yatma saati: "+bedtime,false);manual.addView(bed,Ui.matchMargins(this,9));
        bed.setOnClickListener(v->pickTime(true));
        Button wake=Ui.button(this,"Kalkma saati: "+wakeTime,false);manual.addView(wake,Ui.matchMargins(this,12));
        wake.setOnClickListener(v->pickTime(false));
        Button save=Ui.button(this,"Uyku süresini kaydet",true);manual.addView(save);
        save.setOnClickListener(v->{AlarmRepository.recordSleep(this,bedtime,wakeTime);
            Toast.makeText(this,I18n.tr(this,"Uyku kaydedildi"),Toast.LENGTH_SHORT).show();render();});
        screen.addView(manual,Ui.matchMargins(this,14));
        JSONArray history=AlarmRepository.sleepHistory(this);
        for(int i=0;i<Math.min(20,history.length());i++){
            JSONObject o=history.optJSONObject(i);if(o==null)continue;
            String from=o.optString("sleep","23:00"),to=o.optString("wake","07:00");
            int duration=minutes(to)-minutes(from);if(duration<0)duration+=24*60;
            LinearLayout entry=Ui.card(this);
            entry.addView(Ui.text(this,String.format(I18n.locale(this),"%d sa %d dk",duration/60,duration%60),20,Ui.WHITE,true));
            entry.addView(Ui.text(this,from+" → "+to+"  ·  "+df.format(new Date(o.optLong("at"))),13,Ui.MUTED,false));
            screen.addView(entry,Ui.matchMargins(this,9));
        }
    }
    private void startSleepRecording(){
        try{
            Intent intent=new Intent(this,SleepAudioService.class).setAction(SleepAudioService.START);
            if(Build.VERSION.SDK_INT>=26)startForegroundService(intent);else startService(intent);
            Toast.makeText(this,I18n.tr(this,"Uyku kaydı başlatılıyor"),Toast.LENGTH_SHORT).show();
        }catch(Exception e){Toast.makeText(this,I18n.tr(this,"Mikrofon başlatılamadı: uygulama izinlerini kontrol et."),Toast.LENGTH_LONG).show();}
    }
    private void askNightmare(){
        final AlertDialog dialog=new AlertDialog.Builder(this).create();
        LinearLayout panel=Ui.column(this);panel.setPadding(Ui.dp(this,20),Ui.dp(this,19),Ui.dp(this,20),Ui.dp(this,18));
        panel.setBackground(Ui.shape(Ui.PANEL,22,this));
        TextView title=Ui.text(this,"Kabus kaydı",25,Ui.WHITE,true);
        panel.addView(title,Ui.matchMargins(this,12));
        TextView description=Ui.text(this,
            "Uyandığında hatırladığın kabusu kaydet. Mikrofon kabusları kesin olarak algılayamaz.",
            15,Ui.MUTED,false);
        description.setLineSpacing(Ui.dp(this,3),1f);
        panel.addView(description,Ui.matchMargins(this,16));
        final EditText note=new EditText(this);note.setHint(I18n.tr(this,"Kabus notu (isteğe bağlı)"));
        note.setTextSize(15);note.setSingleLine(false);note.setMinLines(2);
        note.setGravity(Gravity.TOP);note.setTextColor(Ui.WHITE);note.setHintTextColor(Ui.MUTED);
        note.setPadding(Ui.dp(this,13),Ui.dp(this,14),Ui.dp(this,13),Ui.dp(this,12));
        note.setBackground(Ui.stroked(Ui.SECONDARY,13,Ui.OUTLINE,this));
        panel.addView(note,Ui.matchMargins(this,10));
        // The remembered clock time is entered by the user; audio cannot date a dream.
        final long[] nightmareAt={System.currentTimeMillis()};
        final long[] referenceNight={0L,0L};
        JSONArray recentNights=SleepRecordStore.sessions(this);
        for(int k=0;k<recentNights.length();k++){
            JSONObject night=recentNights.optJSONObject(k);if(night==null)continue;
            long from=night.optLong("started"),to=night.optLong("ended");
            if(from>0 && System.currentTimeMillis()-from<48L*3600000){
                referenceNight[0]=from;
                referenceNight[1]=to>from?to:System.currentTimeMillis();
                break;
            }
        }
        final Button eventTime=Ui.button(this,"Kabus saati: Şimdi (değiştir)",false);
        panel.addView(eventTime,Ui.matchMargins(this,12));
        eventTime.setOnClickListener(v->{
            Calendar selected=Calendar.getInstance();selected.setTimeInMillis(nightmareAt[0]);
            new TimePickerDialog(this,(picker,hour,minute)->{
                long result=resolveSleepClockTime(hour,minute,referenceNight[0],referenceNight[1]);
                nightmareAt[0]=result;
                eventTime.setText(I18n.tr(this,"Kabus saati: "+new SimpleDateFormat("dd MMM HH:mm",I18n.locale(this)).format(new Date(result))));
            },selected.get(Calendar.HOUR_OF_DAY),selected.get(Calendar.MINUTE),true).show();
        });
        LinearLayout actions=Ui.row(this);
        Button cancel=Ui.button(this,"Vazgeç",false);
        Button save=Ui.button(this,"Kaydet",true);
        LinearLayout.LayoutParams cancelParams=new LinearLayout.LayoutParams(0,Ui.dp(this,48),1);
        cancelParams.rightMargin=Ui.dp(this,9);
        actions.addView(cancel,cancelParams);
        actions.addView(save,new LinearLayout.LayoutParams(0,Ui.dp(this,48),1));
        panel.addView(actions);
        cancel.setOnClickListener(v->dialog.dismiss());
        save.setOnClickListener(v->{
            SleepRecordStore.addManualNightmare(this,note.getText().toString().trim(),nightmareAt[0]);
            dialog.dismiss();render();
        });
        dialog.setView(panel);dialog.show();
        if(dialog.getWindow()!=null){
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE|
                WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
            dialog.getWindow().setLayout(getResources().getDisplayMetrics().widthPixels-Ui.dp(this,38),-2);
        }
    }
    /** Pick a clock time inside the most recent night when possible (cross-midnight safe). */
    private long resolveSleepClockTime(int hour,int minute,long nightStart,long nightEnd){
        long now=System.currentTimeMillis(),best=-1;
        if(nightStart>0){
            Calendar day=Calendar.getInstance();day.setTimeInMillis(nightStart);
            day.set(Calendar.HOUR_OF_DAY,hour);day.set(Calendar.MINUTE,minute);
            day.set(Calendar.SECOND,0);day.set(Calendar.MILLISECOND,0);
            for(int offset=0;offset<3;offset++){
                long candidate=day.getTimeInMillis();
                if(candidate>=nightStart && candidate<=nightEnd && candidate<=now){best=candidate;break;}
                day.add(Calendar.DATE,1);
            }
        }
        if(best!=-1)return best;
        Calendar c=Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY,hour);c.set(Calendar.MINUTE,minute);
        c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);
        if(c.getTimeInMillis()>now)c.add(Calendar.DATE,-1);
        return c.getTimeInMillis();
    }
    private void labelSleepEvent(long id,String eventId,String current){
        String[] labels={"Horlama (kullanıcı onayı)","Öksürük (kullanıcı onayı)","Kabusla ilişkili ses (kullanıcı onayı)","Uykuda konuşma","Diğer ses","Ses olayı","Olası horlama","Olası öksürük"};
        new AlertDialog.Builder(this).setTitle(I18n.tr(this,"Dinlediğin sesi etiketle"))
           .setSingleChoiceItems(labels,java.util.Arrays.asList(labels).indexOf(current),(d,index)->{
                SleepRecordStore.labelEvent(this,id,eventId,labels[index]);d.dismiss();render();
           }).setNegativeButton(I18n.tr(this,"Vazgeç"),null).show();
    }
    private void playSleepClip(String path){
        try{
            if(sleepPlayer!=null){sleepPlayer.release();sleepPlayer=null;}
            File clip=new File(path);
            File folder=SleepRecordStore.recordingsDirectory(this).getCanonicalFile();
            if(!folder.equals(clip.getCanonicalFile().getParentFile())||!clip.isFile())throw new Exception("Dosya bulunamadı");
            sleepPlayer=new MediaPlayer();sleepPlayer.setDataSource(clip.getAbsolutePath());
            sleepPlayer.setOnCompletionListener(mp->{mp.release();if(sleepPlayer==mp)sleepPlayer=null;});
            sleepPlayer.prepare();sleepPlayer.start();
        }catch(Exception e){Toast.makeText(this,I18n.tr(this,"Ses dosyası oynatılamadı"),Toast.LENGTH_LONG).show();}
    }
    private void confirmDeleteSleep(long id){
        new AlertDialog.Builder(this).setTitle(I18n.tr(this,"Uyku kaydını sil"))
           .setMessage(I18n.tr(this,"Bu gecenin kayıtları ve ses dosyaları cihazdan silinecek."))
           .setNegativeButton(I18n.tr(this,"Vazgeç"),null)
           .setPositiveButton(I18n.tr(this,"Sil"),(d,w)->{if(sleepPlayer!=null){sleepPlayer.release();sleepPlayer=null;}
                SleepRecordStore.deleteSession(this,id);render();}).show();
    }
    private int minutes(String hhmm){String[] p=hhmm.split(":");return Integer.parseInt(p[0])*60+Integer.parseInt(p[1]);}
    private void pickTime(boolean bed){
        String old=bed?bedtime:wakeTime;String[] p=old.split(":");
        TimePickerDialog dialog=new TimePickerDialog(this,(view,h,m)->{
            if(bed)bedtime=String.format(Locale.ROOT,"%02d:%02d",h,m);
            else wakeTime=String.format(Locale.ROOT,"%02d:%02d",h,m);render();
        },Integer.parseInt(p[0]),Integer.parseInt(p[1]),true);dialog.show();
    }
    private void showProfile(){
        Achievements a=Achievements.from(AlarmRepository.history(this));
        LinearLayout user=Ui.card(this);
        LinearLayout userRow=Ui.row(this);
        FrameLayout avatar=new FrameLayout(this);
        avatar.setBackground(Ui.shape(Ui.SECONDARY,50,this));
        ReferenceIconView avatarIcon=new ReferenceIconView(this,"person",0xFF101010);
        avatar.addView(avatarIcon,new FrameLayout.LayoutParams(Ui.dp(this,33),Ui.dp(this,33),Gravity.CENTER));
        userRow.addView(avatar,new LinearLayout.LayoutParams(Ui.dp(this,54),Ui.dp(this,54)));
        Ui.spaceHoriz(userRow,14);LinearLayout data=Ui.column(this);
        data.addView(Ui.text(this,"Kullanıcı",19,Ui.WHITE,true));Ui.space(data,3);
        data.addView(Ui.text(this,"🔥 "+a.streak+" günlük seri",12,Ui.MUTED,false));
        userRow.addView(data);user.addView(userRow);screen.addView(user,Ui.matchMargins(this,13));
        LinearLayout menu=Ui.column(this);menu.setBackground(Ui.shape(Ui.PANEL,18,this));
        profileAction(menu,"badge","Başarılar","Rozetlerini gör",()->{section="milestones";render();});
        profileAction(menu,"tasks","Görev Geçmişi","Tamamladığın görevler",()->{section="insights";render();});
        profileAction(menu,"settings","Ayarlar","Uygulama ayarları",()->{section="settings";render();});
        profileAction(menu,"help","Yardım ve Destek","Sorular ve geri bildirim",()->startActivity(new Intent(this,DeviceDiagnosticsActivity.class)));
        profileAction(menu,"info","Hakkında","Mission Alarm Veykano v1.12",()->new AlertDialog.Builder(this).setTitle(I18n.tr(this,"Mission Alarm Veykano 1.12"))
            .setMessage(I18n.tr(this,"Referans uyumlu arayüz. Alarm, uyku ve kamera görevleri cihaz üzerinde çalışır."))
            .setPositiveButton(I18n.tr(this,"Tamam"),null).show());
        screen.addView(menu,Ui.matchMargins(this,12));
        // Existing sleep route remains available without crowding the reference view.
        TextView sleep=Ui.text(this,"Uyku Analizi  ›",13,Ui.MUTED,true);
        screen.addView(sleep);sleep.setOnClickListener(v->{section="sleep";render();});
    }
    private void profileAction(LinearLayout menu,String glyph,String name,String detail,Runnable action){
        LinearLayout row=Ui.row(this);row.setPadding(Ui.dp(this,14),Ui.dp(this,13),Ui.dp(this,12),Ui.dp(this,13));
        ReferenceIconView icon=new ReferenceIconView(this,glyph,0xFF151515);
        row.addView(icon,new LinearLayout.LayoutParams(Ui.dp(this,26),Ui.dp(this,26)));
        Ui.spaceHoriz(row,12);
        LinearLayout labels=Ui.column(this);labels.addView(Ui.text(this,name,14,Ui.WHITE,true));
        Ui.space(labels,2);labels.addView(Ui.text(this,detail,11,Ui.MUTED,false));
        row.addView(labels,new LinearLayout.LayoutParams(0,-2,1));
        row.addView(Ui.text(this,"›",24,Ui.MUTED,false));
        menu.addView(row);
        View divider=new View(this);divider.setBackgroundColor(Ui.OUTLINE);
        LinearLayout.LayoutParams dl=new LinearLayout.LayoutParams(-1,Ui.dp(this,1));
        dl.leftMargin=Ui.dp(this,14);dl.rightMargin=Ui.dp(this,14);menu.addView(divider,dl);
        row.setOnClickListener(v->action.run());
    }
    private void showSettings(){
        LinearLayout theme=Ui.card(this);
        theme.addView(Ui.text(this,"🎨 Tema",19,Ui.WHITE,true));Ui.space(theme,5);
        theme.addView(Ui.text(this,"Seçili: "+AppTheme.current(this).title+"  ›",14,Ui.MUTED,false));
        theme.setOnClickListener(v->startActivity(new Intent(this,ThemePickerActivity.class)));
        screen.addView(theme,Ui.matchMargins(this,12));
        Button sleepJournal=Ui.button(this,"Uyku Kayıtları",false);screen.addView(sleepJournal,Ui.matchMargins(this,14));
        sleepJournal.setOnClickListener(v->{section="sleep";render();});
        sectionCard("Alarm ve bildirim izinleri","Kesin zamanlı alarm, bildirim ve kilit ekranı erişimini kontrol et.");
        AlarmManager alarmManager=(AlarmManager)getSystemService(ALARM_SERVICE);
        boolean exact=alarmManager!=null && (Build.VERSION.SDK_INT<31 || alarmManager.canScheduleExactAlarms());
        screen.addView(Ui.text(this,exact?"✓  Kesin alarm izni kullanılabilir":"⚠  Kesin alarm izni kapalı",14,exact?Ui.GREEN:Ui.PEACH,true));
        if(!exact && Build.VERSION.SDK_INT>=31){
            Button exactBtn=Ui.button(this,"Kesin alarm iznini aç",false);
            screen.addView(exactBtn,Ui.matchMargins(this,12));
            exactBtn.setOnClickListener(v->{try{
                Intent i=new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                i.setData(android.net.Uri.parse("package:"+getPackageName()));startActivity(i);
            }catch(Exception e){Toast.makeText(this,I18n.tr(this,"Uygulama ayarlarından alarm iznini aç."),Toast.LENGTH_LONG).show();}});
        }
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
            Button notif=Ui.button(this,"Bildirim izni ver",false);screen.addView(notif,Ui.matchMargins(this,10));
            notif.setOnClickListener(v->requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},100));
        }
        Button sys=Ui.button(this,"Uygulama ayarlarını aç",true);screen.addView(sys,Ui.matchMargins(this,12));
        sys.setOnClickListener(v->{Intent i=new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            i.setData(android.net.Uri.parse("package:"+getPackageName()));startActivity(i);});
        if(Build.VERSION.SDK_INT>=34){
            NotificationManager manager=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            if(manager!=null && !manager.canUseFullScreenIntent()){
                TextView warn=Ui.text(this,"Kilit ekranında tam ekran alarm izni kapalı.",14,Ui.PEACH,true);screen.addView(warn);
                Button full=Ui.button(this,"Tam ekran alarm iznini aç",false);screen.addView(full,Ui.matchMargins(this,12));
                full.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT)
                    .setData(android.net.Uri.parse("package:"+getPackageName()))));
            }
        }
        screen.addView(Ui.text(this,"App language",13,Ui.PEACH,true));
        Button changeLanguage=Ui.button(this,"🌐  "+LanguageCatalog.label(I18n.selected(this))+"  ›",false);
        screen.addView(changeLanguage,Ui.matchMargins(this,15));
        changeLanguage.setOnClickListener(v->showLanguagePicker(false));
        Button phone=Ui.button(this,"Telefon uygunluk kontrolü / Phone check",false);
        screen.addView(phone,Ui.matchMargins(this,12));
        phone.setOnClickListener(v->startActivity(new Intent(this,DeviceDiagnosticsActivity.class)));
        sectionCard("Gizlilik","Alarm ve uyku kayıtları cihazda tutulur. Gece ses kaydı yalnızca mikrofon izniyle başlatılır ve bildirimden durdurulabilir. Ses dosyaları paylaşılmaz.");
        Button pro=Ui.button(this,"Pro seçeneklerini incele",false);screen.addView(pro,Ui.matchMargins(this,12));
        pro.setOnClickListener(v->startActivity(new Intent(this,ProActivity.class)));
        sectionCard("Sürüm","1.12.0 • Verify alarms, camera missions and translations on a device.");
    }
    private void sectionCard(String title,String details){
        LinearLayout card=Ui.card(this);card.addView(Ui.text(this,title,18,Ui.WHITE,true));Ui.space(card,7);
        card.addView(Ui.text(this,details,14,Ui.MUTED,false));screen.addView(card,Ui.matchMargins(this,12));
    }
}
