package com.wakemission.alarm;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;

/** Private, on-device sleep audio sessions. No microphone data is uploaded. */
public final class SleepRecordStore {
    private static final String PREF = "wake_mission_sleep_audio_v1";
    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }
    private static JSONArray read(Context c) {
        try { return new JSONArray(prefs(c).getString("sessions", "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }
    public static synchronized JSONArray sessions(Context c) { return read(c); }
    private static void save(Context c, JSONArray a) { prefs(c).edit().putString("sessions", a.toString()).commit(); }

    public static synchronized long begin(Context c) {
        long id = System.currentTimeMillis();
        JSONArray old = read(c), out = new JSONArray();
        JSONObject session = new JSONObject();
        try {
            session.put("id", id); session.put("started", id); session.put("ended", 0L);
            session.put("status", "recording"); session.put("events", new JSONArray());
        } catch (Exception ignored) {}
        out.put(session);
        for (int i=0; i<old.length(); i++) out.put(old.opt(i));
        save(c, out);
        return id;
    }
    public static synchronized long latestRecordingId(Context c) {
        JSONArray a=read(c);
        for (int i=0;i<a.length();i++) {
            JSONObject s=a.optJSONObject(i);
            if(s!=null && "recording".equals(s.optString("status"))) return s.optLong("id");
        }
        return 0L;
    }
    public static synchronized void finish(Context c,long sessionId) {
        JSONArray a=read(c);
        for(int i=0;i<a.length();i++) {
            JSONObject s=a.optJSONObject(i);
            if(s!=null && s.optLong("id")==sessionId) {
                try{s.put("ended",System.currentTimeMillis());s.put("status","finished");}catch(Exception ignored){}
                break;
            }
        }
        save(c,a);
    }
    // Recover an interrupted session if the Android process was killed during recording.
    public static synchronized void recoverInterrupted(Context c,boolean running) {
        if(running)return;
        JSONArray a=read(c);boolean changed=false;
        for(int i=0;i<a.length();i++) {
            JSONObject s=a.optJSONObject(i);
            if(s!=null && "recording".equals(s.optString("status"))) {
                try{
                    long ended=s.optLong("started");
                    JSONArray ev=s.optJSONArray("events");
                    if(ev!=null && ev.length()>0){
                        JSONObject last=ev.optJSONObject(ev.length()-1);
                        if(last!=null)ended=Math.max(ended,last.optLong("at"));
                    }
                    s.put("status","interrupted");s.put("ended",ended);changed=true;
                }catch(Exception ignored){}
            }
        }
        if(changed)save(c,a);
    }
    public static synchronized void addEvent(Context c,long sessionId,String type,String path,long at,String note) {
        JSONArray a=read(c);
        for(int i=0;i<a.length();i++) {
            JSONObject s=a.optJSONObject(i);
            if(s==null || s.optLong("id")!=sessionId)continue;
            JSONArray events=s.optJSONArray("events"); if(events==null)events=new JSONArray();
            JSONObject e=new JSONObject();
            try {
                e.put("id",System.nanoTime());e.put("type",type);
                e.put("at",at);e.put("file",path==null?"":path);e.put("note",note==null?"":note);
                events.put(e);s.put("events",events);
            } catch(Exception ignored){}
            save(c,a);return;
        }
    }
    public static synchronized void addManualNightmare(Context c,String note) {
        addManualNightmare(c,note,System.currentTimeMillis());
    }
    /** A nightmare is a user-reported event, never automatically inferred from microphone audio. */
    public static synchronized void addManualNightmare(Context c,String note,long at) {
        long now=System.currentTimeMillis();
        at=Math.min(at,now);
        JSONArray sessions=read(c);
        for(int i=0;i<sessions.length();i++) {
            JSONObject s=sessions.optJSONObject(i);if(s==null)continue;
            long start=s.optLong("started"), end=s.optLong("ended");
            if(at>=start && ("recording".equals(s.optString("status")) || (end>start && at<=end))) {
                addEvent(c,s.optLong("id"),"Kabus (kullanıcı kaydı)","",at,note);return;
            }
        }
        long id=begin(c);
        addEvent(c,id,"Kabus (kullanıcı kaydı)","",at,note);
        finish(c,id);
        JSONArray nights=read(c);
        for(int i=0;i<nights.length();i++){
            JSONObject n=nights.optJSONObject(i);
            if(n!=null && n.optLong("id")==id){
                try{n.put("status","manual");}catch(Exception ignored){}
                break;
            }
        }
        save(c,nights);
    }
    public static synchronized void labelEvent(Context c,long sessionId,String eventId,String type) {
        JSONArray a=read(c);
        for(int i=0;i<a.length();i++) {
            JSONObject s=a.optJSONObject(i);
            if(s==null||s.optLong("id")!=sessionId)continue;
            JSONArray events=s.optJSONArray("events");if(events==null)return;
            for(int j=0;j<events.length();j++) {
                JSONObject e=events.optJSONObject(j);
                if(e!=null && eventId.equals(e.optString("id"))) {
                    try{e.put("type",type);}catch(Exception ignored){}
                    save(c,a);return;
                }
            }
        }
    }
    public static synchronized void deleteSession(Context c,long id) {
        JSONArray a=read(c),out=new JSONArray();
        for(int i=0;i<a.length();i++) {
            JSONObject s=a.optJSONObject(i);if(s==null)continue;
            if(s.optLong("id")!=id){out.put(s);continue;}
            JSONArray ev=s.optJSONArray("events");if(ev==null)continue;
            for(int j=0;j<ev.length();j++){
                JSONObject e=ev.optJSONObject(j);
                if(e!=null)deleteAudio(c,e.optString("file"));
            }
        }
        save(c,out);
    }
    public static File recordingsDirectory(Context c) {
        File f=new File(c.getFilesDir(),"sleep_recordings");
        if(!f.exists() && !f.mkdirs())throw new IllegalStateException("Kayıt klasörü oluşturulamadı");
        return f;
    }
    public static void deleteAudio(Context c,String path){
        if(path==null||path.isEmpty())return;
        try {
            File directory=recordingsDirectory(c).getCanonicalFile();
            File file=new File(path).getCanonicalFile();
            if(directory.equals(file.getParentFile()) && file.isFile())file.delete();
        }catch(Exception ignored){}
    }
    private SleepRecordStore(){}
}
