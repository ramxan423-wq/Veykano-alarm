package com.wakemission.alarm;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.Rect;
import android.view.View;
import com.google.mlkit.vision.pose.Pose;
import com.google.mlkit.vision.pose.PoseLandmark;

/** Transparent live on-device pose visualization. No image is stored or uploaded.
 * Source coordinates are rotated into the detector's upright orientation and
 * transformed to the PreviewView's FILL_CENTER viewport, including front mirroring.
 */
public final class PoseOverlayView extends View {
    private final Paint line=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dot=new Paint(Paint.ANTI_ALIAS_FLAG);
    private Pose pose;
    private int imageWidth=1,imageHeight=1;
    private boolean mirror,squat;
    private final Rect activeCrop=new Rect(0,0,1,1);
    private static final int[][] BONES={
        {PoseLandmark.LEFT_SHOULDER,PoseLandmark.RIGHT_SHOULDER},
        {PoseLandmark.LEFT_SHOULDER,PoseLandmark.LEFT_ELBOW},
        {PoseLandmark.LEFT_ELBOW,PoseLandmark.LEFT_WRIST},
        {PoseLandmark.RIGHT_SHOULDER,PoseLandmark.RIGHT_ELBOW},
        {PoseLandmark.RIGHT_ELBOW,PoseLandmark.RIGHT_WRIST},
        {PoseLandmark.LEFT_SHOULDER,PoseLandmark.LEFT_HIP},
        {PoseLandmark.RIGHT_SHOULDER,PoseLandmark.RIGHT_HIP},
        {PoseLandmark.LEFT_HIP,PoseLandmark.RIGHT_HIP},
        {PoseLandmark.LEFT_HIP,PoseLandmark.LEFT_KNEE},
        {PoseLandmark.RIGHT_HIP,PoseLandmark.RIGHT_KNEE},
        {PoseLandmark.LEFT_KNEE,PoseLandmark.LEFT_ANKLE},
        {PoseLandmark.RIGHT_KNEE,PoseLandmark.RIGHT_ANKLE}};
    public PoseOverlayView(Context context){super(context);
        setLayerType(View.LAYER_TYPE_SOFTWARE,null);
        line.setColor(Color.WHITE);line.setStrokeWidth(Ui.dp(context,2));line.setStrokeCap(Paint.Cap.ROUND);
        line.setStyle(Paint.Style.STROKE);line.setShadowLayer(Ui.dp(context,2),0,0,0xAA1D1D1D);
        dot.setColor(Color.WHITE);dot.setStyle(Paint.Style.FILL);
        dot.setShadowLayer(Ui.dp(context,2),0,0,0x991D1D1D);
    }
    public void update(Pose newest,int uprightWidth,int uprightHeight,boolean mirrored,Rect rotatedCrop,boolean isSquat){
        pose=newest;imageWidth=Math.max(1,uprightWidth);imageHeight=Math.max(1,uprightHeight);
        mirror=mirrored;squat=isSquat;
        activeCrop.set(rotatedCrop==null?new Rect(0,0,imageWidth,imageHeight):rotatedCrop);
        if(activeCrop.width()<=0||activeCrop.height()<=0)activeCrop.set(0,0,imageWidth,imageHeight);
        invalidate();
    }
    public void clear(){pose=null;invalidate();}
    @Override protected void onDraw(Canvas c){super.onDraw(c);if(pose==null)return;
        // The on-screen camera preview is center-cropped to fill the same rectangle.
        float scale=Math.max(getWidth()/(float)activeCrop.width(),getHeight()/(float)activeCrop.height());
        float ox=(getWidth()-activeCrop.width()*scale)*.5f,oy=(getHeight()-activeCrop.height()*scale)*.5f;
        for(int i=0;i<BONES.length;i++){
            if(!squat && i>=5)break; // reference push-up: shoulders and both arms only
            int[] bone=BONES[i];
            PoseLandmark a=visible(bone[0]),b=visible(bone[1]);
            if(a==null||b==null)continue;
            PointF pa=point(a.getPosition(),scale,ox,oy),pb=point(b.getPosition(),scale,ox,oy);
            c.drawLine(pa.x,pa.y,pb.x,pb.y,line);
        }
        int[] points=squat?new int[]{PoseLandmark.LEFT_SHOULDER,PoseLandmark.RIGHT_SHOULDER,
            PoseLandmark.LEFT_ELBOW,PoseLandmark.RIGHT_ELBOW,PoseLandmark.LEFT_WRIST,PoseLandmark.RIGHT_WRIST,
            PoseLandmark.LEFT_HIP,PoseLandmark.RIGHT_HIP,PoseLandmark.LEFT_KNEE,PoseLandmark.RIGHT_KNEE,
            PoseLandmark.LEFT_ANKLE,PoseLandmark.RIGHT_ANKLE}:
            new int[]{PoseLandmark.LEFT_SHOULDER,PoseLandmark.RIGHT_SHOULDER,
                PoseLandmark.LEFT_ELBOW,PoseLandmark.RIGHT_ELBOW,PoseLandmark.LEFT_WRIST,PoseLandmark.RIGHT_WRIST};
        for(int id:points){
            PoseLandmark lm=visible(id);if(lm==null)continue;
            PointF p=point(lm.getPosition(),scale,ox,oy);
            c.drawCircle(p.x,p.y,Ui.dp(getContext(),3),dot);
        }
        if(!squat){
            // The source photo has one extra white marker halfway down each forearm.
            for(int side=0;side<2;side++){
                PoseLandmark elbow=visible(side==0?PoseLandmark.LEFT_ELBOW:PoseLandmark.RIGHT_ELBOW);
                PoseLandmark wrist=visible(side==0?PoseLandmark.LEFT_WRIST:PoseLandmark.RIGHT_WRIST);
                if(elbow==null||wrist==null)continue;
                PointF a=point(elbow.getPosition(),scale,ox,oy),b=point(wrist.getPosition(),scale,ox,oy);
                c.drawCircle((a.x+b.x)*.5f,(a.y+b.y)*.5f,Ui.dp(getContext(),3),dot);
            }
        }
    }
    private PoseLandmark visible(int id){PoseLandmark x=pose.getPoseLandmark(id);
        return x!=null&&x.getInFrameLikelihood()>=.52f?x:null;
    }
    private PointF point(PointF p,float s,float ox,float oy){
        float px=mirror?activeCrop.left+activeCrop.right-p.x:p.x;
        return new PointF(ox+(px-activeCrop.left)*s,oy+(p.y-activeCrop.top)*s);
    }
}
