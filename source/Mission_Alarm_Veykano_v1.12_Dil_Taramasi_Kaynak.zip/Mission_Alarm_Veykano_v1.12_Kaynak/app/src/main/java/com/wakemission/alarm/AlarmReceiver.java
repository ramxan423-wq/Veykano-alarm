package com.wakemission.alarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public final class AlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c,Intent intent){
        int id=intent.getIntExtra("alarm_id",-1);
        AlarmItem a=AlarmRepository.get(c,id);if(a==null || !a.enabled)return;
        // Repeating alarms retain tomorrow's occurrence. A snooze must not replace it.
        if(!"com.wakemission.alarm.FIRE_SNOOZE".equals(intent.getAction()) && a.daysMask!=0)
            AlarmScheduler.schedule(c,a);
        Intent service=new Intent(c,AlarmRingService.class).putExtra("alarm_id",id);
        try{if(Build.VERSION.SDK_INT>=26)c.startForegroundService(service);else c.startService(service);}
        catch(Exception e){
            // Keep a recoverable signal if OS refused background start.
            AlarmRepository.record(c,"Çalma servisi engellendi",a);
        }
    }
}
