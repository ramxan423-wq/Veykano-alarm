package com.wakemission.alarm;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.*;
import java.text.SimpleDateFormat;

/** Pure snapshot of local wake-up data. No cloud account. */
public final class Achievements {
    public final int completed,stopped,snoozes,streak,underMinute;
    public final int[] lastSeven;
    private Achievements(int a,int b,int c,int d,int e,int[] days){completed=a;stopped=b;snoozes=c;streak=d;underMinute=e;lastSeven=days;}
    public static Achievements from(JSONArray history){
        int completed=0,stopped=0,snoozes=0,under=0;
        SimpleDateFormat fmt=new SimpleDateFormat("yyyy-MM-dd",Locale.ROOT);
        Set<String> successDays=new HashSet<>();int[] seven=new int[7];
        Calendar base=Calendar.getInstance();base.set(Calendar.HOUR_OF_DAY,0);base.set(Calendar.MINUTE,0);base.set(Calendar.SECOND,0);base.set(Calendar.MILLISECOND,0);
        long midnight=base.getTimeInMillis();
        for(int i=0;i<history.length();i++){
            JSONObject h=history.optJSONObject(i);if(h==null)continue;
            String value=h.optString("result","");long when=h.optLong("time",0);
            if("Görev tamamlandı".equals(value)){
                completed++;successDays.add(fmt.format(new Date(when)));
                if(h.optLong("duration_ms",Long.MAX_VALUE)<60_000)under++;
                long dayDiff=(midnight-when)/(24*3600_000L);
                if(when>=midnight)dayDiff=0;
                if(dayDiff>=0&&dayDiff<7)seven[6-(int)dayDiff]++;
            }else if("Ertelendi".equals(value))snoozes++;
            else stopped++;
        }
        int streak=0;Calendar day=Calendar.getInstance();
        if(!successDays.contains(fmt.format(day.getTime())))day.add(Calendar.DAY_OF_YEAR,-1);
        for(int i=0;i<365;i++){
            if(!successDays.contains(fmt.format(day.getTime())))break;
            streak++;day.add(Calendar.DAY_OF_YEAR,-1);
        }
        return new Achievements(completed,stopped,snoozes,streak,under,seven);
    }
    public String badges(){
        StringBuilder b=new StringBuilder();
        if(completed>=1)b.append("🥇 İlk Uyanış   ");
        if(completed>=10)b.append("🏅 10 Görev   ");
        if(streak>=3)b.append("🔥 3 Gün Seri   ");
        if(streak>=7)b.append("🏆 7 Gün Seri   ");
        if(underMinute>=5)b.append("⚡ Hızlı Uyanan");
        return b.length()==0?"İlk görevini tamamlayınca rozet kazanacaksın.":b.toString();
    }
}
