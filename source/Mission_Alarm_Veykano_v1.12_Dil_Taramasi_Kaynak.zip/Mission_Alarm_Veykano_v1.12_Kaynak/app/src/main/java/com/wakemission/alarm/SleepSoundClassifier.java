package com.wakemission.alarm;

import java.util.ArrayList;
import java.util.Arrays;

/** Best-effort signal-shape cues only. Never reports a definitive diagnosis. */
public final class SleepSoundClassifier {
    private SleepSoundClassifier() {}

    /** Samples are 100-ms PCM16 blocks at 16 kHz; output is a tentative label. */
    public static String classify(ArrayList<short[]> frames) {
        if(frames==null || frames.size()<10) return "Diğer ses";
        int n=frames.size();
        double[] rms=new double[n], zcr=new double[n];
        for(int i=0;i<n;i++) {
            short[] a=frames.get(i);
            if(a==null || a.length==0)continue;
            double energy=0;int crosses=0;
            short last=a[0];
            for(short s:a) {
                energy+=(double)s*s;
                if((s>=0)!=(last>=0))crosses++;
                last=s;
            }
            rms[i]=Math.sqrt(energy/a.length);zcr[i]=crosses/(double)a.length;
        }
        double[] sorted=rms.clone();Arrays.sort(sorted);
        double median=sorted[n/2], max=sorted[n-1];
        if(max<500)return "Diğer ses";
        double threshold=Math.max(600, Math.max(median*1.9,max*.23));
        int bursts=0, activeFrames=0, current=0, longest=0;
        double activeZcr=0, maxRms=0;
        for(int i=0;i<n;i++) {
            if(rms[i]>threshold){
                current++;activeFrames++;activeZcr+=zcr[i];maxRms=Math.max(maxRms,rms[i]);
            }else if(current>0){
                if(current>=2){bursts++;longest=Math.max(longest,current);}
                current=0;
            }
        }
        if(current>=2){bursts++;longest=Math.max(longest,current);}
        if(activeFrames<3)return "Diğer ses";
        double meanCross=activeZcr/activeFrames;
        // One brief, sharp, broadband burst is more cough-like; several slower
        // low-frequency recurring bursts are more snore-like. Voices can overlap.
        if(bursts>=1 && bursts<=3 && longest<=9 && maxRms>Math.max(1400,median*3.2) && meanCross>.11)
            return "Olası öksürük";
        if(bursts>=2 && bursts<=9 && longest>=3 && meanCross<.13)
            return "Olası horlama";
        return "Diğer ses";
    }
}
