package com.wakemission.alarm;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

/** White round pause/play control with black vector bars, matching the reference. */
public final class ReferenceExerciseControl extends View {
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private boolean paused;
    public ReferenceExerciseControl(Context c){super(c);setClickable(true);setFocusable(true);
        setContentDescription("Hareket takibini duraklat");}
    public void setPaused(boolean next){paused=next;
        setContentDescription(paused?"Hareket takibini sürdür":"Hareket takibini duraklat");invalidate();}
    @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);
        float s=Math.min(getWidth(),getHeight());
        float cx=getWidth()/2f,cy=getHeight()/2f;
        paint.setStyle(Paint.Style.FILL);paint.setColor(0xFFFFFFFF);
        canvas.drawCircle(cx,cy,s*.5f,paint);
        paint.setColor(0xFF111111);
        if(paused){android.graphics.Path triangle=new android.graphics.Path();
            triangle.moveTo(cx-s*.105f,cy-s*.185f);
            triangle.lineTo(cx+s*.185f,cy);triangle.lineTo(cx-s*.105f,cy+s*.185f);
            triangle.close();canvas.drawPath(triangle,paint);
        }else{
            float w=s*.105f,h=s*.36f,gap=s*.055f;
            canvas.drawRoundRect(cx-gap/2-w,cy-h/2,cx-gap/2,cy+h/2,w*.22f,w*.22f,paint);
            canvas.drawRoundRect(cx+gap/2,cy-h/2,cx+gap/2+w,cy+h/2,w*.22f,w*.22f,paint);
        }
    }
}
