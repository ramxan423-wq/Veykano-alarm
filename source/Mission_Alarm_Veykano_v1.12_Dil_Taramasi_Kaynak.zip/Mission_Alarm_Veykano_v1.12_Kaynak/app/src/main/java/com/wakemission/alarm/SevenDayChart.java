package com.wakemission.alarm;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

/** Reference yellow bars from actual activity history; values are not fabricated. */
public final class SevenDayChart extends View {
    private final int[] days;
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    public SevenDayChart(Context c,int[] values){super(c);days=values.clone();}
    @Override protected void onMeasure(int ws,int hs){setMeasuredDimension(
        MeasureSpec.getSize(ws),MeasureSpec.getMode(hs)==MeasureSpec.EXACTLY?MeasureSpec.getSize(hs):Ui.dp(getContext(),128));}
    @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);
        float w=getWidth(),h=getHeight(),base=h-Ui.dp(getContext(),22);
        float step=w/Math.max(1,days.length);int max=1;
        for(int v:days)max=Math.max(max,v);
        // Mon-Sun labels based on the in-app locale.
        String[] shortDays=java.text.DateFormatSymbols.getInstance(I18n.locale(getContext())).getShortWeekdays();
        String[] names=new String[7];
        for(int day=0;day<7;day++){
            int calDay=(day+1)%7+1;
            String label=shortDays[calDay];
            names[day]=label==null||label.trim().isEmpty()?String.valueOf(day+1):label.trim();
        }
        p.setTextSize(Ui.dp(getContext(),11));p.setTextAlign(Paint.Align.CENTER);
        for(int i=0;i<days.length;i++){
            float x=step*(i+.5f),barH=days[i]<=0?0:Math.max(Ui.dp(getContext(),5),
                (base-Ui.dp(getContext(),13))*(days[i]/(float)max));
            if(barH>0){p.setColor(Ui.PEACH);canvas.drawRoundRect(x-step*.23f,base-barH,x+step*.23f,base,Ui.dp(getContext(),4),Ui.dp(getContext(),4),p);}
            p.setColor(Ui.MUTED);canvas.drawText(names[i%7],x,h-Ui.dp(getContext(),3),p);
        }
    }
}
