package com.wakemission.alarm;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Simple vector art: stays sharp at all densities; no camera images or branding claims. */
public final class PromoIllustrationView extends View {
    private final int page;
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    public PromoIllustrationView(Context ctx,int page){super(ctx);this.page=page;setContentDescription(page==0?"Camera push-up preview":page==1?"Yoga and movement preview":"Sleep sound chart preview");}
    private void color(int c,Paint.Style style,float width){paint.setColor(c);paint.setStyle(style);paint.setStrokeWidth(width);paint.setStrokeCap(Paint.Cap.ROUND);paint.setStrokeJoin(Paint.Join.ROUND);}
    private void line(Canvas c,float x1,float y1,float x2,float y2,int col,float size){color(col,Paint.Style.STROKE,size);c.drawLine(x1,y1,x2,y2,paint);}
    private void round(Canvas c,float x,float y,float w,float h,float r,int col){color(col,Paint.Style.FILL,0);c.drawRoundRect(new RectF(x,y,x+w,y+h),r,r,paint);}
    private void ring(Canvas c,float x,float y,float radius,int col,float stroke){color(col,Paint.Style.STROKE,stroke);c.drawCircle(x,y,radius,paint);}
    private void dot(Canvas c,float x,float y,float radius,int col){color(col,Paint.Style.FILL,0);c.drawCircle(x,y,radius,paint);}
    private void caption(Canvas c,String text,float x,float y,int size,int col){color(col,Paint.Style.FILL,0);paint.setTextSize(size);paint.setFakeBoldText(true);c.drawText(text,x,y,paint);paint.setFakeBoldText(false);}
    @Override protected void onDraw(Canvas original){super.onDraw(original);
        int w=getWidth(),h=getHeight(); if(w<=0||h<=0)return;
        Canvas c=original; c.save();c.scale(w/360f,h/274f);
        round(c,1,1,358,272,24,Ui.PANEL);
        if(page==0)pushup(c);else if(page==1)yoga(c);else sleep(c);
        c.restore();
    }
    private void frame(Canvas c){
        round(c,42,40,276,186,21,Ui.SECONDARY);
        int a=Ui.PEACH;
        line(c,58,58,79,58,a,4);line(c,58,58,58,78,a,4);
        line(c,302,58,281,58,a,4);line(c,302,58,302,78,a,4);
        line(c,58,208,79,208,a,4);line(c,58,208,58,190,a,4);
        line(c,302,208,281,208,a,4);line(c,302,208,302,190,a,4);
    }
    private void pushup(Canvas c){
        frame(c);
        round(c,144,11,72,30,15,Ui.PEACH);caption(c,"CAM",160,31,14,Color.WHITE);
        line(c,83,180,272,180,Ui.MUTED,4);
        dot(c,239,105,16,Ui.WHITE);
        line(c,223,117,174,138,Ui.WHITE,13);
        line(c,174,138,105,153,Ui.WHITE,12);
        line(c,105,153,93,181,Ui.WHITE,8);
        line(c,174,138,169,177,Ui.WHITE,9);
        line(c,169,177,166,180,Ui.WHITE,8);
        line(c,223,117,249,151,Ui.WHITE,10);
        line(c,249,151,249,177,Ui.WHITE,9);
        for(float[] p:new float[][]{{223,117},{174,138},{105,153},{169,177},{249,151}})dot(c,p[0],p[1],5,Ui.PEACH);
        round(c,109,232,140,27,13,Ui.GREEN);caption(c,"08  /  20",144,251,16,Color.WHITE);
    }
    private void yoga(Canvas c){
        frame(c);
        round(c,83,189,196,6,3,Ui.GREEN);
        dot(c,180,89,18,Ui.WHITE);
        line(c,180,110,180,161,Ui.WHITE,14);
        line(c,180,124,144,87,Ui.WHITE,10);line(c,144,87,135,63,Ui.WHITE,8);
        line(c,180,124,216,87,Ui.WHITE,10);line(c,216,87,225,63,Ui.WHITE,8);
        line(c,180,157,155,188,Ui.WHITE,12);line(c,180,157,205,188,Ui.WHITE,12);
        for(float[] p:new float[][]{{180,124},{180,157},{144,87},{216,87}})dot(c,p[0],p[1],5,Ui.PEACH);
        round(c,116,15,129,31,16,Ui.PEACH);caption(c,"YOGA",152,37,16,Color.WHITE);
        round(c,110,230,142,28,13,Ui.GREEN);caption(c,"20 SEC",155,249,16,Color.WHITE);
    }
    private void sleep(Canvas c){
        round(c,35,20,290,213,21,Ui.SECONDARY);
        dot(c,92,69,22,Ui.PEACH);dot(c,102,58,22,Ui.SECONDARY);
        caption(c,"SLEEP TIMELINE",138,68,14,Ui.WHITE);
        line(c,62,181,305,181,Ui.MUTED,2);
        line(c,62,105,62,181,Ui.MUTED,2);
        for(int x=70;x<293;x+=12){
            float wave=(float)(20*Math.sin((x-70)*0.092)+9*Math.cos((x-70)*0.2));
            if(x>150&&x<190)wave+=14;
            line(c,x,146-wave*.65f,x,146+wave*.65f,Ui.GREEN,4);
        }
        for(int x:new int[]{109,173,257}){
            dot(c,x,144,6,Ui.PEACH);
            line(c,x,180,x,213,Ui.PEACH,2);
        }
        caption(c,"01:20",58,215,12,Ui.MUTED);
        caption(c,"03:15",147,215,12,Ui.MUTED);
        caption(c,"06:40",256,215,12,Ui.MUTED);
        round(c,77,240,207,26,13,Ui.GREEN);caption(c,"SOUND EVENTS",119,259,14,Color.WHITE);
    }
}
