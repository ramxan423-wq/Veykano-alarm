package com.wakemission.alarm;

/** Framework-free, unit-testable repetition classifier. Input is a valid elbow angle. */
public final class RepCounter {
    private enum Phase { READY, DOWN }
    private Phase phase=Phase.READY;
    private int count;
    private long lastCountMs = -10_000;
    private long downStartedMs;
    private boolean sawUp=false;
    private int downFrames=0, upFrames=0;
    private final boolean squat;

    public RepCounter(boolean squat){this.squat=squat;}
    public int count(){return count;}
    public void reset(){phase=Phase.READY;count=0;lastCountMs=-10_000;sawUp=false;downFrames=0;upFrames=0;}
    /** Discard a half-finished repetition after pause/lost tracking; keep completed reps. */
    public void interrupt(){phase=Phase.READY;sawUp=false;downFrames=0;upFrames=0;}
    /** Require consecutive confident observations, complete down/up cycle and interval. */
    public int addAngle(double angle,long nowMs){
        if(!Double.isFinite(angle)||angle<35||angle>180)return count;
        final double up = squat ? 155 : 155;
        final double down = squat ? 105 : 100;
        if(phase==Phase.READY){
            if(angle>=up){sawUp=true;upFrames++;}else if(angle>down){upFrames=0;}
            if(sawUp && angle<=down){
                downFrames++;
                if(downFrames>=2){phase=Phase.DOWN;downStartedMs=nowMs;downFrames=0;upFrames=0;}
            }else if(angle>down){downFrames=0;}
        }else{
            if(angle>=up){
                upFrames++;
                if(upFrames>=2 && nowMs-downStartedMs>=250 && nowMs-lastCountMs>=600){
                    count++;lastCountMs=nowMs;phase=Phase.READY;upFrames=0;downFrames=0;
                }
            }else if(angle<up){upFrames=0;}
        }
        return count;
    }
}
