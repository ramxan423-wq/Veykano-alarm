package com.wakemission.alarm;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

/** Deterministic vector-like reference icons, independent of emoji fonts. */
public final class ReferenceIconView extends View {
    private final String name;
    private final int color;
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    public ReferenceIconView(Context context,String name,int color){super(context);this.name=name;this.color=color;}
    private void path(Canvas c,float... coords){Path path=new Path();path.moveTo(coords[0],coords[1]);
        for(int i=2;i+1<coords.length;i+=2)path.lineTo(coords[i],coords[i+1]);c.drawPath(path,p);}
    private void rect(Canvas c,float l,float t,float r,float b,float rad){c.drawRoundRect(l,t,r,b,rad,rad,p);}
    @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);
        float s=Math.min(getWidth(),getHeight())/36f;
        canvas.save();canvas.translate((getWidth()-36*s)/2,(getHeight()-36*s)/2);canvas.scale(s,s);
        p.setColor(color);p.setStrokeWidth(2.4f);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);
        p.setStyle(Paint.Style.STROKE);
        switch(name){
            case "dumbbell":
                p.setStrokeWidth(3.2f);canvas.drawLine(7,18,29,18,p);
                p.setStrokeWidth(4.5f);canvas.drawLine(9,11,9,25,p);canvas.drawLine(13,9,13,27,p);
                canvas.drawLine(23,9,23,27,p);canvas.drawLine(27,11,27,25,p);break;
            case "plus":
                p.setStrokeWidth(3.2f);canvas.drawLine(18,9,18,27,p);canvas.drawLine(9,18,27,18,p);break;
            case "moon":{
                p.setStyle(Paint.Style.FILL);Path cres=new Path();cres.moveTo(23,4);cres.cubicTo(14,5,10,12,11,19);
                cres.cubicTo(13,26,20,28,28,23);cres.cubicTo(24,33,8,30,6,19);cres.cubicTo(4,11,11,4,23,4);canvas.drawPath(cres,p);
                rect(canvas,26,4,28,9,1);rect(canvas,30,11,32,15,1);break;}
            case "bars":
                p.setStyle(Paint.Style.FILL);rect(canvas,6,18,12,31,2);rect(canvas,15,9,21,31,2);rect(canvas,24,14,30,31,2);break;
            case "camera":{
                p.setStyle(Paint.Style.FILL);rect(canvas,3,10,33,29,3);rect(canvas,10,7,19,12,2);
                p.setColor(0xFFFFFFFF);canvas.drawCircle(18,19,7,p);p.setColor(color);canvas.drawCircle(18,19,4.7f,p);break;}
            case "calculator":
                p.setStyle(Paint.Style.FILL);rect(canvas,5,5,31,31,4);
                p.setColor(0xFFFFFFFF);p.setStrokeWidth(2);
                canvas.drawLine(12,12,19,12,p);canvas.drawLine(15.5f,8.5f,15.5f,15.5f,p);
                canvas.drawLine(23,10,27,14,p);canvas.drawLine(27,10,23,14,p);canvas.drawLine(11,23,16,23,p);
                canvas.drawLine(23,20,27,20,p);canvas.drawLine(23,24,27,24,p);break;
            case "qr":{
                p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3.0f);
                rect(canvas,3,3,15,15,1);rect(canvas,21,3,33,15,1);rect(canvas,3,21,15,33,1);
                p.setStyle(Paint.Style.FILL);rect(canvas,8,8,11,11,0);rect(canvas,26,8,29,11,0);rect(canvas,8,26,11,29,0);
                rect(canvas,20,21,24,25,0);rect(canvas,28,21,32,25,0);rect(canvas,21,29,25,33,0);
                rect(canvas,29,29,33,33,0);break;}
            case "steps":
                p.setStyle(Paint.Style.FILL);
                canvas.save();canvas.rotate(-24,11,13);canvas.drawOval(7,3,17,19,p);canvas.drawOval(8,20,16,26,p);canvas.restore();
                canvas.save();canvas.rotate(22,25,19);canvas.drawOval(20,11,30,28,p);canvas.drawOval(21,29,29,34,p);canvas.restore();break;
            case "mic":
                p.setStrokeWidth(3.3f);p.setStyle(Paint.Style.FILL);rect(canvas,13,3,23,23,6);
                p.setStyle(Paint.Style.STROKE);canvas.drawArc(8,11,28,30,0,180,false,p);
                canvas.drawLine(18,30,18,34,p);canvas.drawLine(11,34,25,34,p);break;
            case "touch":{
                p.setStrokeWidth(2.6f);path(canvas,16,31,10,21,11,18,13,17,17,20,17,5);
                canvas.drawRoundRect(15,3,19,24,2,2,p);
                path(canvas,19,18,22,16,24,18,27,17,30,20,29,30,24,33,16,31);break;}
            case "yoga":{
                p.setStrokeWidth(2.7f);canvas.drawCircle(18,7,3,p);
                path(canvas,18,12,18,25,10,29,6,27);
                path(canvas,18,25,26,29,30,27);
                path(canvas,17,15,9,9,6,4);
                path(canvas,19,15,27,9,30,4);
                break;}
            case "situp":{
                p.setStrokeWidth(2.8f);canvas.drawCircle(10,21,3,p);
                path(canvas,12,23,19,14,24,26,31,27);
                path(canvas,19,14,23,9,28,10);
                path(canvas,23,26,19,32,9,32);
                break;}
            case "calorie":{
                p.setStrokeWidth(2.5f);
                path(canvas,17,3,12,13,15,18,9,17,8,26,12,32,19,34,26,31,29,24,24,17,23,9,18,15,17,3);
                path(canvas,19,19,17,25,20,30,23,26);
                break;}
            case "squat":{
                p.setStrokeWidth(3.9f);canvas.drawCircle(23,6,3,p);
                path(canvas,21,11,16,19,25,23,30,30);path(canvas,16,19,10,25,15,31);path(canvas,19,15,28,16);
                canvas.drawLine(13,31,7,31,p);canvas.drawLine(28,30,33,30,p);break;}
            case "badge":{p.setStrokeWidth(2.5f);canvas.drawCircle(18,13,8,p);path(canvas,13,20,11,32,18,28,25,32,23,20);break;}
            case "tasks":{
                rect(canvas,8,6,28,32,3);rect(canvas,13,3,23,9,2);
                canvas.drawLine(13,15,23,15,p);canvas.drawLine(13,21,23,21,p);canvas.drawLine(13,27,21,27,p);break;}
            case "settings":{
                canvas.drawCircle(18,18,9,p);canvas.drawCircle(18,18,3,p);
                for(int i=0;i<8;i++){double a=i*Math.PI/4;float dx=(float)Math.cos(a),dy=(float)Math.sin(a);
                    canvas.drawLine(18+dx*10,18+dy*10,18+dx*15,18+dy*15,p);}break;}
            case "help":{canvas.drawCircle(18,18,14,p);p.setTextSize(23);p.setStyle(Paint.Style.FILL);
                p.setTextAlign(Paint.Align.CENTER);canvas.drawText("?",18,26,p);break;}
            case "info":{canvas.drawCircle(18,18,14,p);p.setTextSize(22);p.setStyle(Paint.Style.FILL);
                p.setTextAlign(Paint.Align.CENTER);canvas.drawText("i",18,26,p);break;}
            case "bell":{path(canvas,9,24,12,19,12,13,14,9,18,7,22,9,24,13,24,19,27,24,9,24);
                canvas.drawLine(15,29,21,29,p);break;}
            case "clock":{canvas.drawCircle(18,18,13,p);path(canvas,18,10,18,18,24,21);break;}
            case "tag":{path(canvas,6,9,21,9,30,18,19,30,6,17,6,9);canvas.drawCircle(11,14,2,p);break;}
            case "person":{p.setStrokeWidth(3);canvas.drawCircle(18,11,6,p);rect(canvas,7,22,29,34,9);break;}
            default:canvas.drawCircle(18,18,12,p);
        }
        canvas.restore();
    }
}
