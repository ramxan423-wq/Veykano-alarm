package com.wakemission.alarm;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

/** Reference-sized yellow switch, with no dependency on OEM switch rendering. */
public final class ReferenceToggleView extends View {
    public interface Listener{void onCheckedChanged(boolean value);}
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    private boolean checked;
    private Listener listener;
    public ReferenceToggleView(Context c){super(c);setClickable(true);setFocusable(true);
        setOnClickListener(v->{checked=!checked;updateDescription();invalidate();
            if(listener!=null)listener.onCheckedChanged(checked);});
        updateDescription();
    }
    public void setChecked(boolean on){checked=on;updateDescription();invalidate();}
    public void setOnCheckedChangeListener(Listener l){listener=l;}
    private void updateDescription(){setContentDescription(checked?"Alarm açık":"Alarm kapalı");}
    @Override protected void onDraw(Canvas c){super.onDraw(c);
        float w=getWidth(),h=getHeight();
        float inset=Math.max(1,Math.min(w,h)*.08f),top=h*.13f,bottom=h*.87f;
        float radius=(bottom-top)*.5f;
        p.setStyle(Paint.Style.FILL);p.setColor(checked?Ui.PEACH:0xFFBFC0BE);
        c.drawRoundRect(inset,top,w-inset,bottom,radius,radius,p);
        float thumbRadius=radius*.88f;
        float x=checked?w-inset-radius:inset+radius;
        p.setColor(0xFFFFFFFF);c.drawCircle(x,h/2f,thumbRadius,p);
    }
}
