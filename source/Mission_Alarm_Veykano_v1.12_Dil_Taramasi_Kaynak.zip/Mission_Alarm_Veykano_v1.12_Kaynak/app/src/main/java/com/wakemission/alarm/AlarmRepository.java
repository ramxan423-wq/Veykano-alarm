package com.wakemission.alarm;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public final class AlarmRepository {
    private static SharedPreferences prefs(Context c){return c.getApplicationContext().getSharedPreferences("wake_mission_v1",Context.MODE_PRIVATE);}
    public static synchronized List<AlarmItem> list(Context c){
        List<AlarmItem> alarms=new ArrayList<>();
        try{
            JSONArray array=new JSONArray(prefs(c).getString("alarms","[]"));
            for(int i=0;i<array.length();i++) alarms.add(AlarmItem.from(array.getJSONObject(i)));
        }catch(Exception ignored){}return alarms;
    }
    public static AlarmItem get(Context c,int id){for(AlarmItem a:list(c))if(a.id==id)return a;return null;}
    public static synchronized int nextId(Context c){
        SharedPreferences p=prefs(c);int result=Math.max(p.getInt("seq",100),100)+1;
        p.edit().putInt("seq",result).apply();return result;
    }
    private static void store(Context c,List<AlarmItem> alarms){
        JSONArray array=new JSONArray();for(AlarmItem a:alarms)array.put(a.json());
        // commit: changes should survive process death before the next scheduled broadcast
        prefs(c).edit().putString("alarms",array.toString()).commit();
    }
    public static synchronized void put(Context c,AlarmItem input){
        List<AlarmItem> items=list(c);boolean replaced=false;
        for(int i=0;i<items.size();i++)if(items.get(i).id==input.id){items.set(i,input);replaced=true;break;}
        if(!replaced)items.add(input);store(c,items);
    }
    public static synchronized void delete(Context c,int id){
        List<AlarmItem> items=list(c);items.removeIf(a->a.id==id);store(c,items);
    }
    public static synchronized void record(Context c,String result,AlarmItem alarm){record(c,result,alarm,-1L);}
    public static synchronized void record(Context c,String result,AlarmItem alarm,long durationMs){
        JSONArray list;
        try{list=new JSONArray(prefs(c).getString("history","[]"));}catch(Exception ignored){list=new JSONArray();}
        JSONObject row=new JSONObject();
        try{row.put("time",System.currentTimeMillis());row.put("result",result);row.put("alarm",alarm==null?"Alarm":alarm.title);if(durationMs>=0)row.put("duration_ms",durationMs);}
        catch(Exception ignored){}
        JSONArray out=new JSONArray();out.put(row);
        for(int i=0;i<Math.min(199,list.length());i++)try{out.put(list.get(i));}catch(Exception ignored){}
        prefs(c).edit().putString("history",out.toString()).apply();
    }
    public static JSONArray history(Context c){try{return new JSONArray(prefs(c).getString("history","[]"));}catch(Exception e){return new JSONArray();}}
    public static void recordSleep(Context c,String sleep,String wake){
        JSONArray a;try{a=new JSONArray(prefs(c).getString("sleep","[]"));}catch(Exception e){a=new JSONArray();}
        JSONObject j=new JSONObject();try{j.put("at",System.currentTimeMillis());j.put("sleep",sleep);j.put("wake",wake);}catch(Exception ignored){}
        JSONArray out=new JSONArray();out.put(j);for(int i=0;i<Math.min(a.length(),90);i++)try{out.put(a.get(i));}catch(Exception ignored){}
        prefs(c).edit().putString("sleep",out.toString()).apply();
    }
    public static JSONArray sleepHistory(Context c){try{return new JSONArray(prefs(c).getString("sleep","[]"));}catch(Exception e){return new JSONArray();}}
}
