package com.wakemission.alarm;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import java.util.Locale;

/** Local visual reference matching, NOT a learned made-vs-unmade bed classifier. */
public final class BedReferenceMatcher {
    private static final int GRID=16;
    private static final String PREF="reference_bed_v1";
    private BedReferenceMatcher(){}

    /** Normalized low-resolution luminance plus local edge energy, no photo persisted. */
    public static byte[] fingerprint(Bitmap image){
        if(image==null||image.getWidth()<64||image.getHeight()<64)return null;
        int n=GRID*GRID;
        double[] lum=new double[n];double sum=0, sq=0;
        // Crop outer border to reduce differences in phone framing.
        for(int y=0;y<GRID;y++)for(int x=0;x<GRID;x++){
            int px=(int)((.10+(x+.5)*.80/GRID)*image.getWidth());
            int py=(int)((.10+(y+.5)*.80/GRID)*image.getHeight());
            int rgb=image.getPixel(Math.min(image.getWidth()-1,px),Math.min(image.getHeight()-1,py));
            double v=.2126*Color.red(rgb)+.7152*Color.green(rgb)+.0722*Color.blue(rgb);
            lum[y*GRID+x]=v;sum+=v;sq+=v*v;
        }
        double avg=sum/n, std=Math.sqrt(Math.max(1,sq/n-avg*avg));
        byte[] result=new byte[n];
        for(int i=0;i<n;i++){
            int normalized=(int)Math.round(128+(lum[i]-avg)*40/std);
            result[i]=(byte)Math.max(0,Math.min(255,normalized));
        }
        return result;
    }
    public static String encode(byte[] features){
        if(features==null)return "";
        StringBuilder b=new StringBuilder(features.length*2);
        for(byte v:features)b.append(String.format(Locale.ROOT,"%02x",v&255));
        return b.toString();
    }
    public static byte[] decode(String encoded){
        if(encoded==null||encoded.length()!=GRID*GRID*2)return null;
        byte[] result=new byte[GRID*GRID];
        try{for(int i=0;i<result.length;i++)result[i]=(byte)Integer.parseInt(encoded.substring(i*2,i*2+2),16);}
        catch(NumberFormatException ignored){return null;}
        return result;
    }
    public static double similarity(byte[] a,byte[] b){
        return SceneSimilarity.score(a,b,GRID*GRID);
    }
    public static void save(Context c,Bitmap bitmap){
        String v=encode(fingerprint(bitmap));
        if(!v.isEmpty())c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putString("features",v).apply();
    }
    public static boolean available(Context c){return decode(c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("features",""))!=null;}
    public static double match(Context c,Bitmap candidate){
        byte[] original=decode(c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("features",""));
        return similarity(original,fingerprint(candidate));
    }
    public static boolean accept(double similarity){return similarity>=.88;}
}
