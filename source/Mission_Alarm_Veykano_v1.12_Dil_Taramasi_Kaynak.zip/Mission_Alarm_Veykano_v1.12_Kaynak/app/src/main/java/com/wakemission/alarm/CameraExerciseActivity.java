package com.wakemission.alarm;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.View;
import android.util.Rational;
import android.view.Surface;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.StyleSpan;
import android.graphics.Typeface;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.activity.ComponentActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.core.UseCaseGroup;
import androidx.camera.core.ViewPort;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.pose.Pose;
import com.google.mlkit.vision.pose.PoseDetection;
import com.google.mlkit.vision.pose.PoseDetector;
import com.google.mlkit.vision.pose.PoseLandmark;
import com.google.mlkit.vision.pose.accurate.AccuratePoseDetectorOptions;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Reference-styled real camera challenge with live, on-device pose tracking. */
public final class CameraExerciseActivity extends ComponentActivity {
    public static final String EXTRA_KIND="kind",EXTRA_TARGET="target",EXTRA_POSE="pose",EXTRA_ACTIVITY="calorie_activity",EXTRA_WEIGHT_KG="weight_kg",EXTRA_CALORIE_GOAL="calorie_goal";
    private static final int CAMERA_REQUEST=719;
    private static final int YELLOW=0xFFFFCC32;
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private PreviewView preview;
    private PoseOverlayView skeleton;
    private TextView countLabel,hint;
    private ReferenceExerciseControl pauseButton;
    private ReferenceProgressView progress;
    private RepCounter counter;
    private YogaHoldTimer yogaTimer;
    private SitupCounter situpCounter;
    private String calorieActivity=CalorieEstimate.SITUP;
    private int calorieGoal=2, weightKg=70;
    private String yogaPose=YogaPoseLogic.ARMS_UP;
    private PoseDetector detector;
    private int target=20;
    private boolean squat,yoga,situp,calorie,frontCamera;
    private volatile boolean completed,paused;
    private long lastValidPoseMs;

    @Override protected void onCreate(Bundle saved){super.onCreate(saved);AppTheme.apply(this);
        squat="SQUAT".equals(getIntent().getStringExtra(EXTRA_KIND));
        yoga="YOGA".equals(getIntent().getStringExtra(EXTRA_KIND));
        calorie="CALORIE".equals(getIntent().getStringExtra(EXTRA_KIND));
        calorieActivity=CalorieEstimate.safeActivity(getIntent().getStringExtra(EXTRA_ACTIVITY));
        calorieGoal=CalorieEstimate.safeGoal(getIntent().getIntExtra(EXTRA_CALORIE_GOAL,2));
        weightKg=CalorieEstimate.safeWeight(getIntent().getIntExtra(EXTRA_WEIGHT_KG,70));
        if(calorie)squat=CalorieEstimate.SQUAT.equals(calorieActivity);
        situp="SITUP".equals(getIntent().getStringExtra(EXTRA_KIND)) ||
            (calorie && CalorieEstimate.SITUP.equals(calorieActivity));
        yogaPose=YogaPoseLogic.safePose(getIntent().getStringExtra(EXTRA_POSE));
        target=yoga?YogaHoldTimer.safeSeconds(getIntent().getIntExtra(EXTRA_TARGET,10)):
            Math.max(1,Math.min(200,getIntent().getIntExtra(EXTRA_TARGET,20)));
        if(calorie)target=calorieGoal;
        if(yoga)yogaTimer=new YogaHoldTimer(target);
        else if(situp)situpCounter=new SitupCounter();
        else counter=new RepCounter(squat);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(0xFF747474);
        getWindow().setNavigationBarColor(0xFF262626);
        getWindow().getDecorView().setSystemUiVisibility(0);
        buildScreen();
        detector=PoseDetection.getClient(new AccuratePoseDetectorOptions.Builder()
            .setDetectorMode(AccuratePoseDetectorOptions.STREAM_MODE).build());
        if(checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.CAMERA},CAMERA_REQUEST);
        else startCamera();
    }
    private int dp(float n){return (int)(getResources().getDisplayMetrics().density*n+.5f);}
    private GradientDrawable bubble(int color,int radius){GradientDrawable d=new GradientDrawable();
        d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private TextView text(String value,int size,int color,boolean bold){
        TextView t=Ui.text(this,value,size,color,bold);t.setIncludeFontPadding(false);return t;}
    private void buildScreen(){
        FrameLayout root=new FrameLayout(this);root.setBackgroundColor(0xFF5D5D5D);
        preview=new PreviewView(this);preview.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        // Compatible texture rendering allows the joint canvas to overlay camera content.
        preview.setImplementationMode(PreviewView.ImplementationMode.COMPATIBLE);
        root.addView(preview,new FrameLayout.LayoutParams(-1,-1));
        View shade=new View(this);
        GradientDrawable overlay=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            new int[]{0x77000000,0x00000000,0x00000000,0x78000000});
        shade.setBackground(overlay);root.addView(shade,new FrameLayout.LayoutParams(-1,-1));
        skeleton=new PoseOverlayView(this);
        root.addView(skeleton,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout toolbar=new LinearLayout(this);toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setPadding(dp(18),dp(17),dp(18),dp(14));
        TextView back=text("‹",35,Color.WHITE,false);back.setGravity(Gravity.CENTER);
        back.setContentDescription(I18n.tr(this,"Geri dön"));toolbar.addView(back,new LinearLayout.LayoutParams(dp(42),dp(42)));
        back.setOnClickListener(v->finish());
        TextView title=text(yoga?"Yoga • "+YogaPoseLogic.title(yogaPose):calorie?"Kalori • "+
            (situp?"Mekik":squat?"Squat":"Şınav"):situp?"Mekik Görevi":squat?"Squat Görevi":"Şınav Görevi",18,Color.WHITE,true);
        title.setGravity(Gravity.CENTER);toolbar.addView(title,new LinearLayout.LayoutParams(0,dp(42),1));
        toolbar.addView(new View(this),new LinearLayout.LayoutParams(dp(42),dp(42)));
        FrameLayout.LayoutParams top=new FrameLayout.LayoutParams(-1,dp(74),Gravity.TOP);
        root.addView(toolbar,top);

        LinearLayout hud=new LinearLayout(this);hud.setGravity(Gravity.CENTER_HORIZONTAL);
        hud.setOrientation(LinearLayout.VERTICAL);
        hud.setPadding(dp(20),0,dp(20),dp(18));
        countLabel=text(yoga?"0 / "+target+" sn":calorie?"0.0 / "+target+" kcal":"0 / "+target,37,Color.WHITE,false);countLabel.setGravity(Gravity.CENTER);
        if(!calorie)updateCounter(0);
        hud.addView(countLabel,new LinearLayout.LayoutParams(-1,dp(53)));
        progress=new ReferenceProgressView(this);progress.setMax(calorie?target*100:target);progress.setProgress(0);
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,dp(10));
        pp.topMargin=dp(7);pp.bottomMargin=dp(16);hud.addView(progress,pp);
        pauseButton=new ReferenceExerciseControl(this);
        hud.addView(pauseButton,new LinearLayout.LayoutParams(dp(55),dp(55)));
        pauseButton.setOnClickListener(v->{paused=!paused;
            pauseButton.setPaused(paused);
            if(yoga)yogaTimer.interrupt();else if(situp)situpCounter.interrupt();else counter.interrupt();
            if(paused){skeleton.clear();hint.setText(I18n.tr(this,"Duraklatıldı. Devam etmek için oynat düğmesine dokun."));}
            else hint.setText(yoga?"Kamera önünde "+YogaPoseLogic.title(yogaPose)+" pozunu koru.":
                situp?"Kamera yandan görsün; dizlerini bük, kontrollü mekik yap.":
                "Kamerada tüm vücudun görünsün. Doğru formda yapmaya çalış.");
        });
        LinearLayout hintBox=new LinearLayout(this);hintBox.setGravity(Gravity.CENTER_VERTICAL);
        hintBox.setPadding(dp(14),dp(13),dp(13),dp(13));
        hintBox.setBackground(bubble(0x99727272,15));
        TextView bulb=text("💡",22,0xFFFFD130,false);
        hintBox.addView(bulb,new LinearLayout.LayoutParams(dp(36),-2));
        hint=text(yoga?"Telefonu sabitle. Tüm vücudun görünsün.\n"+YogaPoseLogic.title(yogaPose)+" pozunda sabit kal.":
            situp?"Telefonu sabitle, yandan görün.\nDizini bükerek kontrollü mekik yap.":
            "Kamerada tüm vücudun görünsün.\nDoğru formda yapmaya çalış.",12,Color.WHITE,false);
        hintBox.addView(hint,new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);
        hp.topMargin=dp(22);hud.addView(hintBox,hp);
        FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM);
        bp.bottomMargin=dp(14);root.addView(hud,bp);
        setContentView(root);
    }
    private void startCamera(){
        // Wait for PreviewView dimensions. Both camera use cases must share its viewport
        // or the white joint markers may appear shifted from the person.
        if(isFinishing()||isDestroyed())return;
        if(preview.getWidth()==0||preview.getHeight()==0){preview.post(this::startCamera);return;}
        ListenableFuture<ProcessCameraProvider> future=ProcessCameraProvider.getInstance(this);
        future.addListener(()->{
            if(isFinishing()||isDestroyed())return;
            try{
                ProcessCameraProvider provider=future.get();provider.unbindAll();
                frontCamera=provider.hasCamera(CameraSelector.DEFAULT_FRONT_CAMERA);
                CameraSelector camera=frontCamera?CameraSelector.DEFAULT_FRONT_CAMERA:CameraSelector.DEFAULT_BACK_CAMERA;
                Preview p=new Preview.Builder().build();p.setSurfaceProvider(preview.getSurfaceProvider());
                ImageAnalysis analysis=new ImageAnalysis.Builder().setBackpressureStrategy(
                    ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build();
                analysis.setAnalyzer(worker,this::analyze);
                ViewPort viewPort=preview.getViewPort();
                if(viewPort==null){
                    int rotation=preview.getDisplay()==null?Surface.ROTATION_0:preview.getDisplay().getRotation();
                    viewPort=new ViewPort.Builder(new Rational(preview.getWidth(),preview.getHeight()),rotation)
                        .setScaleType(ViewPort.FILL_CENTER).build();
                }
                UseCaseGroup group=new UseCaseGroup.Builder().addUseCase(p).addUseCase(analysis)
                    .setViewPort(viewPort).build();
                provider.bindToLifecycle(this,camera,group);
            }catch(Exception err){hint.setText(I18n.tr(this,"Kamera başlatılamadı. Kamera izinlerini kontrol et."));}
        },ContextCompat.getMainExecutor(this));
    }
    @androidx.camera.core.ExperimentalGetImage
    private void analyze(ImageProxy frame){
        if(completed||paused||isFinishing()||frame.getImage()==null){frame.close();return;}
        int rotation=frame.getImageInfo().getRotationDegrees();
        final int width=(rotation==90||rotation==270)?frame.getHeight():frame.getWidth();
        final int height=(rotation==90||rotation==270)?frame.getWidth():frame.getHeight();
        final Rect crop=rotateCrop(frame.getCropRect(),frame.getWidth(),frame.getHeight(),rotation);
        InputImage input=InputImage.fromMediaImage(frame.getImage(),rotation);
        try{
            detector.process(input)
                .addOnSuccessListener(pose->runOnUiThread(()->{
                    if(!paused&&!completed&&!isFinishing()){
                        skeleton.update(pose,width,height,frontCamera,crop,squat||yoga||situp);onPose(pose);
                    }
                }))
                .addOnFailureListener(e->runOnUiThread(()->{
                    if(!paused&&!completed&&!isFinishing())hint.setText(I18n.tr(this,"Vücut algılanamadı. Işığı ve kamerayı kontrol et."));
                }))
                // Must close every ImageProxy even if Activity is paused/destroyed.
                .addOnCompleteListener(t->frame.close());
        }catch(RuntimeException e){frame.close();}

    }
    /** Transform CameraX sensor crop into ML Kit's upright image coordinates. */
    private static Rect rotateCrop(Rect r,int w,int h,int rotation){
        switch(rotation){
            case 90:return new Rect(h-r.bottom,r.left,h-r.top,r.right);
            case 180:return new Rect(w-r.right,h-r.bottom,w-r.left,h-r.top);
            case 270:return new Rect(r.top,w-r.right,r.bottom,w-r.left);
            default:return new Rect(r);
        }
    }
    private void onPose(Pose pose){
        if(yoga){onYogaPose(pose);return;}
        if(situp){onSitupPose(pose);return;}
        double a=angle(pose,squat?PoseLandmark.LEFT_HIP:PoseLandmark.LEFT_SHOULDER,
                squat?PoseLandmark.LEFT_KNEE:PoseLandmark.LEFT_ELBOW,
                squat?PoseLandmark.LEFT_ANKLE:PoseLandmark.LEFT_WRIST);
        double b=angle(pose,squat?PoseLandmark.RIGHT_HIP:PoseLandmark.RIGHT_SHOULDER,
                squat?PoseLandmark.RIGHT_KNEE:PoseLandmark.RIGHT_ELBOW,
                squat?PoseLandmark.RIGHT_ANKLE:PoseLandmark.RIGHT_WRIST);
        double usable;
        if(Double.isFinite(a)&&Double.isFinite(b))usable=(a+b)/2.0;
        else usable=Double.isFinite(a)?a:b;
        if(!Double.isFinite(usable)){
            // Missing landmarks must not finish a partial rep when tracking reappears.
            if(SystemClock.elapsedRealtime()-lastValidPoseMs>1200)counter.interrupt();
            hint.setText(I18n.tr(this,squat?"Kamerada tüm vücudun görünsün.\nKalça, diz ve ayak bileklerin görünmeli.":
                "Kamerada tüm vücudun görünsün.\nOmuz, dirsek ve bilekler görünmeli."));return;
        }
        long now=SystemClock.elapsedRealtime();
        if(lastValidPoseMs>0 && now-lastValidPoseMs>1200)counter.interrupt();
        lastValidPoseMs=now;
        int prior=counter.count(),current=counter.addAngle(usable,now);
        if(prior!=current)updateExerciseProgress(current);
        hint.setText(calorie?"Tekrar: "+current+" • Tahmini kalori: "+formattedKcal(current)+" kcal.\nGerçek enerji harcaması farklı olabilir.":
            "Kamerada tüm vücudun görünsün.\nDoğru formda yapmaya çalış.");
        if(exerciseDone(current))finishExercise(current);
    }
    private void onSitupPose(Pose pose){
        double a=angle(pose,PoseLandmark.LEFT_SHOULDER,PoseLandmark.LEFT_HIP,PoseLandmark.LEFT_KNEE);
        double b=angle(pose,PoseLandmark.RIGHT_SHOULDER,PoseLandmark.RIGHT_HIP,PoseLandmark.RIGHT_KNEE);
        double lKnee=angle(pose,PoseLandmark.LEFT_HIP,PoseLandmark.LEFT_KNEE,PoseLandmark.LEFT_ANKLE);
        double rKnee=angle(pose,PoseLandmark.RIGHT_HIP,PoseLandmark.RIGHT_KNEE,PoseLandmark.RIGHT_ANKLE);
        boolean legVisible=(Double.isFinite(lKnee)&&lKnee>=45&&lKnee<=165) ||
                           (Double.isFinite(rKnee)&&rKnee>=45&&rKnee<=165);
        double usable=Double.isFinite(a)&&Double.isFinite(b)?(a+b)/2:
            Double.isFinite(a)?a:b;
        long now=SystemClock.elapsedRealtime();
        if(!Double.isFinite(usable)||!legVisible){
            situpCounter.interrupt();
            hint.setText(I18n.tr(this,"Mekik için telefonu yana koy. Omuz, kalça ve bükülü diz görünmeli."));return;
        }
        if(lastValidPoseMs>0&&now-lastValidPoseMs>1200)situpCounter.interrupt();
        lastValidPoseMs=now;
        int prior=situpCounter.count(),current=situpCounter.addAngle(usable,now);
        if(prior!=current)updateExerciseProgress(current);
        hint.setText(calorie?"Mekik: "+current+" tekrar • Yaklaşık "+formattedKcal(current)+" kcal.\nKalori değeri tahminidir.":
            "Yat → doğrul → yeniden yat. Tekrar: "+current+" / "+target);
        if(exerciseDone(current))finishExercise(current);
    }
    private String formattedKcal(int reps){
        return String.format(java.util.Locale.getDefault(),"%.1f",CalorieEstimate.estimate(reps,weightKg,calorieActivity));
    }
    private void updateExerciseProgress(int reps){
        if(calorie){
            double kcal=CalorieEstimate.estimate(reps,weightKg,calorieActivity);
            progress.setProgress(Math.min(target*100,(int)Math.floor(kcal*100)));
            String value=formattedKcal(reps)+" / "+target+" kcal";
            countLabel.setText(value);
        }else {updateCounter(reps);progress.setProgress(reps);}
    }
    private boolean exerciseDone(int reps){
        return calorie?CalorieEstimate.estimate(reps,weightKg,calorieActivity)>=calorieGoal:reps>=target;
    }
    private void finishExercise(int reps){
        completed=true;
        Intent result=new Intent().putExtra("repetitions",reps);
        if(calorie)result.putExtra("estimated_kcal",CalorieEstimate.estimate(reps,weightKg,calorieActivity));
        setResult(Activity.RESULT_OK,result);finish();
    }
    private void onYogaPose(Pose pose){
        YogaPoseLogic.Joint[] joints=new YogaPoseLogic.Joint[33];
        for(int id=0;id<joints.length;id++){
            PoseLandmark mark=pose.getPoseLandmark(id);
            if(mark!=null)joints[id]=new YogaPoseLogic.Joint(mark.getPosition().x,mark.getPosition().y,mark.getInFrameLikelihood());
        }
        boolean matched=YogaPoseLogic.matches(yogaPose,joints);
        int elapsed=yogaTimer.update(matched,SystemClock.elapsedRealtime());
        updateCounter(elapsed);progress.setProgress(elapsed);
        if(!matched)hint.setText(I18n.tr(this,"Poz algılanamadı. Telefonu sabitle; omuz, bilek, kalça, diz ve ayakların görünsün.\n"+
            YogaPoseLogic.title(yogaPose)+" pozunu yeniden dene."));
        else hint.setText(I18n.tr(this,"Harika, sabit kal! "+Math.max(0,target-elapsed)+" saniye kaldı."));
        if(yogaTimer.completed()){
            completed=true;
            setResult(Activity.RESULT_OK,new Intent().putExtra("yoga_pose",yogaPose)
                .putExtra("hold_seconds",target));finish();
        }
    }
    private void updateCounter(int count){
        String value=count+" / "+target+(yoga?" sn":calorie?" kcal":"");
        SpannableString span=new SpannableString(value);
        span.setSpan(new StyleSpan(Typeface.BOLD),0,String.valueOf(count).length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        countLabel.setText(span);
    }
    private static double angle(Pose p,int first,int joint,int last){
        PoseLandmark x=p.getPoseLandmark(first),y=p.getPoseLandmark(joint),z=p.getPoseLandmark(last);
        if(x==null||y==null||z==null||x.getInFrameLikelihood()<.6f||y.getInFrameLikelihood()<.6f||z.getInFrameLikelihood()<.6f)
            return Double.NaN;
        PointF a=x.getPosition(),b=y.getPosition(),c=z.getPosition();
        double ux=a.x-b.x,uy=a.y-b.y,vx=c.x-b.x,vy=c.y-b.y;
        double norm=Math.hypot(ux,uy)*Math.hypot(vx,vy);
        return norm<1?Double.NaN:Math.toDegrees(Math.acos(Math.max(-1,Math.min(1,(ux*vx+uy*vy)/norm))));
    }
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results){
        super.onRequestPermissionsResult(request,permissions,results);
        if(request==CAMERA_REQUEST){if(results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED)startCamera();
            else hint.setText(I18n.tr(this,"Kamera izni gerekli. Geri dönerek alarm görevini değiştirebilirsin."));}
    }
    @Override protected void onPause(){if(yoga)yogaTimer.interrupt();else if(situp)situpCounter.interrupt();else counter.interrupt();skeleton.clear();super.onPause();}
    @Override protected void onDestroy(){
        completed=true;
        if(detector!=null)detector.close();worker.shutdown();super.onDestroy();
    }
}
