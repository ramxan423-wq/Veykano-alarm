package com.wakemission.alarm;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.os.Bundle;
import android.os.Build;
import android.provider.MediaStore;
import android.view.WindowManager;
import android.view.View;
import android.widget.Button;
import android.view.Gravity;
import android.widget.*;
import androidx.activity.ComponentActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.ImageCaptureException;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;
import com.google.common.util.concurrent.ListenableFuture;
import java.io.File;

/** Full-size offline camera capture + bundled ML Kit labeler; no captured file is kept. */
public final class PhotoChallengeActivity extends ComponentActivity {
    public static final String EXTRA_TARGET="target";
    public static final String EXTRA_CALIBRATE="calibrate";
    private static final int ASK_CAMERA=911, SYSTEM_CAMERA_REQUEST=912;
    private TextView status;
    private PreviewView preview;
    private ImageCapture capture;
    private String target="SKY";
    private boolean calibrate=false;
    private File picture;
    private Button take, systemCamera;
    private boolean processing=false;

    @Override protected void onCreate(Bundle saved){super.onCreate(saved);AppTheme.apply(this);
        if(Build.VERSION.SDK_INT>=27){setShowWhenLocked(true);setTurnScreenOn(true);}
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON|
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED|WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        target=getIntent().getStringExtra(EXTRA_TARGET);
        if(target==null)target="SKY";
        calibrate=getIntent().getBooleanExtra(EXTRA_CALIBRATE,false);
        LinearLayout screen=Ui.column(this);screen.setPadding(16,18,16,25);screen.setBackgroundColor(Ui.BG);
        TextView name=Ui.text(this,calibrate?"Toplu yatak örneğini kaydet":("BED".equals(target)?"Yatak toplama görevi":"Fotoğraf görevi: "+target),26,Ui.WHITE,true);screen.addView(name);
        status=Ui.text(this,calibrate?"Yatağını topla ve sabit bir açıdan örnek fotoğraf çek. Görsel özellikler cihazda saklanır.":
            ("BED".equals(target)?"Yatağını topla, örnek fotoğrafın açısıyla eşleşen yerden çek. Fotoğraf benzerliği kesin doğrulama değildir.":
            "Fotoğraf cihaz üzerinde incelenir. Yatak referansıyla karşılaştırma kesin yapay zekâ doğrulaması değildir."),15,Ui.MUTED,false);
        screen.addView(status,Ui.matchMargins(this,14));
        preview=new PreviewView(this);screen.addView(preview,new LinearLayout.LayoutParams(-1,0,1));
        take=Ui.button(this,calibrate?"Toplu yatak örneğini kaydet":"Fotoğrafı çek ve doğrula",true);screen.addView(take,Ui.matchMargins(this,12));
        take.setOnClickListener(v->verify());
        systemCamera=Ui.button(this,"Kamera açılmazsa: sistem kamerası",false);
        screen.addView(systemCamera,Ui.matchMargins(this,7));
        systemCamera.setOnClickListener(v->launchSystemCamera());
        Button back=Ui.button(this,"Alarm ekranına dön",false);screen.addView(back,Ui.matchMargins(this,9));back.setOnClickListener(v->finish());
        setContentView(screen);
        if(checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)startCamera();
        else requestPermissions(new String[]{Manifest.permission.CAMERA},ASK_CAMERA);
    }
    private void startCamera(){
        final ListenableFuture<ProcessCameraProvider> future;
        try{future=ProcessCameraProvider.getInstance(this);}
        catch(Exception e){status.setText(I18n.tr(this,"Kamera başlatılamadı. Sistem kamerasını dene."));return;}
        future.addListener(()->{
            try{
                ProcessCameraProvider provider=future.get();provider.unbindAll();
                Preview p=new Preview.Builder().build();p.setSurfaceProvider(preview.getSurfaceProvider());
                capture=new ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build();
                provider.bindToLifecycle(this,CameraSelector.DEFAULT_BACK_CAMERA,p,capture);
            }catch(Exception e){
                capture=null;
                status.setText(I18n.tr(this,"Uygulama kamerası açılamadı ("+e.getClass().getSimpleName()+"). Sistem kamerasını dene."));
            }
        },ContextCompat.getMainExecutor(this));
    }
    private void verify(){
        if(processing)return;
        if(capture==null){status.setText(I18n.tr(this,"Kamera henüz hazır değil. Sistem kamerasını deneyebilirsin."));return;}
        processing=true;take.setEnabled(false);
        picture=new File(getCacheDir(),"photo_challenge_"+System.currentTimeMillis()+".jpg");
        status.setText(I18n.tr(this,"Fotoğraf çekiliyor..."));
        try{capture.takePicture(new ImageCapture.OutputFileOptions.Builder(picture).build(),
            ContextCompat.getMainExecutor(this),new ImageCapture.OnImageSavedCallback(){
                @Override public void onImageSaved(ImageCapture.OutputFileResults saved){
                    try{
                        BitmapFactory.Options opt=new BitmapFactory.Options();opt.inJustDecodeBounds=true;
                        BitmapFactory.decodeFile(picture.getAbsolutePath(),opt);
                        opt.inJustDecodeBounds=false;
                        opt.inSampleSize=Math.max(1,Math.max(opt.outWidth,opt.outHeight)/1024);
                        Bitmap bitmap=BitmapFactory.decodeFile(picture.getAbsolutePath(),opt);
                        int rotation=0;
                        try{
                            int orientation=new ExifInterface(picture.getAbsolutePath()).getAttributeInt(
                                ExifInterface.TAG_ORIENTATION,ExifInterface.ORIENTATION_NORMAL);
                            rotation=orientation==ExifInterface.ORIENTATION_ROTATE_90?90:
                                orientation==ExifInterface.ORIENTATION_ROTATE_180?180:
                                orientation==ExifInterface.ORIENTATION_ROTATE_270?270:0;
                        }catch(Exception ignored){}
                        if(bitmap!=null && rotation!=0){
                            Matrix matrix=new Matrix();matrix.postRotate(rotation);
                            Bitmap rotated=Bitmap.createBitmap(bitmap,0,0,bitmap.getWidth(),bitmap.getHeight(),matrix,true);
                            if(rotated!=bitmap){bitmap.recycle();bitmap=rotated;}
                        }
                        if(picture!=null)picture.delete();
                        checkBitmap(bitmap);
                    }catch(Exception e){
                        if(picture!=null)picture.delete();
                        processing=false;take.setEnabled(true);
                        status.setText(I18n.tr(PhotoChallengeActivity.this,"Fotoğraf işlenemedi: "+e.getClass().getSimpleName()));
                    }
                }
                @Override public void onError(ImageCaptureException e){
                    if(picture!=null)picture.delete();
                    processing=false;take.setEnabled(true);
                    status.setText(I18n.tr(PhotoChallengeActivity.this,"Fotoğraf çekilemedi: "+e.getMessage()+". Sistem kamerasını deneyebilirsin."));
                }
            });
        }catch(Exception e){
            if(picture!=null)picture.delete();
            processing=false;take.setEnabled(true);
            status.setText(I18n.tr(this,"Kamera çekime başlayamadı: "+e.getClass().getSimpleName()+". Sistem kamerasını dene."));
        }
    }
    private void checkBitmap(Bitmap bitmap){
        if(bitmap==null){processing=false;take.setEnabled(true);status.setText(I18n.tr(this,"Fotoğraf alınamadı. Tekrar dene."));return;}
        if(calibrate){
            if(BedReferenceMatcher.fingerprint(bitmap)==null){processing=false;take.setEnabled(true);
                status.setText(I18n.tr(this,"Fotoğraf çok küçük. Tekrar dene."));return;}
            BedReferenceMatcher.save(this,bitmap);
            setResult(Activity.RESULT_OK,new Intent().putExtra("calibrated",true));finish();return;
        }
        status.setText(I18n.tr(this,"Nesne aranıyor..."));
        PhotoValidator.verify(this,bitmap,target,(passed,detail)->{
            if(isFinishing()||isDestroyed())return;
            processing=false;take.setEnabled(true);
            if(passed){setResult(Activity.RESULT_OK,new Intent());finish();}
            else status.setText(I18n.tr(PhotoChallengeActivity.this,detail)+" • "+I18n.tr(PhotoChallengeActivity.this,"Tekrar deneyebilirsin."));
        });
    }
    private void launchSystemCamera(){
        if(processing)return;
        try{
            Intent intent=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(intent,SYSTEM_CAMERA_REQUEST);
        }catch(Exception e){status.setText(I18n.tr(this,"Sistem kamerası açılamadı: "+e.getClass().getSimpleName()));}
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request!=SYSTEM_CAMERA_REQUEST || result!=RESULT_OK)return;
        Bitmap thumbnail=null;
        if(data!=null && data.getExtras()!=null){
            Object candidate=data.getExtras().get("data");
            if(candidate instanceof Bitmap)thumbnail=(Bitmap)candidate;
        }
        if(thumbnail==null){status.setText(I18n.tr(this,"Kamera fotoğraf döndürmedi; uygulama kamerasını deneyebilirsin."));return;}
        processing=true;take.setEnabled(false);
        checkBitmap(thumbnail);
    }
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] grant){super.onRequestPermissionsResult(request,permissions,grant);
        if(request==ASK_CAMERA){if(grant.length>0&&grant[0]==PackageManager.PERMISSION_GRANTED)startCamera();
            else status.setText(I18n.tr(this,"Kamera izni verilmedi. Alarm ekranına dönüp güvenli durdur seçeneğini kullan."));}
    }
    @Override protected void onDestroy(){if(picture!=null&&picture.exists())picture.delete();super.onDestroy();}
}
