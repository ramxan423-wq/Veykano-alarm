package com.wakemission.alarm;

/** Bounded normalized byte-vector similarity, deterministic and unit-testable. */
public final class SceneSimilarity {
    private SceneSimilarity(){}
    public static double score(byte[] a,byte[] b,int expected){
        if(a==null||b==null||a.length!=expected||b.length!=expected||expected<=0)return 0;
        double sum=0;
        for(int i=0;i<expected;i++)sum+=Math.abs((a[i]&255)-(b[i]&255));
        return Math.max(0,1-sum/(expected*255));
    }
}
