package com.wakemission.alarm;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

/** Precisely rounded yellow/grey reference progress track, without device-specific widget skins. */
public final class ReferenceProgressView extends View {
    private final Paint track=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint filled=new Paint(Paint.ANTI_ALIAS_FLAG);
    private int value=0,max=20;
    public ReferenceProgressView(Context c){super(c);
        track.setColor(0xA3E5E5E5);filled.setColor(0xFFFFCC32);
        setContentDescription("Şınav ilerlemesi: 0 / 20");
    }
    public void setMax(int count){max=Math.max(1,count);setProgress(value);}
    public void setProgress(int next){value=Math.max(0,Math.min(max,next));
        setContentDescription("Hareket ilerlemesi: "+value+" / "+max);invalidate();}
    @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);
        float left=getPaddingLeft(),top=getPaddingTop();
        float right=getWidth()-getPaddingRight(),bottom=getHeight()-getPaddingBottom();
        if(right<=left||bottom<=top)return;
        float r=(bottom-top)*.5f;
        canvas.drawRoundRect(left,top,right,bottom,r,r,track);
        float amount=(right-left)*value/(float)max;
        if(amount>0){float end=Math.min(right,left+Math.max(amount,2*r));
            canvas.save();canvas.clipRect(left,top,left+amount,bottom);
            canvas.drawRoundRect(left,top,end,bottom,r,r,filled);canvas.restore();}
    }
}
