package com.wakemission.alarm;

import android.app.*;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.speech.tts.TextToSpeech;
import java.util.Locale;
import android.media.MediaPlayer;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Handler;
import android.os.Looper;
import android.os.Vibrator;

public final class AlarmRingService extends Service {
    public static final String ACTION_STOP="com.wakemission.alarm.STOP";
    public static final String CHANNEL="wake_mission_alarm_v1";
    private static final int NOTIFICATION_ID=8001;
    private final Handler rampHandler=new Handler(Looper.getMainLooper());
    private MediaPlayer media;
    private TextToSpeech speaker;
    private ToneGenerator backupTone;
    private boolean fallbackScheduled=false;
    private Vibrator vibrator;
    private PowerManager.WakeLock wakeLock;

    @Override public void onCreate(){super.onCreate();
        NotificationManager nm=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        if(nm!=null && Build.VERSION.SDK_INT>=26){
            NotificationChannel ch=new NotificationChannel(CHANNEL,I18n.tr(this,"Çalan alarmlar"),NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription(I18n.tr(this,"Uyanma alarmı ve görev ekranı"));ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            ch.enableVibration(true);nm.createNotificationChannel(ch);
        }
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent!=null && ACTION_STOP.equals(intent.getAction())){stopSelf();return START_NOT_STICKY;}
        int id=intent==null?-1:intent.getIntExtra("alarm_id",-1);
        AlarmItem a=AlarmRepository.get(this,id);
        if(a==null){stopSelf();return START_NOT_STICKY;}
        Intent open=new Intent(this,AlarmActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP).putExtra("alarm_id",id);
        PendingIntent fullScreen=PendingIntent.getActivity(this,id,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification notification=new Notification.Builder(this,CHANNEL)
                .setSmallIcon(com.wakemission.alarm.R.drawable.ic_notification)
                .setContentTitle("⏰ " + a.title).setContentText(I18n.tr(this,"Görevi tamamla ve güne başla"))
                .setPriority(Notification.PRIORITY_MAX).setCategory(Notification.CATEGORY_ALARM)
                .setVisibility(Notification.VISIBILITY_PUBLIC).setOngoing(true)
                .setContentIntent(fullScreen).setFullScreenIntent(fullScreen,true).build();
        try{startForeground(NOTIFICATION_ID,notification);}catch(Exception e){stopSelf();return START_NOT_STICKY;}
        acquireWakeLock();playAlarm(a);
        speakCustomMessage(a);
        return START_NOT_STICKY;
    }
    private void speakCustomMessage(AlarmItem alarm){
        if(alarm.ttsMessage==null||alarm.ttsMessage.isEmpty())return;
        String spoken=alarm.ttsMessage;
        speaker=new TextToSpeech(this,status->{
            if(status==TextToSpeech.SUCCESS && speaker!=null){
                speaker.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
                speaker.setLanguage(Locale.getDefault());
                speaker.speak(spoken,TextToSpeech.QUEUE_FLUSH,null,"wake_mission_message");
            }
        });
    }
    private void acquireWakeLock(){
        try{PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);
            if(wakeLock!=null&&wakeLock.isHeld())return;
            wakeLock=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"WakeMission:alarm");wakeLock.acquire(10*60*1000L);
        }catch(Exception ignored){}
    }
    private void playAlarm(AlarmItem a){
        if(media!=null || fallbackScheduled)return;
        // Fail safe: first try user-selected, then device default alarm, then a generated beep.
        Uri chosen=a.ringtoneUri.isEmpty()?null:Uri.parse(a.ringtoneUri);
        Uri fallback=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        boolean playing=(chosen!=null && tryPlayer(chosen,a))
                || (fallback!=null && tryPlayer(fallback,a));
        if(!playing){
            Uri notification=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            playing=notification!=null && tryPlayer(notification,a);
        }
        if(!playing)startBackupBeep();
        if(a.vibrate){
            vibrator=(Vibrator)getSystemService(VIBRATOR_SERVICE);
            if(vibrator!=null && vibrator.hasVibrator())
                vibrator.vibrate(VibrationEffect.createWaveform(new long[]{0,500,500,500},0));
        }
    }
    private boolean tryPlayer(Uri ringtone,AlarmItem a){
        MediaPlayer candidate=null;
        try{
            candidate=new MediaPlayer();
            candidate.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            candidate.setDataSource(this,ringtone);
            candidate.setLooping(true);
            candidate.prepare();
            media=candidate;
            if(a.crescendo)media.setVolume(0.2f,0.2f);
            media.start();
            if(a.crescendo){
                for(int n=1;n<=6;n++){
                    final float volume=0.2f+0.8f*n/6;
                    rampHandler.postDelayed(()->{if(media!=null)media.setVolume(volume,volume);},n*5000L);
                }
            }
            return true;
        }catch(Exception exception){
            if(candidate!=null){try{candidate.release();}catch(Exception ignored){}}
            media=null;
            return false;
        }
    }
    private void startBackupBeep(){
        try{
            backupTone=new ToneGenerator(AudioManager.STREAM_ALARM,95);
            fallbackScheduled=true;
            // Using the local alarm stream works without a downloaded sound file.
            Runnable r=new Runnable(){
                @Override public void run(){
                    if(backupTone==null)return;
                    backupTone.startTone(ToneGenerator.TONE_PROP_BEEP2,750);
                    rampHandler.postDelayed(this,1400L);
                }
            };
            rampHandler.post(r);
        }catch(Exception ignored){fallbackScheduled=false;}
    }
    @Override public void onDestroy(){
        rampHandler.removeCallbacksAndMessages(null);
        if(media!=null){try{media.stop();}catch(Exception ignored){}media.release();media=null;}
        if(speaker!=null){speaker.stop();speaker.shutdown();speaker=null;}
        if(backupTone!=null){backupTone.stopTone();backupTone.release();backupTone=null;}
        fallbackScheduled=false;
        if(vibrator!=null)vibrator.cancel();
        if(wakeLock!=null&&wakeLock.isHeld())wakeLock.release();
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent){return null;}
}
