package com.wakemission.alarm;

/** Approximate sit-up counter for a fixed SIDE camera: reclined -> sitting -> reclined. */
public final class SitupCounter {
    private enum Phase { WAIT_DOWN, WAIT_UP, WAIT_RETURN }
    private Phase phase=Phase.WAIT_DOWN;
    private int count,downFrames,upFrames,returnFrames;
    private long lastCountMs=-10000,upAtMs;
    public int count(){return count;}
    public void interrupt(){phase=Phase.WAIT_DOWN;downFrames=0;upFrames=0;returnFrames=0;}
    public void reset(){count=0;lastCountMs=-10000;interrupt();}
    public int addAngle(double hipAngle,long nowMs){
        if(!Double.isFinite(hipAngle)||hipAngle<40||hipAngle>180)return count;
        if(phase==Phase.WAIT_DOWN){
            downFrames=hipAngle>=138?downFrames+1:0;
            if(downFrames>=2){phase=Phase.WAIT_UP;upFrames=0;}
        }else if(phase==Phase.WAIT_UP){
            if(hipAngle<=110){upFrames++;if(upFrames>=2){phase=Phase.WAIT_RETURN;returnFrames=0;upAtMs=nowMs;}}
            else if(hipAngle>120)upFrames=0;
        }else{
            returnFrames=hipAngle>=138?returnFrames+1:0;
            if(returnFrames>=2 && nowMs-upAtMs>=300 && nowMs-lastCountMs>=700){
                count++;lastCountMs=nowMs;interrupt();
            }
        }
        return count;
    }
}
