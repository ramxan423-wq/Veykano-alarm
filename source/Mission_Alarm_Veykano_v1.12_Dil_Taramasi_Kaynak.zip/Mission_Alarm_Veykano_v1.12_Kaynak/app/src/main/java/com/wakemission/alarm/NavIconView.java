package com.wakemission.alarm;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

/** Crisp stroke icons with no external font, matching the low-profile glass navigation. */
public final class NavIconView extends View {
    private final String icon;private final int color;private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    public NavIconView(Context c,String icon,int color){super(c);this.icon=icon;this.color=color;setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
    @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);float s=Math.min(getWidth(),getHeight())/24f;
        canvas.save();canvas.translate((getWidth()-24*s)/2f,(getHeight()-24*s)/2f);canvas.scale(s,s);
        paint.setColor(color);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(1.8f);paint.setStrokeJoin(Paint.Join.ROUND);paint.setStrokeCap(Paint.Cap.ROUND);
        switch(icon){
            case "home":{Path p=new Path();p.moveTo(3,10);p.lineTo(12,3);p.lineTo(21,10);p.moveTo(5.5f,9);p.lineTo(5.5f,21);p.lineTo(18.5f,21);p.lineTo(18.5f,9);p.moveTo(10,21);p.lineTo(10,14);p.lineTo(14,14);p.lineTo(14,21);canvas.drawPath(p,paint);break;}
            case "alarm":{canvas.drawCircle(12,13,7.5f,paint);canvas.drawLine(12,13,12,8,paint);canvas.drawLine(12,13,15,15,paint);canvas.drawArc(3,3,9,9,180,130,false,paint);canvas.drawArc(15,3,21,9,230,130,false,paint);break;}
            case "person":{canvas.drawCircle(12,7.5f,4,paint);canvas.drawRoundRect(5,14,19,21,6,6,paint);break;}
            case "tasks":{canvas.drawRoundRect(4,4,20,20,3,3,paint);canvas.drawLine(7.5f,9,10.5f,12,paint);canvas.drawLine(10.5f,12,16,7,paint);canvas.drawLine(8,16,16,16,paint);break;}
            case "stats":{canvas.drawLine(4,21,20,21,paint);canvas.drawRoundRect(5,13,8,20,1,1,paint);canvas.drawRoundRect(11,9,14,20,1,1,paint);canvas.drawRoundRect(17,4,20,20,1,1,paint);break;}
            case "moon":{Path p=new Path();p.moveTo(16,3);p.cubicTo(9,5,8,15,16,19);p.cubicTo(5,22,1,10,9,4);p.cubicTo(12,2.5f,14,2.5f,16,3);canvas.drawPath(p,paint);break;}
            case "award":{canvas.drawCircle(12,9,5.2f,paint);Path p=new Path();p.moveTo(8,13);p.lineTo(7,21);p.lineTo(12,18);p.lineTo(17,21);p.lineTo(16,13);canvas.drawPath(p,paint);break;}
            default:{canvas.drawCircle(12,12,8,paint);canvas.drawCircle(12,12,3,paint);for(int i=0;i<8;i++){double a=i*Math.PI/4;float x=(float)Math.cos(a),y=(float)Math.sin(a);canvas.drawLine(12+x*9.1f,12+y*9.1f,12+x*11,12+y*11,paint);}break;}
        }
        canvas.restore();
    }
}
