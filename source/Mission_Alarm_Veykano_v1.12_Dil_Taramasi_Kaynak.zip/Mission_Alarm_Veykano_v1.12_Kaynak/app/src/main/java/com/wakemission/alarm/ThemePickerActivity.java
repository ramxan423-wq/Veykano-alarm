package com.wakemission.alarm;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Settings > Theme: four selectable, persistent palettes with live swatch previews. */
public final class ThemePickerActivity extends Activity {
    @Override public void onCreate(Bundle state){super.onCreate(state);AppTheme.apply(this);render();}
    private void render(){
        ScrollView scroll=new ScrollView(this);scroll.setBackgroundColor(Ui.BG);scroll.setFillViewport(true);
        LinearLayout root=Ui.column(this);root.setPadding(Ui.dp(this,19),Ui.dp(this,32),Ui.dp(this,19),Ui.dp(this,30));scroll.addView(root);
        TextView back=Ui.text(this,"‹  Ayarlar",16,Ui.PURPLE,true);back.setOnClickListener(v->finish());root.addView(back);Ui.space(root,19);
        root.addView(Ui.text(this,"Tema Seç",29,Ui.WHITE,true));Ui.space(root,7);
        root.addView(Ui.text(this,"Görünümünü seç. Değişiklik hemen uygulanır ve kaydedilir.",14,Ui.MUTED,false));Ui.space(root,25);
        String active=AppTheme.selected(this);
        for(AppTheme theme:AppTheme.options()){
            LinearLayout entry=Ui.row(this);entry.setPadding(Ui.dp(this,14),Ui.dp(this,12),Ui.dp(this,12),Ui.dp(this,12));
            entry.setBackground(Ui.stroked(Ui.PANEL,22,theme.key.equals(active)?Ui.PURPLE:Ui.OUTLINE,this));
            View preview=preview(theme);
            entry.addView(preview,new LinearLayout.LayoutParams(Ui.dp(this,76),Ui.dp(this,106)));
            LinearLayout details=Ui.column(this);details.setPadding(Ui.dp(this,14),0,0,0);
            details.addView(Ui.text(this,theme.title,17,Ui.WHITE,true));Ui.space(details,5);
            details.addView(Ui.text(this,theme.subtitle,12,Ui.MUTED,false));
            entry.addView(details,new LinearLayout.LayoutParams(0,-2,1));
            TextView marker=Ui.text(this,theme.key.equals(active)?"●":"○",23,theme.key.equals(active)?Ui.PURPLE:Ui.MUTED,true);
            entry.addView(marker);root.addView(entry,Ui.matchMargins(this,12));
            entry.setOnClickListener(v->{AppTheme.choose(this,theme.key);AppTheme.apply(this);render();});
        }
        Ui.space(root,9);
        root.addView(Ui.text(this,"Sabah Işığı yeni varsayılandır. Beyaz Bordo ve önceki diğer temaların hepsi korunur.",12,Ui.MUTED,false));
        setContentView(scroll);
    }
    private View preview(AppTheme theme){
        LinearLayout tile=Ui.column(this);tile.setGravity(Gravity.CENTER_HORIZONTAL);
        tile.setPadding(Ui.dp(this,7),Ui.dp(this,12),Ui.dp(this,7),Ui.dp(this,7));
        tile.setBackground(Ui.stroked(theme.background,15,theme.outline,this));
        TextView header=new TextView(this);header.setText(I18n.tr(this,"Mission Alarm Veykano"));header.setTextSize(7);header.setTextColor(theme.ink);
        header.setTypeface(Typeface.DEFAULT,Typeface.BOLD);tile.addView(header);
        Ui.space(tile,10);
        TextView time=new TextView(this);time.setText(I18n.tr(this,"07:30"));time.setTextSize(16);time.setTextColor(theme.ink);
        time.setTypeface(Typeface.DEFAULT,Typeface.BOLD);time.setGravity(Gravity.CENTER);
        time.setBackground(Ui.shape(theme.panel,10,this));tile.addView(time,new LinearLayout.LayoutParams(-1,Ui.dp(this,29)));
        Ui.space(tile,8);
        View action=new View(this);GradientDrawable grad=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
            new int[]{theme.primary,theme.gradientEnd});grad.setCornerRadius(Ui.dp(this,9));action.setBackground(grad);
        tile.addView(action,new LinearLayout.LayoutParams(-1,Ui.dp(this,12)));
        Ui.space(tile,9);
        View nav=new View(this);nav.setBackground(Ui.shape(theme.nav,9,this));tile.addView(nav,new LinearLayout.LayoutParams(-1,Ui.dp(this,8)));
        return tile;
    }
}
