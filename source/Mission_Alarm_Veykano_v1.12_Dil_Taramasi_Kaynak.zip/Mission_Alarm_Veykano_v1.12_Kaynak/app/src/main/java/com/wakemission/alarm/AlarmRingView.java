package com.wakemission.alarm;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Lightweight, static custom view for the large premium-white alarm dial. */
public final class AlarmRingView extends View {
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final String time,caption,detail;
    public AlarmRingView(Context c,String time,String caption,String detail){super(c);this.time=time;this.caption=caption;this.detail=detail;}
    @Override protected void onMeasure(int w,int h){setMeasuredDimension(MeasureSpec.getSize(w),Ui.dp(getContext(),220));}
    @Override protected void onDraw(Canvas c){super.onDraw(c);float density=getResources().getDisplayMetrics().density;
        float cx=getWidth()/2f,cy=getHeight()/2f,r=91*density;
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(6*density);p.setStrokeCap(Paint.Cap.ROUND);
        p.setColor(Ui.OUTLINE);c.drawCircle(cx,cy,r,p);
        p.setColor(Ui.PURPLE);c.drawArc(new RectF(cx-r,cy-r,cx+r,cy+r),-84,270,false,p);
        p.setStyle(Paint.Style.FILL);p.setTextAlign(Paint.Align.CENTER);p.setColor(Ui.PEACH);
        p.setTextSize(22*density);c.drawText("☀",cx,cy-43*density,p);
        p.setColor(Ui.WHITE);p.setFakeBoldText(true);p.setTextSize(40*density);c.drawText(time,cx,cy+5*density,p);
        p.setFakeBoldText(false);p.setTextSize(14*density);c.drawText(caption,cx,cy+27*density,p);
        p.setColor(Ui.MUTED);p.setTextSize(11*density);c.drawText(detail,cx,cy+46*density,p);
    }
}
