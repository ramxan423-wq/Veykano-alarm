package com.wakemission.alarm;

import android.content.Context;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;

/** Offline UI localization, no network requests. Missing locales fallback to English. */
public final class I18n {
    private I18n(){}
    private static final HashMap<String,JSONObject> cache=new HashMap<>();
    public static String selected(Context c){
        return c.getSharedPreferences("display_settings",Context.MODE_PRIVATE).getString("language","en");
    }
    public static String language(Context c){
        String s=selected(c);
        if("system".equals(s))s=java.util.Locale.getDefault().getLanguage(); // legacy preference
        return s;
    }
    /** Locale of the user-selected language; independent from Android system language. */
    public static java.util.Locale locale(Context c){
        String tag=language(c);
        java.util.Locale result=java.util.Locale.forLanguageTag(tag);
        return result.getLanguage().isEmpty()?java.util.Locale.ENGLISH:result;
    }
    private static JSONObject read(Context c,String language){
        try(InputStream in=c.getAssets().open("translations_"+language+".json");ByteArrayOutputStream bytes=new ByteArrayOutputStream()){
            byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1)bytes.write(b,0,n);
            return new JSONObject(new String(bytes.toByteArray(),StandardCharsets.UTF_8));
        }catch(Exception e){return new JSONObject();}
    }
    private static JSONObject map(Context c,String tag){
        synchronized(cache){
            if(!cache.containsKey(tag))cache.put(tag,read(c,tag));
            return cache.get(tag);
        }
    }
    private static String match(JSONObject map,String message){
        String exact=map.optString(message,null);
        if(exact!=null)return exact;
        String best=null;
        java.util.Iterator<String> it=map.keys();
        while(it.hasNext()){
            String k=it.next();
            if(k.length()>6&&message.startsWith(k)&&
                (best==null||k.length()>best.length()))best=k;
        }
        return best==null?null:map.optString(best)+message.substring(best.length());
    }
    public static boolean isRtl(Context c){
        String tag=language(c).split("-")[0];
        return tag.equals("ar")||tag.equals("he")||tag.equals("fa")||tag.equals("ur")||tag.equals("ps")||tag.equals("sd")||tag.equals("yi")||tag.equals("ug")||tag.equals("ckb");
    }
    public static String tr(Context c,String message){
        if(message==null)return "";
        String lang=language(c);
        if("tr".equals(lang)){
            String x=match(map(c,"tr"),message);
            return x==null?message:x;
        }
        String local=match(map(c,lang),message);
        if(local==null&&lang.contains("-"))
            local=match(map(c,lang.substring(0,lang.indexOf('-'))),message);
        if(local!=null)return local;
        String en=match(map(c,"en"),message);
        return en==null?message:en;
    }
}
