package com.wakemission.alarm;
import java.util.Random;

/** Never repeats the previous object within a task chain. */
public final class ObjectHunt {
    private static final String[] TARGETS={"SKY","BOOK","CUP","PET","SHOE","BOTTLE","CHAIR"};
    private ObjectHunt(){}
    public static String next(Random rng,String previous){
        int index=rng.nextInt(TARGETS.length);
        if(TARGETS[index].equals(previous))index=(index+1+rng.nextInt(TARGETS.length-1))%TARGETS.length;
        return TARGETS[index];
    }
}
