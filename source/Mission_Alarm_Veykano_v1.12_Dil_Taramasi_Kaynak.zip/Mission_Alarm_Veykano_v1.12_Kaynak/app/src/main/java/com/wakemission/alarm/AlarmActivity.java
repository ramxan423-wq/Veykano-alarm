package com.wakemission.alarm;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.speech.RecognizerIntent;
import java.util.ArrayList;
import java.text.Normalizer;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import java.util.Locale;
import java.util.Random;

public final class AlarmActivity extends Activity implements SensorEventListener {
    private static final int PHOTO_REQUEST=42, STEP_PERMISSION=200, PHOTO_PERMISSION=201, EXERCISE_REQUEST=203, VOICE_REQUEST=204;
    private AlarmItem alarm;
    private LinearLayout root, content;
    private TextView progress, prompt, status;
    private EditText answer;
    private SensorManager sensors;
    private Sensor activeSensor;
    private final Random random=new Random();
    private final Handler handler=new Handler(Looper.getMainLooper());
    private int remaining=0, expectedNumber=0, sensorCount=0;
    private String expectedString="", activeMission="";
    private long lastSensorEvent=0;
    private float stepCounterStart=-1f;
    private final WalkingMotionCounter walkingMotionCounter=new WalkingMotionCounter();
    private int snoozed=0;
    private boolean finished=false;
    private String currentPhotoTarget="SKY";
    private long taskStarted=0;

    @Override public void onCreate(Bundle state){super.onCreate(state);AppTheme.apply(this);
        if(Build.VERSION.SDK_INT>=27){setShowWhenLocked(true);setTurnScreenOn(true);}
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON|
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED|
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        int id=getIntent().getIntExtra("alarm_id",-1);
        alarm=AlarmRepository.get(this,id);
        if(alarm==null){finish();return;}
        snoozed=getSharedPreferences("snoozes",MODE_PRIVATE).getInt("snooze_"+id,0);
        taskStarted=android.os.SystemClock.elapsedRealtime();
        remaining=Math.max(1,alarm.challengeCount);
        setup();nextChallenge();
    }
    private void setup(){
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true);scroll.setBackgroundColor(Ui.BG);
        root=Ui.column(this);root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(Ui.dp(this,22),Ui.dp(this,42),Ui.dp(this,22),Ui.dp(this,25));scroll.addView(root);
        TextView brand=Ui.text(this,"MISSION ALARM VEYKANO  •  WAKE-UP TIME",13,Ui.PEACH,true);
        brand.setGravity(Gravity.CENTER);root.addView(brand);Ui.space(root,30);
        TextView clock=Ui.text(this,alarm.timeText(),64,Ui.WHITE,true);clock.setGravity(Gravity.CENTER);root.addView(clock);
        TextView title=Ui.text(this,alarm.title,21,Ui.MUTED,false);title.setGravity(Gravity.CENTER);root.addView(title);Ui.space(root,25);
        progress=Ui.text(this,"",15,Ui.GREEN,true);progress.setGravity(Gravity.CENTER);root.addView(progress);Ui.space(root,10);
        content=Ui.card(this);root.addView(content,Ui.matchMargins(this,18));
        prompt=Ui.text(this,"",24,Ui.WHITE,true);prompt.setGravity(Gravity.CENTER);content.addView(prompt,Ui.matchMargins(this,16));
        status=Ui.text(this,"",14,Ui.MUTED,false);status.setGravity(Gravity.CENTER);content.addView(status,Ui.matchMargins(this,14));
        Ui.space(root,18);
        if(alarm.snoozeMax>0 && snoozed<alarm.snoozeMax){
            Button snooze=Ui.button(this,"Ertele  •  "+alarm.snoozeMinutes+" dk ("+(alarm.snoozeMax-snoozed)+" hak)",false);
            root.addView(snooze,Ui.matchMargins(this,12));snooze.setOnClickListener(v->snooze());
        }
        Button safe=Ui.button(this,"Güvenli durdur",false);
        root.addView(safe,Ui.matchMargins(this,7));safe.setOnClickListener(v->confirmStop());
        TextView safety=Ui.text(this,"Görev çalışmazsa alarmı bu düğmeyle güvenle kapatabilirsin.",12,Ui.MUTED,false);
        safety.setGravity(Gravity.CENTER);root.addView(safety);
        setContentView(scroll);
    }
    private void nextChallenge(){
        unregisterSensors();
        // Cancel any pending memory-hide action from the previous mission.
        handler.removeCallbacksAndMessages(null);
        answer=null;
        for(int i=content.getChildCount()-1;i>=2;i--)content.removeViewAt(i);
        if(remaining<=0){complete();return;}
        activeMission=alarm.mission;
        if(AlarmItem.CHAIN.equals(activeMission)){
            String[] order={AlarmItem.MATH,AlarmItem.MEMORY,AlarmItem.TYPE,AlarmItem.SHAKE,AlarmItem.WALK,AlarmItem.PUSHUP};
            activeMission=order[(alarm.challengeCount-remaining)%order.length];
        }
        progress.setText(I18n.tr(this,AlarmItem.missionName(activeMission))+"  •  "+(alarm.challengeCount-remaining+1)+" / "+alarm.challengeCount);
        status.setText(I18n.tr(this,""));
        switch(activeMission){
            case AlarmItem.QR:qrTask();break;
            case AlarmItem.TYPE:typeTask();break;
            case AlarmItem.MEMORY:memoryTask();break;
            case AlarmItem.SHAKE:motionTask(false);break;
            case AlarmItem.WALK:motionTask(true);break;
            case AlarmItem.PHOTO:photoTask();break;
            case AlarmItem.BED:photoTask();break;
            case AlarmItem.PUSHUP:exerciseTask(false);break;
            case AlarmItem.SQUAT:exerciseTask(true);break;
            case AlarmItem.YOGA:yogaTask();break;
            case AlarmItem.SITUP:situpTask();break;
            case AlarmItem.CALORIE:calorieTask();break;
            case AlarmItem.VOICE:voiceTask();break;
            default:mathTask();break;
        }
    }
    private void inputField(String hint){
        answer=new EditText(this);answer.setSingleLine(true);answer.setTextColor(Ui.WHITE);answer.setHintTextColor(Ui.MUTED);
        answer.setHint(hint);answer.setTextSize(19);answer.setSelectAllOnFocus(true);
        content.addView(answer,Ui.matchMargins(this,12));
    }
    private void addAction(String label,Runnable callback){
        Button b=Ui.button(this,label,true);content.addView(b,Ui.matchMargins(this,6));b.setOnClickListener(v->callback.run());
    }
    private void wrong(){status.setText(I18n.tr(this,"Henüz doğru değil. Tekrar dene."));status.setTextColor(Ui.PEACH);}
    private void pass(){
        if(finished)return;
        remaining--;
        if(remaining<=0)complete();else nextChallenge();
    }
    private void mathTask(){
        int level=Math.min(12,1+alarm.difficulty*3+alarm.challengeCount);
        int a=random.nextInt(9+level*3)+2,b=random.nextInt(9+level*3)+2;
        if(random.nextBoolean()){expectedNumber=a+b;prompt.setText(a+"  +  "+b+"  = ?");}
        else {expectedNumber=a;prompt.setText((a+b)+"  −  "+b+"  = ?");}
        status.setText(I18n.tr(this,"Doğru sonucu gir."));inputField("Cevap");answer.setInputType(2);
        addAction("Kontrol et",()->{try{if(Integer.parseInt(answer.getText().toString().trim())==expectedNumber)pass();else wrong();}
            catch(Exception ignored){wrong();}});
    }
    private void typeTask(){
        expectedString="YATAGIMDAN KALKIYORUM";prompt.setText(I18n.tr(this,"Cümleyi yaz"));
        status.setText(expectedString);inputField("Cümleyi buraya yaz");
        addAction("Kontrol et",()->{String typed=answer.getText().toString().trim().toUpperCase(new Locale("tr","TR"));
            if(typed.equals(expectedString))pass();else wrong();});
    }
    private void memoryTask(){
        expectedString=String.format(Locale.ROOT,"%04d",random.nextInt(9000)+1000);
        prompt.setText(expectedString);status.setText(I18n.tr(this,"Sayıyı ezberle; dört saniye sonra gizlenecek."));
        inputField("Dört haneli sayı");answer.setInputType(2);
        final String code=expectedString;
        handler.postDelayed(()->{if(!finished && code.equals(expectedString) && prompt!=null){prompt.setText(I18n.tr(this,"••••"));status.setText(I18n.tr(this,"Hatırladığın sayıyı gir."));}},4000);
        addAction("Hatırladım",()->{if(answer.getText().toString().trim().equals(code))pass();else wrong();});
    }
    private void qrTask(){
        if(alarm.barcode.isEmpty()){
            prompt.setText(I18n.tr(this,"QR kod ayarlanmamış"));status.setText(I18n.tr(this,"Alarm düzenleme ekranında barkod belirlemelisin."));return;
        }
        prompt.setText(I18n.tr(this,"QR / barkod okut"));status.setText(I18n.tr(this,"Alarm oluştururken belirlediğin kodu okut. Başka kod kabul edilmeyecek."));
        addAction("Kamerayı aç",()->{
            try{
                IntentIntegrator scanner=new IntentIntegrator(this);
                scanner.setDesiredBarcodeFormats(IntentIntegrator.ALL_CODE_TYPES);
                scanner.setPrompt("Kayıtlı QR kodu / barkodu okut");scanner.setBeepEnabled(false);
                scanner.setOrientationLocked(true);scanner.initiateScan();
            }catch(Exception e){status.setText(I18n.tr(this,"Kamera açılamadı. Güvenli durdurmayı kullan."));}
        });
    }
    private void motionTask(boolean walk){
        sensorCount=0;lastSensorEvent=0;stepCounterStart=-1f;walkingMotionCounter.reset();
        prompt.setText(I18n.tr(this,walk?"Yürüme görevi":"Sallama görevi"));
        if(walk){
            addAction("Adımlar sayılmıyorsa alternatif algılama",()->startAccelerometerWalkingFallback());
            status.setText(walkTarget()+" adım yürü. Telefonu cebinde veya elinde taşı.");
            if(Build.VERSION.SDK_INT>=29 && checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION)!=PackageManager.PERMISSION_GRANTED){
                requestPermissions(new String[]{Manifest.permission.ACTIVITY_RECOGNITION},STEP_PERMISSION);return;
            }
        }else status.setText(I18n.tr(this,"Telefonu "+shakeTarget()+" kez kuvvetlice salla."));
        startSensor(walk);
    }
    private int walkTarget(){return alarm.difficulty==1?10:alarm.difficulty==3?40:20;}
    private int shakeTarget(){return alarm.difficulty==1?8:alarm.difficulty==3?20:12;}
    private void startSensor(boolean walk){
        unregisterSensors();
        sensors=(SensorManager)getSystemService(SENSOR_SERVICE);
        if(sensors==null){status.setText(I18n.tr(this,"Hareket sensörlerine erişilemedi. Güvenli durdurmayı kullan."));return;}
        if(walk){
            // Some devices (including older Huawei models) have no hardware step detector.
            int[] alternatives={Sensor.TYPE_STEP_DETECTOR,Sensor.TYPE_STEP_COUNTER,Sensor.TYPE_ACCELEROMETER};
            for(int type:alternatives){
                Sensor available=sensors.getDefaultSensor(type);
                if(available==null)continue;
                try{
                    if(sensors.registerListener(this,available,type==Sensor.TYPE_ACCELEROMETER?
                            SensorManager.SENSOR_DELAY_GAME:SensorManager.SENSOR_DELAY_NORMAL)){
                        activeSensor=available;
                        status.setText(type==Sensor.TYPE_ACCELEROMETER?
                            "Adım sensörü yok: hareket algılaması kullanılıyor. Telefonu cebinde tut ve normal tempoda yürü. 0 / "+walkTarget():
                            "Yürüme algılanıyor. Telefonu yanında taşı. 0 / "+walkTarget());
                        return;
                    }
                }catch(SecurityException ignored){/* Activity recognition can be denied; try accelerometer. */}
            }
            status.setText(I18n.tr(this,"Bu telefonda yürümeyi algılayacak sensör bulunamadı. Güvenli durdurmayı kullan."));
        }else{
            activeSensor=sensors.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            if(activeSensor==null || !sensors.registerListener(this,activeSensor,SensorManager.SENSOR_DELAY_NORMAL))
                status.setText(I18n.tr(this,"Sallama sensörü çalışmıyor. Güvenli durdurmayı kullan."));
        }
    }
    @Override public void onSensorChanged(SensorEvent e){
        if(finished||alarm==null||activeSensor==null||
            (!AlarmItem.WALK.equals(activeMission)&&!AlarmItem.SHAKE.equals(activeMission)))return;
        if(e.sensor.getType()!=activeSensor.getType())return;
        boolean walking=AlarmItem.WALK.equals(activeMission);
        if(walking){
            if(e.sensor.getType()==Sensor.TYPE_STEP_COUNTER){
                float reading=e.values[0];
                if(stepCounterStart<0 || reading<stepCounterStart){stepCounterStart=reading;return;}
                int steps=Math.max(0,(int)(reading-stepCounterStart));
                if(steps<=sensorCount)return;
                sensorCount=steps;
            }else if(e.sensor.getType()==Sensor.TYPE_STEP_DETECTOR){
                sensorCount+=Math.max(1,Math.round(e.values[0]));
            }else if(e.sensor.getType()==Sensor.TYPE_ACCELEROMETER){
                int delta=walkingMotionCounter.onSample(e.timestamp,e.values[0],e.values[1],e.values[2]);
                if(delta==0)return;
                sensorCount+=delta;
            }else return;
        }else{
            double mag=Math.sqrt(e.values[0]*e.values[0]+e.values[1]*e.values[1]+e.values[2]*e.values[2]);
            if(mag<17.5)return;
            long now=android.os.SystemClock.elapsedRealtime();
            if(now-lastSensorEvent<350)return;
            lastSensorEvent=now;sensorCount++;
        }
        int target=walking?walkTarget():shakeTarget();
        status.setText(I18n.tr(this,"Algılanan: "+Math.min(sensorCount,target)+" / "+target));
        if(sensorCount>=target)pass();
    }
    @Override public void onAccuracyChanged(Sensor sensor,int accuracy){}
    @Override public void onRequestPermissionsResult(int code,String[] permissions,int[] results){
        super.onRequestPermissionsResult(code,permissions,results);
        if(code==PHOTO_PERMISSION && !finished && (AlarmItem.PHOTO.equals(activeMission)||AlarmItem.BED.equals(activeMission))){
            if(results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED)launchPhoto();
            else status.setText(I18n.tr(this,"Kamera izni verilmedi. Güvenli durdurmayı kullan."));
        }
        if(code==STEP_PERMISSION && !finished && AlarmItem.WALK.equals(activeMission)){
            if(results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED)startSensor(true);
            else {
                // Without ACTIVITY_RECOGNITION, accelerometer still works on Android 10+.
                startAccelerometerWalkingFallback();
            }}
    }
    private void startAccelerometerWalkingFallback(){
        unregisterSensors();
        sensors=(SensorManager)getSystemService(SENSOR_SERVICE);
        activeSensor=sensors==null?null:sensors.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        if(activeSensor==null || !sensors.registerListener(this,activeSensor,SensorManager.SENSOR_DELAY_GAME)){
            status.setText(I18n.tr(this,"Adım izni verilmedi ve hareket sensörü çalışmıyor. Güvenli durdurmayı kullan."));
            return;
        }
        walkingMotionCounter.reset();
        status.setText(I18n.tr(this,"Hareket algılaması etkin. Telefonu cebinde taşı ve yürü. 0 / "+walkTarget()));
    }
    private void exerciseTask(boolean squat){
        prompt.setText(I18n.tr(this,squat?"Kamera: Squat":"Kamera: Şınav"));
        int target=alarm.difficulty==1?10:alarm.difficulty==3?30:20;
        status.setText(target+" tekrar yap. Telefonu sabitle, tüm vücudun kadraja sığsın. Kameradan çıkarsan alarm çalmaya devam eder.");
        addAction("Kamera ile hareket say",()->{
            Intent i=new Intent(this,CameraExerciseActivity.class)
                .putExtra(CameraExerciseActivity.EXTRA_KIND,squat?"SQUAT":"PUSHUP")
                .putExtra(CameraExerciseActivity.EXTRA_TARGET,target);
            try{startActivityForResult(i,EXERCISE_REQUEST);}catch(Exception e){status.setText(I18n.tr(this,"Kamera görevi açılamadı: "+e.getMessage()));}
        });
    }
    private void situpTask(){
        int n=alarm.situpTarget;
        prompt.setText(I18n.tr(this,"Kamera: Mekik"));
        status.setText(I18n.tr(this,"Yandan kameraya görünerek "+n+" mekik yap. Yatış, doğrulma ve yeniden yatış sayılır. Telefonu sabitle."));
        addAction("Kamerayla mekik say",()->{
            Intent i=new Intent(this,CameraExerciseActivity.class)
                .putExtra(CameraExerciseActivity.EXTRA_KIND,"SITUP")
                .putExtra(CameraExerciseActivity.EXTRA_TARGET,n);
            try{startActivityForResult(i,EXERCISE_REQUEST);}catch(Exception e){status.setText(I18n.tr(this,"Mekik kamerası açılamadı: "+e.getMessage()));}
        });
    }
    private void calorieTask(){
        int goal=CalorieEstimate.safeGoal(alarm.calorieGoal);
        String kind=CalorieEstimate.safeActivity(alarm.calorieActivity);
        prompt.setText(I18n.tr(this,"Kalori Modu"));
        status.setText(I18n.tr(this,"Hedef: yaklaşık "+goal+" kcal. Egzersiz: "+
            ("SQUAT".equals(kind)?"Squat":"PUSHUP".equals(kind)?"Şınav":"Mekik")+
            ", ağırlık: "+alarm.calorieWeightKg+" kg. Kamera tekrarları sayar, kalori yalnızca tahmindir."));
        addAction("Kamera ile kalori görevini başlat",()->{
            Intent i=new Intent(this,CameraExerciseActivity.class)
                .putExtra(CameraExerciseActivity.EXTRA_KIND,"CALORIE")
                .putExtra(CameraExerciseActivity.EXTRA_ACTIVITY,kind)
                .putExtra(CameraExerciseActivity.EXTRA_CALORIE_GOAL,goal)
                .putExtra(CameraExerciseActivity.EXTRA_WEIGHT_KG,alarm.calorieWeightKg);
            try{startActivityForResult(i,EXERCISE_REQUEST);}catch(Exception e){status.setText(I18n.tr(this,"Kalori kamerası açılamadı: "+e.getMessage()));}
        });
    }
    private void yogaTask(){
        String pose=YogaPoseLogic.title(alarm.yogaPose);
        int duration=YogaHoldTimer.safeSeconds(alarm.yogaHoldSeconds);
        prompt.setText(I18n.tr(this,"Yoga: "+pose));
        status.setText(duration+" saniye pozu koru. Telefonu sabitle, tüm vücudun kadraja sığsın. " +
            "Kamera üzerinde algılanamazsan mevcut Güvenli durdur düğmesini kullanabilirsin.");
        addAction("Kamerayla yoga pozunu başlat",()->{
            Intent i=new Intent(this,CameraExerciseActivity.class)
                .putExtra(CameraExerciseActivity.EXTRA_KIND,"YOGA")
                .putExtra(CameraExerciseActivity.EXTRA_POSE,alarm.yogaPose)
                .putExtra(CameraExerciseActivity.EXTRA_TARGET,duration);
            try{startActivityForResult(i,EXERCISE_REQUEST);}catch(Exception e){status.setText(I18n.tr(this,"Yoga kamerası açılamadı: "+e.getMessage()));}
        });
    }
    private void voiceTask(){
        prompt.setText(I18n.tr(this,"Cümleyi sesli oku"));status.setText(alarm.voicePhrase);
        addAction("Mikrofonu aç",()->{
            try{
                Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,I18n.language(this).equals("en")?"en-US":I18n.language(this).equals("es")?"es-ES":"tr-TR");
                i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE,true);
                i.putExtra(RecognizerIntent.EXTRA_PROMPT,alarm.voicePhrase);
                startActivityForResult(i,VOICE_REQUEST);
            }catch(Exception e){status.setText(I18n.tr(this,"Konuşma tanıma servisi yok. Güvenli durdurmayı kullan."));}
        });
    }
    static String normalizeWords(String s){
        String x=Normalizer.normalize(s.toUpperCase(new Locale("tr","TR")),Normalizer.Form.NFD);
        return x.replaceAll("\\p{M}+","").replaceAll("[^A-Z0-9\\s]", " ").replaceAll("\\s+", " ").trim();
    }
    private void photoTask(){
        currentPhotoTarget=AlarmItem.BED.equals(activeMission)?"BED":
            ("RANDOM".equals(alarm.photoTarget)?ObjectHunt.next(random,currentPhotoTarget):alarm.photoTarget);
        prompt.setText(I18n.tr(this,AlarmItem.BED.equals(activeMission)?"Yatağını topla":"Fotoğraf çek"));
        String target=photoTargetText();
        status.setText(AlarmItem.BED.equals(activeMission)
            ?"Yatağını topla. Ardından önceden kaydettiğin toplu yatak örneğiyle aynı açıdan fotoğraf çek. Görsel karşılaştırma kesin doğrulama değildir."
            :"Kamerayla "+target+" fotoğrafı çek. Nesne cihazda aranır. Yatak için toplu yatak örneği karşılaştırılır.");
        addAction("Fotoğraf çek",()->{
            if(checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){
                requestPermissions(new String[]{Manifest.permission.CAMERA},PHOTO_PERMISSION);
            }else launchPhoto();
        });
    }
    private String photoTargetText(){
        switch(currentPhotoTarget){case "BED":return "toplu yatak";case "BOOK":return "kitap";
            case "CUP":return "bardak";case "PET":return "evcil hayvan";
            case "SHOE":return "ayakkabı";case "BOTTLE":return "şişe";case "CHAIR":return "sandalye";
            default:return "gökyüzü";}
    }
    private void launchPhoto(){
        try{startActivityForResult(new Intent(this,PhotoChallengeActivity.class)
            .putExtra(PhotoChallengeActivity.EXTRA_TARGET,currentPhotoTarget),PHOTO_REQUEST);}
        catch(Exception e){status.setText(I18n.tr(this,"Fotoğraf görevi açılamadı. Güvenli durdurmayı kullan."));}
    }
    @Override protected void onActivityResult(int req,int result,Intent data){
        super.onActivityResult(req,result,data);
        if(req==EXERCISE_REQUEST){
            if(result==RESULT_OK && (AlarmItem.PUSHUP.equals(activeMission)||AlarmItem.SQUAT.equals(activeMission)||AlarmItem.YOGA.equals(activeMission)||AlarmItem.SITUP.equals(activeMission)||AlarmItem.CALORIE.equals(activeMission)))pass();
            return;
        }
        if(req==VOICE_REQUEST){
            if(result==RESULT_OK && AlarmItem.VOICE.equals(activeMission) && data!=null){
                ArrayList<String> heard=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                if(heard!=null){for(String guess:heard){
                    if(normalizeWords(guess).equals(normalizeWords(alarm.voicePhrase))){pass();return;}
                }}
                status.setText(I18n.tr(this,"Cümle doğru tanınmadı. Yeniden dene: "+alarm.voicePhrase));
            }return;
        }
        if(req==PHOTO_REQUEST){
            // A successful result is returned only after on-device label verification.
            if((AlarmItem.PHOTO.equals(activeMission)||AlarmItem.BED.equals(activeMission)) && result==RESULT_OK)pass();
            return;
        }
        IntentResult scan=IntentIntegrator.parseActivityResult(req,result,data);
        if(scan!=null){
            if(scan.getContents()!=null && AlarmItem.QR.equals(activeMission)){
                if(scan.getContents().equals(alarm.barcode))pass();else {wrong();status.setText(I18n.tr(this,"Bu kayıtlı kod değil."));}
            }
            return;
        }
    }
    private void snooze(){if(finished)return;
        if(snoozed>=alarm.snoozeMax)return;
        snoozed++;getSharedPreferences("snoozes",MODE_PRIVATE).edit().putInt("snooze_"+alarm.id,snoozed).apply();
        if(!AlarmScheduler.snooze(this,alarm.id,alarm.snoozeMinutes)){
            snoozed--;
            getSharedPreferences("snoozes",MODE_PRIVATE).edit().putInt("snooze_"+alarm.id,snoozed).apply();
            status.setText(I18n.tr(this,"Erteleme planlanamadı. Alarm devam ediyor."));return;
        }
        AlarmRepository.record(this,"Ertelendi",alarm);
        stopAlarm(false);
    }
    private void confirmStop(){
        new AlertDialog.Builder(this).setTitle(I18n.tr(this,"Güvenli durdurma"))
            .setMessage(I18n.tr(this,"Alarmı görev bitmeden kapatacaksın. Alarm geçmişine kaydedilecek."))
            .setPositiveButton(I18n.tr(this,"Durdur"),(d,w)->{AlarmRepository.record(this,"Güvenli durduruldu",alarm);stopAlarm(true);})
            .setNegativeButton(I18n.tr(this,"Vazgeç"),null).show();
    }
    private void complete(){if(finished)return;
        long duration=Math.max(0,android.os.SystemClock.elapsedRealtime()-taskStarted);
        AlarmRepository.record(this,"Görev tamamlandı",alarm,duration);
        getSharedPreferences("snoozes",MODE_PRIVATE).edit().remove("snooze_"+alarm.id).apply();
        stopAlarm(true);
        startActivity(new Intent(this,SuccessActivity.class).putExtra("duration_ms",duration));
    }
    private void stopAlarm(boolean disableSingle){
        finished=true;unregisterSensors();handler.removeCallbacksAndMessages(null);
        if(disableSingle){
            AlarmScheduler.cancelSnooze(this,alarm.id);
            getSharedPreferences("snoozes",MODE_PRIVATE).edit().remove("snooze_"+alarm.id).apply();
        }
        if(disableSingle && alarm.daysMask==0){alarm.enabled=false;AlarmRepository.put(this,alarm);}
        Intent stop=new Intent(this,AlarmRingService.class).setAction(AlarmRingService.ACTION_STOP);
        try{startService(stop);}catch(Exception ignored){stopService(new Intent(this,AlarmRingService.class));}
        finish();
    }
    private void unregisterSensors(){if(sensors!=null){sensors.unregisterListener(this);sensors=null;activeSensor=null;}}
    @Override protected void onDestroy(){unregisterSensors();handler.removeCallbacksAndMessages(null);super.onDestroy();}
    @Override public void onBackPressed(){confirmStop();}
}
