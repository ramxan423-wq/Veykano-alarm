package com.wakemission.alarm;

import android.app.Activity;
import android.os.Bundle;
import android.widget.*;
import android.content.Intent;
import android.net.Uri;
import com.android.billingclient.api.*;
import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;

/** Optional store connection. No alarm features are paywalled. No hard-coded prices. */
public final class ProActivity extends Activity implements PurchasesUpdatedListener {
    // Block real charges until product configuration AND secure entitlement verification are completed.
    private static final boolean PAYMENTS_ENABLED=false;
    private static final String MONTHLY="wakemission_pro_monthly";
    private static final String ANNUAL="wakemission_pro_yearly";
    private BillingClient client;
    private TextView info;
    private LinearLayout products;
    @Override public void onCreate(Bundle b){super.onCreate(b);AppTheme.apply(this);
        ScrollView scroll=new ScrollView(this);scroll.setBackgroundColor(Ui.BG);
        LinearLayout root=Ui.column(this);root.setPadding(24,40,24,24);scroll.addView(root);
        root.addView(Ui.text(this,"Mission Alarm Veykano Pro",30,Ui.WHITE,true));
        root.addView(Ui.text(this,"Tüm temel alarmlar ve görevler ücretsiz kalır. Satın alma yalnızca mağaza ürünleri etkin olduğunda sunulur.",15,Ui.MUTED,false));
        info=Ui.text(this,"Google Play ile bağlantı kuruluyor...",14,Ui.PEACH,false);root.addView(info,Ui.matchMargins(this,20));
        products=Ui.column(this);root.addView(products);setContentView(scroll);
        client=BillingClient.newBuilder(this).setListener(this)
            .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
            .build();
        client.startConnection(new BillingClientStateListener(){
            @Override public void onBillingSetupFinished(BillingResult r){
                if(r.getResponseCode()==BillingClient.BillingResponseCode.OK){lookup();refreshPurchases();}
                else info.setText(I18n.tr(ProActivity.this,"Mağaza kullanılamıyor: "+r.getDebugMessage()));
            }
            @Override public void onBillingServiceDisconnected(){info.setText(I18n.tr(ProActivity.this,"Google Play bağlantısı kesildi. Sonra yeniden dene."));}
        });
    }
    private void lookup(){
        List<QueryProductDetailsParams.Product> entries=Arrays.asList(
            QueryProductDetailsParams.Product.newBuilder().setProductId(MONTHLY).setProductType(BillingClient.ProductType.SUBS).build(),
            QueryProductDetailsParams.Product.newBuilder().setProductId(ANNUAL).setProductType(BillingClient.ProductType.SUBS).build());
        client.queryProductDetailsAsync(QueryProductDetailsParams.newBuilder().setProductList(entries).build(),
            (response,details)->{
                if(response.getResponseCode()!=BillingClient.BillingResponseCode.OK){info.setText(I18n.tr(ProActivity.this,"Ürünler yüklenemedi."));return;}
                products.removeAllViews();
                List<ProductDetails> available=details.getProductDetailsList();
                if(available.isEmpty()){
                    info.setText(I18n.tr(ProActivity.this,"Pro ürünleri henüz Google Play Console'da yayınlanmamış. Ödeme etkin değil."));return;
                }
                info.setText(I18n.tr(ProActivity.this,PAYMENTS_ENABLED?"Satın almadan önce Google Play fiyatlarını kontrol et.":
                    "Önizleme: sunucu satın alma doğrulaması kurulmadan ödeme alınmaz."));
                for(ProductDetails p:available){
                    List<ProductDetails.SubscriptionOfferDetails> offers=p.getSubscriptionOfferDetails();
                    if(offers==null||offers.isEmpty())continue;
                    ProductDetails.SubscriptionOfferDetails offer=offers.get(0);
                    List<ProductDetails.PricingPhase> phases=offer.getPricingPhases().getPricingPhaseList();
                    String price=phases.isEmpty()?"Fiyat bilinmiyor":phases.get(phases.size()-1).getFormattedPrice();
                    Button buy=Ui.button(this,p.getName()+" • "+price,true);products.addView(buy,Ui.matchMargins(this,12));
                    buy.setEnabled(PAYMENTS_ENABLED);
                    buy.setOnClickListener(v->{
                        BillingFlowParams.ProductDetailsParams param=BillingFlowParams.ProductDetailsParams.newBuilder()
                            .setProductDetails(p).setOfferToken(offer.getOfferToken()).build();
                        BillingResult result=client.launchBillingFlow(this,BillingFlowParams.newBuilder()
                            .setProductDetailsParamsList(Arrays.asList(param)).build());
                        if(result.getResponseCode()!=BillingClient.BillingResponseCode.OK)
                            info.setText(I18n.tr(this,"Satın alma açılamadı: "+result.getDebugMessage()));
                    });
                }
            });
    }
    private void refreshPurchases(){
        client.queryPurchasesAsync(QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.SUBS).build(),
            (r,purchases)->{if(r.getResponseCode()==BillingClient.BillingResponseCode.OK)process(purchases);});
    }
    @Override public void onPurchasesUpdated(BillingResult result,List<Purchase> purchases){
        if(result.getResponseCode()==BillingClient.BillingResponseCode.OK && purchases!=null)process(purchases);
        else if(result.getResponseCode()!=BillingClient.BillingResponseCode.USER_CANCELED)
            info.setText(I18n.tr(this,"Satın alma tamamlanmadı: "+result.getDebugMessage()));
    }
    private void process(List<Purchase> purchases){
        for(Purchase p:purchases){
            if(p.getPurchaseState()!=Purchase.PurchaseState.PURCHASED||p.isSuspended())continue;
            // No entitlement or acknowledgement before secure backend verification.
            // PAYMENTS_ENABLED stays false until server-side purchase verification and acknowledgement exist.
            info.setText(I18n.tr(this,"Mağaza aboneliği tespit edildi fakat sunucu doğrulaması kurulmadı. " +
                "Herhangi bir Pro kilidi açılmaz veya satın alma burada onaylanmaz."));
        }
    }
    @Override protected void onDestroy(){if(client!=null)client.endConnection();super.onDestroy();}
}
