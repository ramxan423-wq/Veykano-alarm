package com.wakemission.alarm;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.util.TimeZone;

public final class AlarmScheduler {
    private AlarmScheduler(){}
    private static final int PI_FLAGS=PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE;
    static PendingIntent fireIntent(Context c,int id){
        Intent i=new Intent(c,AlarmReceiver.class).putExtra("alarm_id",id).setAction("com.wakemission.alarm.FIRE");
        return PendingIntent.getBroadcast(c,id,i,PI_FLAGS);
    }
    static PendingIntent snoozeIntent(Context c,int id){
        Intent i=new Intent(c,AlarmReceiver.class).putExtra("alarm_id",id).setAction("com.wakemission.alarm.FIRE_SNOOZE");
        return PendingIntent.getBroadcast(c,id+1_000_000,i,PI_FLAGS);
    }
    public static void cancel(Context c,int id){
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        if(am!=null){am.cancel(fireIntent(c,id));am.cancel(snoozeIntent(c,id));}
    }
    public static void cancelSnooze(Context c,int id){
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        if(am!=null) am.cancel(snoozeIntent(c,id));
    }
    public static boolean schedule(Context c,AlarmItem a){
        if(!a.enabled)return false;
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        if(am==null)return false;
        if(Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms())return false;
        long when=AlarmTimeLogic.nextTriggerMillis(a.hour,a.minute,a.daysMask,System.currentTimeMillis(),TimeZone.getDefault());
        Intent ui=new Intent(c,MainActivity.class).setAction("com.wakemission.alarm.SHOW");
        PendingIntent show=PendingIntent.getActivity(c,a.id,ui,PI_FLAGS);
        try {
            am.setAlarmClock(new AlarmManager.AlarmClockInfo(when,show),fireIntent(c,a.id));
            return true;
        }catch(SecurityException ignored){return false;}
    }
    public static void scheduleAll(Context c){for(AlarmItem a:AlarmRepository.list(c))if(a.enabled)schedule(c,a);}
    public static boolean snooze(Context c,int id,int minutes){
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        if(am==null)return false;
        AlarmItem a=AlarmRepository.get(c,id);
        if(a==null || !a.enabled)return false;
        long when=System.currentTimeMillis()+Math.max(1,minutes)*60_000L;
        PendingIntent pi=snoozeIntent(c,id);
        Intent ui=new Intent(c,MainActivity.class);
        PendingIntent show=PendingIntent.getActivity(c,id,ui,PI_FLAGS);
        if(Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms())return false;
        try{am.setAlarmClock(new AlarmManager.AlarmClockInfo(when,show),pi);return true;}
        catch(SecurityException ignored){return false;}
    }
}
