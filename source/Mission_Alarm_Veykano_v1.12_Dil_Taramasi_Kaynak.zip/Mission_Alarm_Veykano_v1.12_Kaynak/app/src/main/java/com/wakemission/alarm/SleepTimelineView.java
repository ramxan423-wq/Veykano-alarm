package com.wakemission.alarm;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Finished-night sound timeline. Uses shared WakeMission palette. */
public final class SleepTimelineView extends View {
    public interface EventClick { void onEvent(JSONObject event); }
    private final long start,end;
    private final JSONArray events;
    private final EventClick action;
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final String[] rows={"Horlama","Öksürük","Kabus","Diğer ses"};
    private final SimpleDateFormat clock;
    private final float density;
    public SleepTimelineView(Context context,long from,long to,JSONArray entries,EventClick listener){
        super(context);
        start=from;end=Math.max(to,from+60000);events=entries;action=listener;
        clock=new SimpleDateFormat("HH:mm",I18n.locale(context));
        density=getResources().getDisplayMetrics().density;
        setContentDescription(I18n.tr(context,"Uyku ses olayları grafiği. Horlama, öksürük, kabus ve diğer sesler saatlerine göre işaretlenir."));
        setClickable(true);
    }
    private float dp(float v){return v*density;}
    private float left(){return dp(91);}
    private float right(){return getWidth()-dp(11);}
    private float graphTop(){return dp(40);}
    private float rowGap(){return dp(35);}
    private float position(long at){
        double fraction=(at-start)/(double)(end-start);
        return left()+(float)(Math.max(0,Math.min(1,fraction))*(right()-left()));
    }
    public static int rowFor(String type){
        String value=type==null?"":type.toLowerCase(new Locale("tr","TR"));
        if(value.contains("horla"))return 0;
        if(value.contains("öksür"))return 1;
        if(value.contains("kabus"))return 2;
        return 3;
    }
    private void label(Canvas c,String text,float x,float y,int color,float sp){
        paint.setColor(color);paint.setTextSize(dp(sp));paint.setStyle(Paint.Style.FILL);
        c.drawText(text,x,y,paint);
    }
    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);
        float x1=left(),x2=right();
        paint.setTextSize(dp(12));
        label(canvas,clock.format(new Date(start)),x1,dp(18),Ui.MUTED,11);
        String finish=clock.format(new Date(end));
        paint.setTextSize(dp(11));
        label(canvas,finish,x2-paint.measureText(finish),dp(18),Ui.MUTED,11);
        for(int i=0;i<rows.length;i++){
            float y=graphTop()+i*rowGap();
            label(canvas,I18n.tr(getContext(),rows[i]),dp(2),y+dp(4),Ui.WHITE,11);
            paint.setColor(Ui.OUTLINE);paint.setStrokeWidth(dp(1));
            canvas.drawLine(x1,y,x2,y,paint);
        }
        if(events==null)return;
        float[] labeledX={-10000,-10000,-10000,-10000};
        for(int j=0;j<events.length();j++){
            JSONObject e=events.optJSONObject(j);if(e==null)continue;
            long at=e.optLong("at",start);
            if(at<start || at>end)continue;
            int r=rowFor(e.optString("type"));
            float x=position(at),y=graphTop()+r*rowGap();
            int color=r==0?Ui.PEACH:r==1?Ui.GREEN:r==2?Ui.PURPLE:Ui.MUTED;
            paint.setColor(color);paint.setStrokeWidth(dp(3));
            canvas.drawLine(x,y-dp(8),x,y+dp(8),paint);
            paint.setStyle(Paint.Style.FILL);
            canvas.drawCircle(x,y,dp(5),paint);
            if(x-labeledX[r]>dp(43)){
                String time=clock.format(new Date(at));
                float textX=Math.max(x1,Math.min(x-dp(13),x2-dp(27)));
                label(canvas,time,textX,y-dp(13),Ui.MUTED,9);
                labeledX[r]=x;
            }
        }
        label(canvas,I18n.tr(getContext(),"Her işaret kaydedilen bir ana aittir • Dinlemek için dokun"),dp(2),dp(198),Ui.MUTED,10);
    }
    @Override public boolean onTouchEvent(MotionEvent touch){
        if(touch.getAction()==MotionEvent.ACTION_DOWN)return true;
        if(touch.getAction()!=MotionEvent.ACTION_UP)return super.onTouchEvent(touch);
        performClick();
        if(events==null || action==null)return true;
        JSONObject nearest=null;float best=Float.MAX_VALUE;
        for(int j=0;j<events.length();j++){
            JSONObject e=events.optJSONObject(j);if(e==null)continue;
            long at=e.optLong("at",start);if(at<start||at>end)continue;
            int r=rowFor(e.optString("type"));
            float x=position(at),y=graphTop()+r*rowGap();
            float dist=(float)Math.hypot((touch.getX()-x)*.75, touch.getY()-y);
            if(dist<best){best=dist;nearest=e;}
        }
        if(nearest!=null && best<=dp(24))action.onEvent(nearest);
        return true;
    }
    @Override public boolean performClick(){super.performClick();return true;}
}
