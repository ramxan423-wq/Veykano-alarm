package com.wakemission.alarm;

/** Continuous camera-confirmed hold; a gap, missing pose or pause resets the streak. */
public final class YogaHoldTimer {
    private long startedAt=-1,lastValidAt=-1;
    private int validFrames;
    private final int seconds;
    public YogaHoldTimer(int seconds){this.seconds=safeSeconds(seconds);}
    public static int safeSeconds(int value){return value==20||value==30?value:10;}
    public void interrupt(){startedAt=-1;lastValidAt=-1;validFrames=0;}
    /** Consecutive valid frames must be sampled < 1250ms apart; camera timestamps use elapsed realtime. */
    public int update(boolean valid,long nowMs){
        if(!valid || (lastValidAt>=0 && (nowMs<lastValidAt || nowMs-lastValidAt>1250))){
            interrupt();
            if(!valid)return 0;
        }
        validFrames++;
        if(validFrames>=2 && startedAt<0)startedAt=nowMs;
        lastValidAt=nowMs;
        if(startedAt<0)return 0;
        return Math.min(seconds,(int)((nowMs-startedAt)/1000));
    }
    public boolean completed(){return startedAt>=0 && lastValidAt>=startedAt && lastValidAt-startedAt>=seconds*1000L;}
}
