package com.wakemission.alarm;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Shared views and dynamically selected palette. All activities call AppTheme.apply in onCreate. */
public final class Ui {
    public static int BG=Color.rgb(248,250,253), PANEL=Color.WHITE, PURPLE=Color.rgb(38,133,250),
            WHITE=Color.rgb(17,27,51), MUTED=Color.rgb(125,137,155), PEACH=Color.rgb(46,143,253),
            GREEN=Color.rgb(18,169,134), SECONDARY=Color.rgb(237,244,252), GRADIENT_END=Color.rgb(83,172,249),
            NAV=Color.rgb(239,242,246), OUTLINE=Color.rgb(232,237,244);
    public static boolean LIGHT=true;
    private Ui(){}
    public static int dp(Context c,int value){return (int)(c.getResources().getDisplayMetrics().density*value+.5f);}
    public static GradientDrawable shape(int color,int radius,Context c){
        GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(c,radius));return d;
    }
    public static GradientDrawable stroked(int color,int radius,int border,Context c){
        GradientDrawable d=shape(color,radius,c);d.setStroke(dp(c,1),border);return d;
    }
    public static GradientDrawable gradient(Context c){
        GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{PURPLE,GRADIENT_END});
        d.setCornerRadius(dp(c,26));return d;
    }
    public static LinearLayout column(Context c){LinearLayout v=new LinearLayout(c);v.setOrientation(LinearLayout.VERTICAL);return v;}
    public static LinearLayout row(Context c){LinearLayout v=new LinearLayout(c);v.setOrientation(LinearLayout.HORIZONTAL);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    public static TextView text(Context c,String value,int sp,int color,boolean bold){
        TextView t=new TextView(c);t.setText(I18n.tr(c,value));t.setTextColor(color);t.setTextSize(sp);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;
    }
    public static Button button(Context c,String value,boolean primary){
        Button b=new Button(c);b.setText(I18n.tr(c,value));b.setAllCaps(false);b.setTextColor(primary?Color.BLACK:WHITE);b.setTextSize(15);
        b.setBackground(primary?gradient(c):stroked(SECONDARY,16,OUTLINE,c));b.setMinimumHeight(dp(c,48));
        b.setElevation(dp(c,primary?2:0));return b;
    }
    public static void spaceHoriz(LinearLayout parent,int w){View v=new View(parent.getContext());parent.addView(v,new LinearLayout.LayoutParams(dp(parent.getContext(),w),1));}
    public static void space(LinearLayout parent,int h){View v=new View(parent.getContext());parent.addView(v,new LinearLayout.LayoutParams(1,dp(parent.getContext(),h)));}
    public static LinearLayout card(Context c){LinearLayout a=column(c);a.setPadding(dp(c,16),dp(c,15),dp(c,16),dp(c,15));
        a.setBackground(shape(PANEL,19,c));a.setElevation(dp(c,1));return a;
    }
    public static LinearLayout.LayoutParams matchMargins(Context c,int bottom){
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(c,bottom);return p;
    }
}
