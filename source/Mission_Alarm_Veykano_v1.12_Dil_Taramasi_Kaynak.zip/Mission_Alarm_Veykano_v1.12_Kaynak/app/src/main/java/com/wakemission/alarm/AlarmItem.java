package com.wakemission.alarm;

import org.json.JSONObject;

public final class AlarmItem {
    public static final String MATH="MATH", QR="QR", TYPE="TYPE", MEMORY="MEMORY", SHAKE="SHAKE", WALK="WALK", PHOTO="PHOTO", BED="BED", CHAIN="CHAIN", PUSHUP="PUSHUP", SQUAT="SQUAT", YOGA="YOGA", SITUP="SITUP", CALORIE="CALORIE", VOICE="VOICE";
    public int id;
    public int hour=7, minute=0, daysMask=0, challengeCount=3, snoozeMinutes=5, snoozeMax=2, difficulty=2;
    public String title="Günaydın!", mission=MATH, barcode="", ringtoneUri="", photoTarget="SKY", voicePhrase="BUGUN ERKEN KALKIYORUM", ttsMessage="", yogaPose="ARMS_UP";
    public int yogaHoldSeconds=10, situpTarget=10, calorieGoal=2, calorieWeightKg=70;
    public String calorieActivity="SITUP";
    public boolean enabled=true, vibrate=true, crescendo=false;

    public JSONObject json() {
        JSONObject j=new JSONObject();
        try {
            j.put("id",id); j.put("hour",hour);j.put("minute",minute);j.put("daysMask",daysMask);
            j.put("title",title); j.put("mission",mission); j.put("barcode",barcode);j.put("enabled",enabled);
            j.put("challengeCount",challengeCount);j.put("snoozeMinutes",snoozeMinutes);
            j.put("snoozeMax",snoozeMax);j.put("difficulty",difficulty);j.put("vibrate",vibrate);j.put("crescendo",crescendo);j.put("ringtoneUri",ringtoneUri);j.put("photoTarget",photoTarget);j.put("voicePhrase",voicePhrase);j.put("ttsMessage",ttsMessage);j.put("yogaPose",yogaPose);j.put("yogaHoldSeconds",yogaHoldSeconds);j.put("situpTarget",situpTarget);j.put("calorieGoal",calorieGoal);j.put("calorieWeightKg",calorieWeightKg);j.put("calorieActivity",calorieActivity);
        } catch (Exception ignored) { }
        return j;
    }
    public static AlarmItem from(JSONObject j) {
        AlarmItem a=new AlarmItem();
        a.id=j.optInt("id",0); a.hour=j.optInt("hour",7);a.minute=j.optInt("minute",0);
        a.daysMask=j.optInt("daysMask",0);a.title=j.optString("title","Günaydın!");
        a.mission=j.optString("mission",MATH); a.barcode=j.optString("barcode","");
        a.enabled=j.optBoolean("enabled",true);a.challengeCount=j.optInt("challengeCount",3);
        a.snoozeMinutes=j.optInt("snoozeMinutes",5);a.snoozeMax=j.optInt("snoozeMax",2);
        a.difficulty=Math.max(1,Math.min(3,j.optInt("difficulty",2)));
        a.vibrate=j.optBoolean("vibrate",true);a.crescendo=j.optBoolean("crescendo",false);a.ringtoneUri=j.optString("ringtoneUri","");a.photoTarget=j.optString("photoTarget","SKY");a.voicePhrase=j.optString("voicePhrase","BUGUN ERKEN KALKIYORUM");a.ttsMessage=j.optString("ttsMessage","");
        a.yogaPose=YogaPoseLogic.safePose(j.optString("yogaPose","ARMS_UP"));a.yogaHoldSeconds=YogaHoldTimer.safeSeconds(j.optInt("yogaHoldSeconds",10));
        int reps=j.optInt("situpTarget",10);a.situpTarget=reps==5||reps==15||reps==20?reps:10;
        a.calorieGoal=CalorieEstimate.safeGoal(j.optInt("calorieGoal",2));
        a.calorieWeightKg=CalorieEstimate.safeWeight(j.optInt("calorieWeightKg",70));
        a.calorieActivity=CalorieEstimate.safeActivity(j.optString("calorieActivity","SITUP"));
        return a;
    }
    public static String missionName(String key) {
        switch(key){
            case QR:return "QR / Barkod";
            case TYPE:return "Cümle yazma";
            case MEMORY:return "Hafıza";
            case SHAKE:return "Telefonu sallama";
            case WALK:return "Yürüme";
            case PHOTO:return "Fotoğraf çekme";
            case BED:return "Yatak toplama";
            case CHAIN:return "Karma görev zinciri";
            case PUSHUP:return "Kamerayla şınav";
            case SQUAT:return "Kamerayla squat";
            case YOGA:return "Kamerayla yoga";
            case SITUP:return "Kamerayla mekik";
            case CALORIE:return "Kalori modu";
            case VOICE:return "Sesli cümle";
            default:return "Matematik";
        }
    }
    public String repeatText(android.content.Context ctx){
        if(daysMask==0)return I18n.tr(ctx,"Bir kez");
        // Repeat-day labels follow the user-selected app language, not the phone language.
        java.text.DateFormatSymbols dfs=java.text.DateFormatSymbols.getInstance(I18n.locale(ctx));
        String[] shortDays=dfs.getShortWeekdays(); // Calendar.SUNDAY=1
        StringBuilder out=new StringBuilder();
        for(int i=0;i<7;i++)if((daysMask&(1<<i))!=0){
            if(out.length()>0)out.append(" · ");
            String d=shortDays[i+1];
            out.append(d==null||d.trim().isEmpty()?String.valueOf(i+1):d.trim());
        }
        return out.toString();
    }
    public String repeatText(){
        if(daysMask==0)return "Bir kez";
        String[] shortNames={"Pz","Pt","Sa","Ça","Pe","Cu","Ct"};
        StringBuilder sb=new StringBuilder();
        for(int i=0;i<7;i++)if((daysMask&(1<<i))!=0){if(sb.length()>0)sb.append(" · ");sb.append(shortNames[i]);}
        return sb.toString();
    }
    public String timeText(){return String.format(java.util.Locale.getDefault(),"%02d:%02d",hour,minute);}
}
