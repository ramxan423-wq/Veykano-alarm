package com.wakemission.alarm;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.util.Locale;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

/** A compact, accessible, white/burgundy alarm editor. Data schema and tasks are unchanged. */
public final class AlarmEditorActivity extends Activity {
    private static final int REF_PHOTO_REQUEST = 222;
    private static final int BURGUNDY = Color.rgb(255, 203, 53);
    private static final int INK = Color.rgb(29, 29, 29);
    private static final int MUTED = Color.rgb(128, 128, 128);
    private static final int HAIRLINE = Color.rgb(236, 235, 231);
    private static final int TINT = Color.rgb(249, 248, 243);
    private static final int BACKGROUND = Color.rgb(250, 248, 243);
    private static final String[] MISSION_NAMES = {
        "Matematik", "QR / Barkod", "Cümle yazma", "Hafıza", "Telefonu sallama", "Yürüme",
        "Fotoğraf çekme", "Yatak toplama", "Karma görev zinciri", "Kamerayla şınav sayma",
        "Kamerayla squat sayma", "Yoga modu", "Mekik modu", "Kalori modu", "Sesli cümle okuma"
    };
    private static final String[] MISSION_CODES = {
        AlarmItem.MATH, AlarmItem.QR, AlarmItem.TYPE, AlarmItem.MEMORY, AlarmItem.SHAKE,
        AlarmItem.WALK, AlarmItem.PHOTO, AlarmItem.BED, AlarmItem.CHAIN, AlarmItem.PUSHUP,
        AlarmItem.SQUAT, AlarmItem.YOGA, AlarmItem.SITUP, AlarmItem.CALORIE, AlarmItem.VOICE
    };
    private static final int[] SITUP_REPS={5,10,15,20};
    private static final String[] SITUP_REP_NAMES={"5 mekik","10 mekik","15 mekik","20 mekik"};
    private static final int[] CALORIE_GOALS={1,2,3};
    private static final String[] CALORIE_GOAL_NAMES={"1 kcal (tahmini)","2 kcal (tahmini)","3 kcal (tahmini)"};
    private static final String[] CALORIE_EXERCISES={"SITUP","SQUAT","PUSHUP"};
    private static final String[] CALORIE_EXERCISE_NAMES={"Mekik","Squat","Şınav"};
    private static final String[] YOGA_POSE_CODES={"ARMS_UP","MOUNTAIN","WARRIOR_II"};
    private static final String[] YOGA_POSE_NAMES={"Kollar Yukarı","Dağ Duruşu","Savaşçı II"};
    private static final int[] YOGA_HOLD_TIMES={10,20,30};
    private static final String[] YOGA_HOLD_NAMES={"10 saniye","20 saniye","30 saniye"};
    private static final String[] PHOTO_NAMES = {
        "Gökyüzü", "Yatak (referans fotoğrafla karşılaştır)", "Kitap", "Bardak",
        "Evcil hayvan", "Ayakkabı", "Şişe", "Sandalye", "Rastgele nesne avı"
    };
    private static final String[] PHOTO_CODES = {
        "SKY", "BED", "BOOK", "CUP", "PET", "SHOE", "BOTTLE", "CHAIR", "RANDOM"
    };
    private static final String[] COUNT_NAMES = {"1", "2", "3", "4", "5"};
    private static final String[] DIFFICULTY_NAMES = {"Kolay", "Orta", "Zor"};
    private static final String[] SNOOZE_NAMES = {"1 dk", "3 dk", "5 dk", "10 dk"};
    private static final int[] SNOOZE_VALUES = {1, 3, 5, 10};
    private static final String[] MAX_SNOOZE_NAMES = {"Kapalı", "1", "2", "3"};
    private static final String[] TONE_NAMES = {"Yumuşak", "Enerjik", "Klasik"};
    private static final String[] TONE_CODES = {"soft", "strong", "classic"};

    private AlarmItem item;
    private boolean isNew;
    private int hour, minute, daysMask;
    private int missionIndex, photoIndex, countIndex, difficultyIndex, snoozeIndex, maxSnoozeIndex, toneIndex, yogaPoseIndex, yogaHoldIndex, situpIndex, calorieGoalIndex, calorieExerciseIndex;
    private int calorieWeightKg;
    private EditText title, voicePhrase, ttsMessage;
    private Switch vibrate, crescendo;
    private TextView barcodeStatus, clockText, referenceHint;
    private TextView[] dayPills = new TextView[7];
    private boolean advanced=false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        AppTheme.apply(this);
        // Daybreak-style editor keeps all existing mission and alarm fields.
        getWindow().setStatusBarColor(Color.WHITE);
        getWindow().setNavigationBarColor(Color.WHITE);
        int flags = getWindow().getDecorView().getSystemUiVisibility();
        getWindow().getDecorView().setSystemUiVisibility(flags | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        int id = getIntent().getIntExtra("alarm_id", -1);
        item = id > 0 ? AlarmRepository.get(this, id) : null;
        if (item == null) {
            isNew = true;
            item = new AlarmItem();
            item.id = AlarmRepository.nextId(this);
            String preferred = getIntent().getStringExtra("mission");
            if (preferred != null) for (String code : MISSION_CODES)
                if (code.equals(preferred)) { item.mission = preferred; break; }
        }
        hour = item.hour;
        minute = item.minute;
        daysMask = item.daysMask;
        missionIndex = index(MISSION_CODES, item.mission, 0);
        photoIndex = index(PHOTO_CODES, item.photoTarget, 0);
        yogaPoseIndex = index(YOGA_POSE_CODES, YogaPoseLogic.safePose(item.yogaPose), 0);
        situpIndex = 1;
        for(int i=0;i<SITUP_REPS.length;i++)if(SITUP_REPS[i]==item.situpTarget)situpIndex=i;
        calorieGoalIndex=1;
        for(int i=0;i<CALORIE_GOALS.length;i++)if(CALORIE_GOALS[i]==item.calorieGoal)calorieGoalIndex=i;
        calorieExerciseIndex=index(CALORIE_EXERCISES,item.calorieActivity,0);
        calorieWeightKg=CalorieEstimate.safeWeight(item.calorieWeightKg);
        yogaHoldIndex = 0;
        for(int i=0;i<YOGA_HOLD_TIMES.length;i++)if(YOGA_HOLD_TIMES[i]==item.yogaHoldSeconds)yogaHoldIndex=i;
        countIndex = Math.max(0, Math.min(COUNT_NAMES.length - 1, item.challengeCount - 1));
        difficultyIndex = Math.max(0, Math.min(DIFFICULTY_NAMES.length - 1, item.difficulty - 1));
        snoozeIndex = 0;
        for (int i = 0; i < SNOOZE_VALUES.length; i++)
            if (SNOOZE_VALUES[i] == item.snoozeMinutes) snoozeIndex = i;
        maxSnoozeIndex = Math.max(0, Math.min(MAX_SNOOZE_NAMES.length - 1, item.snoozeMax));
        render();
    }

    // Only the mission-picker dialog changes. The app's existing palette and icon drawings remain intact.
    private void showModernMissionDialog(){
        final AlertDialog dialog=new AlertDialog.Builder(this).create();
        LinearLayout panel=col();panel.setPadding(dp(14),dp(16),dp(14),dp(11));
        panel.setBackground(bg(Color.WHITE,22,false));
        TextView heading=text("Görev seç",25,INK,true);
        heading.setPadding(dp(8),dp(3),0,dp(12));panel.addView(heading);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);scroll.setVerticalScrollBarEnabled(false);
        LinearLayout rows=col();
        final String[] glyphs={"calculator","qr","touch","badge","touch","steps","camera","camera","tasks","dumbbell","squat","yoga","situp","calorie","mic"};
        for(int i=0;i<MISSION_NAMES.length;i++){
            final int which=i;boolean checked=i==missionIndex;
            LinearLayout line=row();line.setGravity(Gravity.CENTER_VERTICAL);
            line.setPadding(dp(10),dp(5),dp(10),dp(5));
            line.setMinimumHeight(dp(52));
            line.setBackground(bg(checked?Color.rgb(255,248,225):Color.WHITE,12,false));
            android.widget.RadioButton radio=new android.widget.RadioButton(this);
            radio.setClickable(false);radio.setFocusable(false);radio.setChecked(checked);
            radio.setButtonTintList(new ColorStateList(new int[][]{new int[]{}},new int[]{checked?BURGUNDY:MUTED}));
            line.addView(radio,new LinearLayout.LayoutParams(dp(35),dp(40)));
            LinearLayout iconBox=col();iconBox.setGravity(Gravity.CENTER);
            iconBox.setBackground(bg(checked?Color.rgb(255,232,168):TINT,10,false));
            ReferenceIconView icon=new ReferenceIconView(this,glyphs[i],INK);
            iconBox.addView(icon,new LinearLayout.LayoutParams(dp(27),dp(27)));
            LinearLayout.LayoutParams iconParam=new LinearLayout.LayoutParams(dp(40),dp(40));
            iconParam.leftMargin=dp(5);iconParam.rightMargin=dp(12);
            line.addView(iconBox,iconParam);
            TextView name=text(MISSION_NAMES[i],16,INK,true);
            name.setMaxLines(2);name.setGravity(Gravity.CENTER_VERTICAL);
            line.addView(name,new LinearLayout.LayoutParams(0,-2,1));
            rows.addView(line,new LinearLayout.LayoutParams(-1,-2));
            line.setOnClickListener(v->{missionIndex=which;dialog.dismiss();render();});
        }
        scroll.addView(rows);
        panel.addView(scroll,new LinearLayout.LayoutParams(-1,(int)(getResources().getDisplayMetrics().heightPixels*.68f)));
        TextView cancel=text("VAZGEÇ",14,INK,true);cancel.setGravity(Gravity.CENTER);
        cancel.setBackground(bg(TINT,16,false));
        LinearLayout actions=row();actions.setGravity(Gravity.RIGHT);
        LinearLayout.LayoutParams cancelParams=new LinearLayout.LayoutParams(dp(106),dp(42));
        cancelParams.topMargin=dp(10);actions.addView(cancel,cancelParams);
        panel.addView(actions);cancel.setOnClickListener(v->dialog.dismiss());
        dialog.setView(panel);dialog.show();
        if(dialog.getWindow()!=null){
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            dialog.getWindow().setLayout(getResources().getDisplayMetrics().widthPixels-dp(38),-2);
        }
    }

    private void showSitupDialog(){
        new AlertDialog.Builder(this).setTitle(I18n.tr(this,"Mekik Tekrarı")).setSingleChoiceItems(localize(SITUP_REP_NAMES),situpIndex,
            (d,which)->{situpIndex=which;d.dismiss();render();}).setNegativeButton(I18n.tr(this,"Vazgeç"),null).show();
    }
    private void showCalorieGoalDialog(){
        new AlertDialog.Builder(this).setTitle(I18n.tr(this,"Tahmini Kalori Hedefi")).setSingleChoiceItems(localize(CALORIE_GOAL_NAMES),calorieGoalIndex,
            (d,which)->{calorieGoalIndex=which;d.dismiss();render();}).setNegativeButton(I18n.tr(this,"Vazgeç"),null).show();
    }
    private void showCalorieActivityDialog(){
        new AlertDialog.Builder(this).setTitle(I18n.tr(this,"Kalori Egzersizi")).setSingleChoiceItems(localize(CALORIE_EXERCISE_NAMES),calorieExerciseIndex,
            (d,which)->{calorieExerciseIndex=which;d.dismiss();render();}).setNegativeButton(I18n.tr(this,"Vazgeç"),null).show();
    }
    private void showCalorieWeightDialog(){
        EditText e=new EditText(this);e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        e.setText(String.valueOf(calorieWeightKg));e.setSelectAllOnFocus(true);
        LinearLayout holder=col();holder.setPadding(dp(22),dp(7),dp(22),0);holder.addView(e);
        new AlertDialog.Builder(this).setTitle(I18n.tr(this,"Vücut ağırlığı (kg)")).setView(holder)
            .setMessage(I18n.tr(this,"Kalori hesabı yalnızca tahmindir. Kilo 30–250 kg arasında olmalı."))
            .setNegativeButton(I18n.tr(this,"Vazgeç"),null).setPositiveButton(I18n.tr(this,"Kaydet"),(d,w)->{
                try{int kg=Integer.parseInt(e.getText().toString().trim());
                    if(kg>=30&&kg<=250){calorieWeightKg=kg;render();}
                    else Toast.makeText(this,I18n.tr(this,"30–250 kg arasında değer gir."),Toast.LENGTH_SHORT).show();
                }catch(NumberFormatException ex){Toast.makeText(this,I18n.tr(this,"Geçerli kilo gir."),Toast.LENGTH_SHORT).show();}
            }).show();
    }
    private void showYogaPoseDialog(){
        new AlertDialog.Builder(this).setTitle(I18n.tr(this,"Yoga Pozu")).setSingleChoiceItems(localize(YOGA_POSE_NAMES),yogaPoseIndex,
            (d,which)->{yogaPoseIndex=which;d.dismiss();render();}).setNegativeButton(I18n.tr(this,"Vazgeç"),null).show();
    }
    private void showYogaTimeDialog(){
        new AlertDialog.Builder(this).setTitle(I18n.tr(this,"Pozu Koruma Süresi")).setSingleChoiceItems(localize(YOGA_HOLD_NAMES),yogaHoldIndex,
            (d,which)->{yogaHoldIndex=which;d.dismiss();render();}).setNegativeButton(I18n.tr(this,"Vazgeç"),null).show();
    }
    private int index(String[] values, String requested, int fallback) {
        for (int i = 0; i < values.length; i++) if (values[i].equals(requested)) return i;
        return fallback;
    }
    private int dp(int n) { return Ui.dp(this, n); }
    private GradientDrawable bg(int color, int radius, boolean outlined) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(dp(radius));
        if (outlined) g.setStroke(dp(1), HAIRLINE);
        return g;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(I18n.tr(this, value)); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private LinearLayout col() { return Ui.column(this); }
    private LinearLayout row() { return Ui.row(this); }
    private void gap(LinearLayout p, int height) { Ui.space(p, height); }
    private LinearLayout.LayoutParams bottom(int size) {
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(-1, -2);
        l.bottomMargin = dp(size); return l;
    }
    private TextView section(LinearLayout root, String label, String icon) {
        TextView section = text(icon + "  " + label, 16, INK, true);
        root.addView(section, bottom(10)); return section;
    }
    private LinearLayout card() {
        LinearLayout c = col();
        c.setPadding(dp(14), dp(8), dp(14), dp(8));
        c.setBackground(bg(Color.WHITE, 17, true));
        return c;
    }
    private TextView actionButton(String text, boolean filled) {
        TextView v = text(text, 15, filled ? Color.WHITE : BURGUNDY, true);
        v.setGravity(Gravity.CENTER);
        v.setMinHeight(dp(52));
        v.setPadding(dp(12), dp(12), dp(12), dp(12));
        v.setBackground(bg(filled ? BURGUNDY : TINT, 16, !filled));
        v.setClickable(true);
        v.setFocusable(true);
        return v;
    }
    private TextView pill(int dayIndex, String label) {
        TextView t = text(label, 12, BURGUNDY, true);
        t.setGravity(Gravity.CENTER);
        t.setMinHeight(dp(40));
        t.setClickable(true); t.setFocusable(true);
        t.setOnClickListener(v -> {
            daysMask ^= (1 << dayIndex);
            styleDay(t, (daysMask & (1 << dayIndex)) != 0);
        });
        styleDay(t, (daysMask & (1 << dayIndex)) != 0);
        return t;
    }
    private void styleDay(TextView t, boolean selected) {
        t.setTextColor(INK);
        t.setBackground(bg(selected ? BURGUNDY : Color.rgb(245, 244, 246), 13, false));
        t.setSelected(selected);
        t.setContentDescription(t.getText() + I18n.tr(this,selected ? ", seçili" : ", seçili değil"));
    }
    private TextView selectionRow(LinearLayout parent, String icon, String label, String[] options, int chosen, java.util.function.IntConsumer onChange) {
        LinearLayout frame = row();
        frame.setPadding(dp(13), dp(15), dp(13), dp(15));
        frame.setBackground(bg(Color.WHITE, 16, true));
        frame.setClickable(true); frame.setFocusable(true);
        TextView left = text(icon, 20, BURGUNDY, true);
        left.setGravity(Gravity.CENTER);
        left.setBackground(bg(TINT, 12, false));
        frame.addView(left, new LinearLayout.LayoutParams(dp(42), dp(42)));
        LinearLayout center = col(); center.setPadding(dp(12), 0, dp(5), 0);
        TextView heading = text(label, 12, MUTED, false);
        TextView value = text(options[chosen], 16, INK, true);
        center.addView(heading); center.addView(value);
        frame.addView(center, new LinearLayout.LayoutParams(0, -2, 1));
        TextView arrow = text("›", 28, BURGUNDY, false);
        frame.addView(arrow);
        parent.addView(frame, bottom(10));
        final int[] currentlyChosen = { chosen };
        frame.setContentDescription(I18n.tr(this,label) + ": " + I18n.tr(this,options[chosen]));
        frame.setOnClickListener(v -> new AlertDialog.Builder(this)
            .setTitle(I18n.tr(this, label))
            .setSingleChoiceItems(localize(options), currentlyChosen[0], (dialog, which) -> {
                value.setText(I18n.tr(this, options[which]));
                frame.setContentDescription(I18n.tr(this,label) + ": " + I18n.tr(this,options[which]));
                currentlyChosen[0] = which;
                onChange.accept(which);
                dialog.dismiss();
            }).setNegativeButton(I18n.tr(this,"Vazgeç"), null).show());
        return value;
    }
    private String[] localize(String[] values) {
        String[] out = new String[values.length];
        for (int i = 0; i < values.length; i++) out[i] = I18n.tr(this, values[i]);
        return out;
    }
    private EditText input(LinearLayout parent, String initial, String hint, boolean singleLine) {
        EditText e = new EditText(this);
        e.setText(initial);
        e.setHint(I18n.tr(this, hint));
        e.setTextSize(15); e.setTextColor(INK); e.setHintTextColor(MUTED);
        e.setSingleLine(singleLine);
        e.setPadding(dp(15), dp(13), dp(15), dp(13));
        e.setBackground(bg(Color.WHITE, 15, true));
        parent.addView(e, bottom(18));
        return e;
    }
    private void switchRow(LinearLayout parent, String label, String hint, boolean checked, java.util.function.Consumer<Switch> register) {
        LinearLayout wrapper = row();
        wrapper.setPadding(dp(16), dp(12), dp(13), dp(12));
        wrapper.setBackground(bg(Color.WHITE, 16, true));
        LinearLayout textArea = col();
        textArea.addView(text(label, 15, INK, true));
        if (!hint.isEmpty()) { gap(textArea, 3); textArea.addView(text(hint, 12, MUTED, false)); }
        wrapper.addView(textArea, new LinearLayout.LayoutParams(0, -2, 1));
        Switch s = new Switch(this);
        s.setChecked(checked);
        s.setShowText(false);
        s.setThumbTintList(new ColorStateList(new int[][]{new int[]{android.R.attr.state_checked}, new int[]{}}, new int[]{Color.WHITE, Color.WHITE}));
        s.setTrackTintList(new ColorStateList(new int[][]{new int[]{android.R.attr.state_checked}, new int[]{}}, new int[]{BURGUNDY, Color.rgb(190, 186, 190)}));
        wrapper.addView(s);
        wrapper.setOnClickListener(v -> s.setChecked(!s.isChecked()));
        parent.addView(wrapper, bottom(10));
        register.accept(s);
    }

    /** Four-row reference editor with all specialist settings still accessible via Advanced. */
    private void render() {
        if (advanced) { renderAdvanced(); return; }
        LinearLayout page=col();page.setBackgroundColor(BACKGROUND);
        LinearLayout toolbar=row();toolbar.setPadding(dp(16),dp(9),dp(16),dp(8));
        TextView back=text("‹",31,INK,false);back.setGravity(Gravity.CENTER);
        toolbar.addView(back,new LinearLayout.LayoutParams(dp(40),dp(43)));back.setOnClickListener(v->finish());
        TextView heading=text(isNew?"Alarm Kur":"Alarm Düzenle",19,INK,true);heading.setGravity(Gravity.CENTER);
        toolbar.addView(heading,new LinearLayout.LayoutParams(0,-1,1));
        toolbar.addView(new View(this),new LinearLayout.LayoutParams(dp(40),dp(43)));
        page.addView(toolbar,new LinearLayout.LayoutParams(-1,dp(65)));

        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);scroll.setVerticalScrollBarEnabled(false);
        LinearLayout root=col();root.setPadding(dp(18),dp(7),dp(18),dp(14));scroll.addView(root);
        page.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        // The preview of neighboring hours/minutes mirrors the reference wheel.
        LinearLayout wheel=col();wheel.setGravity(Gravity.CENTER);
        TextView previous=text(String.format(I18n.locale(this),"%02d        %02d",(hour+23)%24,(minute+59)%60),22,0xFFCBCBCB,false);
        previous.setGravity(Gravity.CENTER);wheel.addView(previous);
        TextView selected=text(formatClock().replace(":","  :  "),29,INK,true);
        selected.setGravity(Gravity.CENTER);selected.setBackground(bg(0xFFF1EFEA,18,false));
        LinearLayout.LayoutParams wp=new LinearLayout.LayoutParams(-1,dp(46));wp.topMargin=dp(6);wp.bottomMargin=dp(6);
        wheel.addView(selected,wp);
        TextView following=text(String.format(I18n.locale(this),"%02d        %02d",(hour+1)%24,(minute+1)%60),22,0xFFCBCBCB,false);
        following.setGravity(Gravity.CENTER);wheel.addView(following);
        root.addView(wheel,bottom(22));
        wheel.setClickable(true);wheel.setFocusable(true);wheel.setContentDescription(I18n.tr(this,"Alarm saati " + formatClock()));
        wheel.setOnClickListener(v->new TimePickerDialog(this,(picker,h,m)->{hour=h;minute=m;render();},hour,minute,true).show());

        TextView repeat=text("Tekrar",15,INK,true);repeat.setPadding(dp(9),0,0,dp(12));root.addView(repeat);
        LinearLayout days=row();int[] order={1,2,3,4,5,6,0};
        String[] names={"P","S","Ç","P","C","C","P"};
        for(int i=0;i<7;i++){
            TextView chip=text(names[i],12,INK,true);chip.setGravity(Gravity.CENTER);
            final int day=order[i];dayPills[i]=chip;styleDay(chip,(daysMask&(1<<day))!=0);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(34),1);if(i<6)lp.rightMargin=dp(6);
            days.addView(chip,lp);chip.setOnClickListener(v->{daysMask^=(1<<day);styleDay(chip,(daysMask&(1<<day))!=0);});
        }
        root.addView(days,bottom(19));

        // Invisible form values keep the original alarm model and save logic unchanged.
        title=new EditText(this);title.setText(item.title);
        voicePhrase=new EditText(this);voicePhrase.setText(item.voicePhrase);
        ttsMessage=new EditText(this);ttsMessage.setText(item.ttsMessage);
        vibrate=new Switch(this);vibrate.setChecked(item.vibrate);
        crescendo=new Switch(this);crescendo.setChecked(item.crescendo);
        barcodeStatus=text("",12,MUTED,false);

        LinearLayout options=col();options.setBackground(bg(Color.WHITE,17,false));
        simpleRow(options,"♟","Görev",MISSION_CODES[missionIndex].equals(AlarmItem.PUSHUP)?"Şınav (20 tekrar)":MISSION_NAMES[missionIndex],()->{
            showModernMissionDialog();
        });
        if(AlarmItem.YOGA.equals(MISSION_CODES[missionIndex])){
            divider(options);
            simpleRow(options,"♧","Yoga Pozu",YOGA_POSE_NAMES[yogaPoseIndex],()->showYogaPoseDialog());
            divider(options);
            simpleRow(options,"◷","Pozu Koruma Süresi",YOGA_HOLD_NAMES[yogaHoldIndex],()->showYogaTimeDialog());
        }
        if(AlarmItem.SITUP.equals(MISSION_CODES[missionIndex])){
            divider(options);simpleRow(options,"♧","Mekik Tekrarı",SITUP_REP_NAMES[situpIndex],()->showSitupDialog());
        }
        if(AlarmItem.CALORIE.equals(MISSION_CODES[missionIndex])){
            divider(options);simpleRow(options,"♧","Egzersiz",CALORIE_EXERCISE_NAMES[calorieExerciseIndex],()->showCalorieActivityDialog());
            divider(options);simpleRow(options,"◷","Kalori Hedefi",CALORIE_GOAL_NAMES[calorieGoalIndex],()->showCalorieGoalDialog());
            divider(options);simpleRow(options,"♧","Vücut Ağırlığı",calorieWeightKg+" kg",()->showCalorieWeightDialog());
        }
        divider(options);
        simpleRow(options,"♬","Alarm Sesi",item.ringtoneUri.isEmpty()?"Sabah Neşesi":"Özel zil sesi",()->{
            Intent intent=new Intent(RingtoneManager.ACTION_RINGTONE_PICKER);
            intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE,RingtoneManager.TYPE_ALARM);
            intent.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT,false);
            intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE,"Alarm sesini seç");
            try{startActivityForResult(intent,59);}catch(Exception e){Toast.makeText(this,I18n.tr(this,"Ses seçici bulunamadı"),Toast.LENGTH_SHORT).show();}
        });
        divider(options);
        simpleRow(options,"◷","Erteleme",SNOOZE_VALUES[snoozeIndex]+" dakika ("+MAX_SNOOZE_NAMES[maxSnoozeIndex]+" kez)",()->{
            new AlertDialog.Builder(this).setTitle(I18n.tr(this,"Erteleme süresi")).setSingleChoiceItems(localize(SNOOZE_NAMES),snoozeIndex,(d,which)->{
                snoozeIndex=which;d.dismiss();render();}).setNegativeButton(I18n.tr(this,"Vazgeç"),null).show();
        });
        divider(options);
        simpleRow(options,"◇","Etiket",item.title==null||item.title.isEmpty()?"İşe Uyanma":item.title,()->{
            EditText e=new EditText(this);e.setText(title.getText());e.setSingleLine(true);e.setSelectAllOnFocus(true);
            new AlertDialog.Builder(this).setTitle(I18n.tr(this,"Alarm etiketi")).setView(e).setNegativeButton(I18n.tr(this,"Vazgeç"),null)
                .setPositiveButton(I18n.tr(this,"Kaydet"),(d,w)->{title.setText(e.getText());item.title=e.getText().toString();render();}).show();
        });
        root.addView(options,bottom(17));
        TextView advancedLink=text("Gelişmiş ayarlar  ›",13,MUTED,true);advancedLink.setGravity(Gravity.CENTER);
        advancedLink.setPadding(0,dp(8),0,dp(12));root.addView(advancedLink);
        advancedLink.setOnClickListener(v->{
            item.title=title.getText().toString();advanced=true;renderAdvanced();
        });
        if(!isNew){
            TextView delete=text("Alarmı sil",13,0xFFBC3644,false);delete.setGravity(Gravity.CENTER);
            root.addView(delete);delete.setOnClickListener(v->new AlertDialog.Builder(this)
                .setTitle(I18n.tr(this,"Alarm silinsin mi?")).setNegativeButton(I18n.tr(this,"Vazgeç"),null)
                .setPositiveButton(I18n.tr(this,"Sil"),(d,w)->{AlarmScheduler.cancel(this,item.id);AlarmRepository.delete(this,item.id);finish();}).show());
        }
        LinearLayout footer=col();footer.setPadding(dp(18),dp(8),dp(18),dp(13));
        footer.setBackgroundColor(BACKGROUND);
        TextView save=text("Alarmı Kaydet",15,Color.BLACK,true);save.setGravity(Gravity.CENTER);
        save.setBackground(bg(BURGUNDY,26,false));save.setMinHeight(dp(49));
        footer.addView(save,new LinearLayout.LayoutParams(-1,dp(49)));
        save.setOnClickListener(v->save());page.addView(footer);
        setContentView(page);
    }

    private void divider(LinearLayout parent){
        View line=new View(this);line.setBackgroundColor(HAIRLINE);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(1));lp.leftMargin=dp(12);lp.rightMargin=dp(12);
        parent.addView(line,lp);
    }
    private void simpleRow(LinearLayout parent,String symbol,String name,String value,Runnable click){
        LinearLayout row=row();row.setPadding(dp(14),dp(13),dp(13),dp(13));
        String iconKind="Egzersiz".equals(name)?"situp":"Mekik Tekrarı".equals(name)?"situp":"Kalori Hedefi".equals(name)?"calorie":"Vücut Ağırlığı".equals(name)?"calorie":"Yoga Pozu".equals(name)?"yoga":"Görev".equals(name)?"dumbbell":"Alarm Sesi".equals(name)?"bell":
            "Erteleme".equals(name)||"Pozu Koruma Süresi".equals(name)?"clock":"tag";
        ReferenceIconView ico=new ReferenceIconView(this,iconKind,INK);
        LinearLayout.LayoutParams iconParams=new LinearLayout.LayoutParams(dp(31),dp(31));
        row.addView(ico,iconParams);
        LinearLayout label=col();label.setPadding(dp(8),0,0,0);
        label.addView(text(name,14,INK,true));label.addView(text(value,12,MUTED,false));
        row.addView(label,new LinearLayout.LayoutParams(0,-2,1));
        row.addView(text("›",25,INK,false));parent.addView(row);
        row.setOnClickListener(v->click.run());row.setContentDescription(I18n.tr(this,name)+": "+I18n.tr(this,value));
    }

    /** Keep unsaved advanced form values when dynamically revealing yoga settings. */
    private void cacheAdvancedEdits(){
        if(title!=null)item.title=title.getText().toString();
        if(voicePhrase!=null)item.voicePhrase=voicePhrase.getText().toString();
        if(ttsMessage!=null)item.ttsMessage=ttsMessage.getText().toString();
        if(vibrate!=null)item.vibrate=vibrate.isChecked();
        if(crescendo!=null)item.crescendo=crescendo.isChecked();
    }
    private void renderAdvanced() {
        LinearLayout screen = col();
        screen.setBackgroundColor(BACKGROUND);

        // Fixed, unobtrusive toolbar: the scroll content begins immediately below it.
        LinearLayout toolbar = row();
        toolbar.setPadding(dp(16), dp(10), dp(16), dp(9));
        toolbar.setBackgroundColor(Color.WHITE);
        TextView back = text("‹", 34, INK, false);
        back.setGravity(Gravity.CENTER); back.setContentDescription(I18n.tr(this,"Geri"));
        toolbar.addView(back, new LinearLayout.LayoutParams(dp(44), dp(48)));
        back.setOnClickListener(v -> { advanced=false;render(); });
        TextView heading = text(isNew ? "Alarm Kur" : "Alarm Düzenle", 21, INK, true);
        heading.setGravity(Gravity.CENTER);
        toolbar.addView(heading, new LinearLayout.LayoutParams(0, -1, 1));
        TextView topSave = text("✓", 23, INK, true);
        topSave.setGravity(Gravity.CENTER);
        topSave.setBackground(bg(BURGUNDY, 40, false));
        topSave.setContentDescription(I18n.tr(this,"Alarmı kaydet"));
        toolbar.addView(topSave, new LinearLayout.LayoutParams(dp(44), dp(44)));
        topSave.setOnClickListener(v -> save());
        screen.addView(toolbar, new LinearLayout.LayoutParams(-1, dp(68)));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.setClipToPadding(false);
        LinearLayout root = col();
        root.setPadding(dp(18), dp(15), dp(18), dp(24));
        scroll.addView(root);
        screen.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        
        LinearLayout timeCard = row();
        timeCard.setPadding(dp(18), dp(17), dp(18), dp(17));
        timeCard.setBackground(bg(TINT, 18, false));
        TextView alarmSymbol = text("◷", 34, BURGUNDY, true);
        alarmSymbol.setGravity(Gravity.CENTER);
        timeCard.addView(alarmSymbol, new LinearLayout.LayoutParams(dp(50), dp(64)));
        clockText = text(formatClock(), 38, BURGUNDY, true);
        clockText.setGravity(Gravity.CENTER_VERTICAL);
        clockText.setPadding(dp(10), 0, 0, 0);
        timeCard.addView(clockText, new LinearLayout.LayoutParams(0, dp(68), 1));
        timeCard.addView(text("›", 28, BURGUNDY, false));
        timeCard.setClickable(true);timeCard.setFocusable(true);
        timeCard.setContentDescription(I18n.tr(this,"Saat seç " + formatClock()));
        timeCard.setOnClickListener(v -> {
            TimePickerDialog dialog = new TimePickerDialog(this, (picker, h, m) -> {
                hour = h; minute = m;
                clockText.setText(formatClock());
                timeCard.setContentDescription(I18n.tr(this,"Saat seç " + formatClock()));
            }, hour, minute, true);
            dialog.show();
        });
        root.addView(timeCard, bottom(23));

        section(root, "Tekrar", "");
        LinearLayout dayRow = row();
        // Storage uses Sunday at bit 0; the user interface displays Monday first.
        int[] dayOrder = {1, 2, 3, 4, 5, 6, 0};
        String[] dayNames = {"P", "S", "Ç", "P", "C", "C", "P"};
        for (int i = 0; i < 7; i++) {
            TextView chip = pill(dayOrder[i], dayNames[i]);
            dayPills[i] = chip;
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(42), 1);
            if (i < 6) p.rightMargin = dp(5);
            dayRow.addView(chip, p);
        }
        root.addView(dayRow, bottom(19));
        title = input(root, item.title, "Alarm adı", true);

        section(root, "Görev", "");
        selectionRow(root, "▥", "Görev", MISSION_NAMES, missionIndex, which -> {
            cacheAdvancedEdits();missionIndex = which;renderAdvanced();
        });
        if(AlarmItem.YOGA.equals(MISSION_CODES[missionIndex])){
            selectionRow(root,"♧","Yoga Pozu",YOGA_POSE_NAMES,yogaPoseIndex,which->{yogaPoseIndex=which;});
            selectionRow(root,"◷","Pozu Koruma Süresi",YOGA_HOLD_NAMES,yogaHoldIndex,which->{yogaHoldIndex=which;});
        }
        if(AlarmItem.SITUP.equals(MISSION_CODES[missionIndex])){
            selectionRow(root,"♧","Mekik Tekrarı",SITUP_REP_NAMES,situpIndex,which->situpIndex=which);
        }
        if(AlarmItem.CALORIE.equals(MISSION_CODES[missionIndex])){
            selectionRow(root,"♧","Egzersiz",CALORIE_EXERCISE_NAMES,calorieExerciseIndex,which->calorieExerciseIndex=which);
            selectionRow(root,"◷","Kalori Hedefi",CALORIE_GOAL_NAMES,calorieGoalIndex,which->calorieGoalIndex=which);
            TextView weightButton=actionButton("Vücut Ağırlığı: "+calorieWeightKg+" kg  ›",false);
            root.addView(weightButton,bottom(8));weightButton.setOnClickListener(v->{cacheAdvancedEdits();showCalorieWeightDialog();});
        }
        gap(root, 8);
        section(root, "Fotoğraf Hedefi", "▣");
        selectionRow(root, "▧", "Hedef", PHOTO_NAMES, photoIndex, which -> photoIndex = which);
        TextView sample = actionButton("▣   Toplu yatak referansı çek", false);
        root.addView(sample, bottom(7));
        sample.setOnClickListener(v -> startActivityForResult(new Intent(this, PhotoChallengeActivity.class)
                .putExtra(PhotoChallengeActivity.EXTRA_TARGET, "BED")
                .putExtra(PhotoChallengeActivity.EXTRA_CALIBRATE, true), REF_PHOTO_REQUEST));
        TextView sampleHint = text(BedReferenceMatcher.available(this) ?
            "✓ Yatak referansı kayıtlı" : "Yatak görevi için referans kaydetmelisin.", 12, MUTED, false);
        root.addView(sampleHint, bottom(26));
        referenceHint=sampleHint;

        section(root, "Sesli Görev Cümlesi", "♩");
        voicePhrase = input(root, item.voicePhrase, "Söylenecek cümle", true);
        section(root, "Kişisel Sesli Alarm Mesajı · İsteğe Bağlı", "▤");
        ttsMessage = input(root, item.ttsMessage, "Örn. Haydi kalk, bugün harika bir gün!", false);
        TextView scan = actionButton("▦    QR / barkod kaydet     ›", false);
        root.addView(scan, bottom(8));
        scan.setOnClickListener(v -> scanCode());
        barcodeStatus = text(item.barcode.isEmpty() ? "Kayıtlı barkod yok" : "Kayıtlı barkod mevcut ✓", 12, MUTED, false);
        root.addView(barcodeStatus, bottom(23));

        section(root, "Görev Ayarları", "⚙");
        selectionRow(root, "#", "Görev Sayısı", COUNT_NAMES, countIndex, which -> countIndex = which);
        selectionRow(root, "▥", "Görev Zorluğu", DIFFICULTY_NAMES, difficultyIndex, which -> difficultyIndex = which);
        selectionRow(root, "◷", "Erteleme Süresi", SNOOZE_NAMES, snoozeIndex, which -> snoozeIndex = which);
        selectionRow(root, "↻", "Erteleme Hakkı", MAX_SNOOZE_NAMES, maxSnoozeIndex, which -> maxSnoozeIndex = which);
        gap(root, 13);

        section(root, "Ses ve Titreşim", "♪");
        switchRow(root, "Titreşim açık", "", item.vibrate, s -> vibrate = s);
        switchRow(root, "Sesi kademeli yükselt", "30 sn içinde kademeli artar", item.crescendo, s -> crescendo = s);
        TextView sound = actionButton("♪    Alarm sesini seç       ›", false);
        root.addView(sound, bottom(24));
        sound.setOnClickListener(v -> {
            Intent intent = new Intent(RingtoneManager.ACTION_RINGTONE_PICKER);
            intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM);
            intent.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false);
            intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Alarm sesi seç");
            if (!item.ringtoneUri.isEmpty())
                intent.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(item.ringtoneUri));
            try { startActivityForResult(intent, 59); }
            catch (Exception e) { Toast.makeText(this, I18n.tr(this,"Ses seçici bulunamadı"), Toast.LENGTH_SHORT).show(); }
        });
        section(root, "Cihazda Üretilen Özel Alarm Melodisi", "♫");
        selectionRow(root, "♫", "Melodi tipi", TONE_NAMES, toneIndex, which -> toneIndex = which);
        TextView generate = actionButton("✚   Özel melodi oluştur ve seç", false);
        root.addView(generate, bottom(9));
        root.addView(text("Bu melodiler internet olmadan ses senteziyle oluşturulur; yapay zekâ sesi değildir.", 12, MUTED, false), bottom(26));
        generate.setOnClickListener(v -> {
            try {
                String style = TONE_CODES[toneIndex];
                File out = new File(new File(getFilesDir(), "alarm_sounds"), style + ".wav");
                ToneComposer.write(out, style);
                item.ringtoneUri = Uri.fromFile(out).toString();
                Toast.makeText(this, I18n.tr(this,"Özel melodi seçildi"), Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, I18n.tr(this,"Melodi oluşturulamadı: ") + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

        if (!isNew) {
            TextView delete = actionButton("Bu alarmı sil", false);
            root.addView(delete, bottom(15));
            delete.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle(I18n.tr(this,"Alarm silinsin mi?"))
                .setPositiveButton(I18n.tr(this,"Sil"), (d, w) -> {
                    AlarmScheduler.cancel(this, item.id);
                    AlarmRepository.delete(this, item.id);
                    finish();
                }).setNegativeButton(I18n.tr(this,"Vazgeç"), null).show());
        }

        // Sticky save action stays reachable without a long scroll.
        LinearLayout bottomArea = col();
        bottomArea.setPadding(dp(18), dp(9), dp(18), dp(11));
        bottomArea.setBackgroundColor(Color.WHITE);
        TextView save = actionButton("Alarmı Kaydet", true);
        bottomArea.addView(save);
        save.setOnClickListener(v -> save());
        screen.addView(bottomArea);
        setContentView(screen);
    }

    private String formatClock() { return String.format(I18n.locale(this), "%02d:%02d", hour, minute); }

    private void scanCode() {
        try {
            IntentIntegrator integrator = new IntentIntegrator(this);
            integrator.setDesiredBarcodeFormats(IntentIntegrator.ALL_CODE_TYPES);
            integrator.setPrompt("Alarmı kapatmak için okutulacak kodu kaydet");
            integrator.setBeepEnabled(false);
            integrator.initiateScan();
        } catch (Exception e) {
            Toast.makeText(this, I18n.tr(this,"Kamera açılamadı"), Toast.LENGTH_LONG).show();
        }
    }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == REF_PHOTO_REQUEST) {
            if (result == RESULT_OK){
                Toast.makeText(this, I18n.tr(this,"Yatak referansı kaydedildi"), Toast.LENGTH_SHORT).show();
                if(referenceHint!=null)referenceHint.setText(I18n.tr(this,"✓ Yatak referansı kayıtlı"));
            }
            return;
        }
        if (request == 59) {
            if (result == RESULT_OK && data != null) {
                Uri uri = data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI);
                item.ringtoneUri = uri == null ? "" : uri.toString();
                Toast.makeText(this, I18n.tr(this,"Alarm sesi kaydedildi"), Toast.LENGTH_SHORT).show();
            }
            return;
        }
        IntentResult scan = IntentIntegrator.parseActivityResult(request, result, data);
        if (scan != null && scan.getContents() != null) {
            item.barcode = scan.getContents();
            barcodeStatus.setText(I18n.tr(this, "Kayıtlı barkod mevcut ✓"));
        }
    }
    private void save() {
        String selected = MISSION_CODES[missionIndex];
        if (AlarmItem.QR.equals(selected) && item.barcode.isEmpty()) {
            new AlertDialog.Builder(this).setMessage(I18n.tr(this,"Önce kullanılacak QR kod veya barkodu kaydet."))
                .setPositiveButton(I18n.tr(this,"Tamam"), null).show();
            return;
        }
        if ((AlarmItem.BED.equals(selected) || (AlarmItem.PHOTO.equals(selected) && "BED".equals(PHOTO_CODES[photoIndex]))) &&
                !BedReferenceMatcher.available(this)) {
            new AlertDialog.Builder(this).setTitle(I18n.tr(this,"Toplu yatak örneği gerekli"))
                .setMessage(I18n.tr(this,"Yatak toplama görevini kullanmak için yatağın toplu hâlinin bir örnek fotoğrafını kaydet."))
                .setNegativeButton(I18n.tr(this,"Vazgeç"), null)
                .setPositiveButton(I18n.tr(this,"Kamerayı aç"),(dialog,which)->
                    startActivityForResult(new Intent(this,PhotoChallengeActivity.class)
                        .putExtra(PhotoChallengeActivity.EXTRA_TARGET,"BED")
                        .putExtra(PhotoChallengeActivity.EXTRA_CALIBRATE,true),REF_PHOTO_REQUEST)).show();
            return;
        }
        item.hour = hour; item.minute = minute;
        item.title = title.getText().toString().trim().isEmpty() ? "Günaydın!" : title.getText().toString().trim();
        item.daysMask = daysMask;
        item.mission = selected;
        item.yogaPose=YOGA_POSE_CODES[yogaPoseIndex];
        item.yogaHoldSeconds=YOGA_HOLD_TIMES[yogaHoldIndex];
        item.situpTarget=SITUP_REPS[situpIndex];
        item.calorieGoal=CALORIE_GOALS[calorieGoalIndex];
        item.calorieActivity=CALORIE_EXERCISES[calorieExerciseIndex];
        item.calorieWeightKg=calorieWeightKg;
        item.photoTarget = AlarmItem.BED.equals(selected) ? "BED" : PHOTO_CODES[photoIndex];
        String phrase = voicePhrase.getText().toString().trim();
        item.voicePhrase = phrase.isEmpty() ? "BUGUN ERKEN KALKIYORUM" : phrase;
        item.ttsMessage = ttsMessage.getText().toString().trim();
        item.challengeCount = countIndex + 1;
        item.difficulty = difficultyIndex + 1;
        item.snoozeMinutes = SNOOZE_VALUES[snoozeIndex];
        item.snoozeMax = maxSnoozeIndex;
        item.vibrate = vibrate.isChecked();
        item.crescendo = crescendo.isChecked();
        item.enabled = true;
        AlarmScheduler.cancel(this, item.id);
        AlarmRepository.put(this, item);
        boolean ok = AlarmScheduler.schedule(this, item);
        if (!ok) {
            new AlertDialog.Builder(this).setTitle(I18n.tr(this,"Alarm izni gerekli"))
                .setMessage(I18n.tr(this,"Alarm kaydedildi ama kesin zamanlı alarm izni olmadığı için henüz planlanamadı. Uygulamanın izinler bölümünü kontrol et."))
                .setPositiveButton(I18n.tr(this,"Tamam"), (d, w) -> finish()).show();
        } else {
            Toast.makeText(this, I18n.tr(this,"Alarm kaydedildi: ") + item.timeText(), Toast.LENGTH_LONG).show();
            finish();
        }
    }
}
