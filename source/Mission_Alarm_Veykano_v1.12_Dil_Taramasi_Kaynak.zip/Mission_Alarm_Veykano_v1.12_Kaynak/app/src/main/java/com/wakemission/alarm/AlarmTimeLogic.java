package com.wakemission.alarm;

import java.util.Calendar;
import java.util.TimeZone;

/** Pure Java next-occurrence algorithm, independently testable. daysMask: bit 0=Sunday ... 6=Saturday. */
public final class AlarmTimeLogic {
    private AlarmTimeLogic() {}
    public static long nextTriggerMillis(int hour, int minute, int daysMask, long now, TimeZone zone) {
        if(hour<0||hour>23||minute<0||minute>59||daysMask<0||daysMask>127)
            throw new IllegalArgumentException("Invalid alarm time");
        Calendar start=Calendar.getInstance(zone);
        start.setTimeInMillis(now);
        for(int d=0;d<8;d++){
            Calendar date=(Calendar) start.clone();
            date.add(Calendar.DAY_OF_YEAR,d);
            if(daysMask!=0 && (daysMask & (1 << (date.get(Calendar.DAY_OF_WEEK)-1)))==0)continue;
            date.set(Calendar.HOUR_OF_DAY,hour);date.set(Calendar.MINUTE,minute);
            date.set(Calendar.SECOND,0);date.set(Calendar.MILLISECOND,0);
            if(date.getTimeInMillis()>now)return date.getTimeInMillis();
        }
        throw new IllegalStateException("Could not resolve next alarm");
    }
}
