package com.wakemission.alarm;

import android.Manifest;
import android.app.*;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.IBinder;
import java.io.*;
import java.util.*;

/** Explicitly started foreground mic recorder; saves only short sound-triggered clips. */
public final class SleepAudioService extends Service {
    public static final String START="com.wakemission.alarm.START_SLEEP_AUDIO";
    public static final String STOP="com.wakemission.alarm.STOP_SLEEP_AUDIO";
    private static final String CHANNEL="sleep_audio";
    private static final int NOTIFICATION_ID=7307;
    private static final int RATE=16000, FRAME=1600, MAX_EVENTS=80, CLIP_FRAMES=80;
    private static volatile boolean active=false;
    private volatile boolean capture=false;
    private long sessionId;
    private Thread worker;
    public static boolean isRunning(){return active;}
    @Override public IBinder onBind(Intent intent){return null;}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        String action=intent==null?"":intent.getAction();
        if(STOP.equals(action)){capture=false;return START_NOT_STICKY;}
        if(!START.equals(action) || active)return START_NOT_STICKY;
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){stopSelf();return START_NOT_STICKY;}
        active=true;capture=true;
        try {
            showNotification();
            worker=new Thread(this::record,"Mission Alarm Veykano-SleepAudio");worker.start();
        } catch(Exception e){active=false;capture=false;stopSelf();}
        return START_NOT_STICKY;
    }
    private void showNotification(){
        NotificationManager manager=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel c=new NotificationChannel(CHANNEL,"Uyku ses kaydı",NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Uyku ses kaydı açıkken mikrofon kullanımı");
            manager.createNotificationChannel(c);
        }
        Intent open=new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPending=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Intent stop=new Intent(this,SleepAudioService.class).setAction(STOP);
        PendingIntent stopPending=PendingIntent.getService(this,1,stop,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification n=new Notification.Builder(this,CHANNEL)
          .setSmallIcon(R.drawable.ic_notification).setContentTitle("Mission Alarm Veykano • Uyku kaydı açık")
          .setContentText(I18n.tr(this,"Ses algılanınca kısa kayıtlar cihazına kaydedilir"))
          .setContentIntent(openPending).setOngoing(true)
          .addAction(new Notification.Action.Builder(null,"Kaydı durdur",stopPending).build()).build();
        if(Build.VERSION.SDK_INT>=29)startForeground(NOTIFICATION_ID,n,android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        else startForeground(NOTIFICATION_ID,n);
    }
    private void record(){
        AudioRecord mic=null;
        try {
            int min=AudioRecord.getMinBufferSize(RATE,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT);
            if(min<=0)throw new IOException("Mikrofon kullanılamıyor");
            mic=new AudioRecord(MediaRecorder.AudioSource.MIC,RATE,AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,Math.max(min,FRAME*2*5));
            if(mic.getState()!=AudioRecord.STATE_INITIALIZED)throw new IOException("Ses kayıt başlatılamadı");
            mic.startRecording();
            if(mic.getRecordingState()!=AudioRecord.RECORDSTATE_RECORDING)throw new IOException("Mikrofon başlatılamadı");
            sessionId=SleepRecordStore.begin(this);
            ArrayDeque<short[]> before=new ArrayDeque<>();
            ArrayList<short[]> clip=null;
            double floor=280.0;
            int loudFrames=0, events=0;
            long lastCompleted=0;
            while(capture){
                short[] chunk=new short[FRAME];
                int read=mic.read(chunk,0,FRAME);
                if(read<=0){if(read<0)break;continue;}
                if(read<FRAME)chunk=Arrays.copyOf(chunk,read);
                long sum=0;
                for(short sample:chunk)sum+=(long)sample*sample;
                double rms=Math.sqrt(sum/(double)read);
                boolean loud=rms>Math.max(850,floor*2.6);
                if(!loud)floor=Math.max(90,Math.min(1800,floor*.995+rms*.005));
                loudFrames=loud?Math.min(10,loudFrames+1):0;
                if(clip!=null){
                    clip.add(chunk);
                    if(clip.size()>=CLIP_FRAMES){
                        saveClip(clip);events++;lastCompleted=System.currentTimeMillis();clip=null;
                    }
                }else if(events<MAX_EVENTS && loudFrames>=3 && System.currentTimeMillis()-lastCompleted>9000){
                    clip=new ArrayList<>(CLIP_FRAMES+25);
                    clip.addAll(before);clip.add(chunk);
                    loudFrames=0;
                }
                before.addLast(chunk);
                if(before.size()>20)before.removeFirst();
            }
            if(clip!=null && clip.size()>12)saveClip(clip);
        }catch(Exception e){
            android.util.Log.e("Mission Alarm VeykanoSleep","Uyku ses kaydı durdu",e);
        }finally{
            if(mic!=null){try{mic.stop();}catch(Exception ignored){}mic.release();}
            if(sessionId!=0L)SleepRecordStore.finish(this,sessionId);
            capture=false;active=false;
            stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();
        }
    }
    private void saveClip(ArrayList<short[]> clip){
        File f=null;
        try {
            f=new File(SleepRecordStore.recordingsDirectory(this),"night_"+sessionId+"_"+System.nanoTime()+".wav");
            int count=0;for(short[] a:clip)count+=a.length;
            try(BufferedOutputStream out=new BufferedOutputStream(new FileOutputStream(f))){
                writeAscii(out,"RIFF");writeLe32(out,36+count*2);writeAscii(out,"WAVE");
                writeAscii(out,"fmt ");writeLe32(out,16);writeLe16(out,1);writeLe16(out,1);
                writeLe32(out,RATE);writeLe32(out,RATE*2);writeLe16(out,2);writeLe16(out,16);
                writeAscii(out,"data");writeLe32(out,count*2);
                for(short[] a:clip)for(short s:a){out.write(s&0xff);out.write((s>>>8)&0xff);}
            }
            String suspected=SleepSoundClassifier.classify(clip);
            // Timestamp the START of the captured sound, not the moment the clip was saved.
            long firstSoundAt=System.currentTimeMillis()-(count*1000L/RATE);
            SleepRecordStore.addEvent(this,sessionId,suspected,f.getAbsolutePath(),firstSoundAt,"");
        }catch(Exception e){if(f!=null)f.delete();android.util.Log.e("Mission Alarm VeykanoSleep","Ses dosyası yazılamadı",e);}
    }
    private static void writeAscii(OutputStream out,String v)throws IOException{out.write(v.getBytes(java.nio.charset.StandardCharsets.US_ASCII));}
    private static void writeLe16(OutputStream out,int n)throws IOException{out.write(n&255);out.write((n>>8)&255);}
    private static void writeLe32(OutputStream out,int n)throws IOException{for(int i=0;i<4;i++)out.write((n>>(8*i))&255);}
    @Override public void onDestroy(){capture=false;super.onDestroy();}
}
