package com.wakemission.alarm;

import java.util.Locale;

/** Allows common ML Kit label variants, but still demands a target-related label. */
public final class PhotoLabelMatcher {
    private PhotoLabelMatcher(){}
    public static boolean matches(String target,String name){
        if(target==null||name==null)return false;
        final String[] aliases;
        switch(target){
            case "SKY":aliases=new String[]{"sky","cloud","sunset","sunrise","atmosphere","blue sky","daylight"};break;
            case "BED":aliases=new String[]{"bed","bedroom","bedding","mattress","pillow","bed sheet","blanket"};break;
            case "BOOK":aliases=new String[]{"book","textbook","publication","reading material","novel"};break;
            case "CUP":aliases=new String[]{"cup","mug","coffee cup","teacup","drinkware"};break;
            case "PET":aliases=new String[]{"dog","cat","puppy","kitten","pet"};break;
            case "SHOE":aliases=new String[]{"shoe","footwear","sneaker","boot","high heel"};break;
            case "BOTTLE":aliases=new String[]{"bottle","water bottle","plastic bottle","glass bottle"};break;
            case "CHAIR":aliases=new String[]{"chair","armchair","stool","seat","office chair"};break;
            default:return false;
        }
        String normalized=" "+name.toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}0-9]+"," ").trim()+" ";
        for(String alias:aliases)if(normalized.contains(" "+alias+" "))return true;
        return false;
    }
}
