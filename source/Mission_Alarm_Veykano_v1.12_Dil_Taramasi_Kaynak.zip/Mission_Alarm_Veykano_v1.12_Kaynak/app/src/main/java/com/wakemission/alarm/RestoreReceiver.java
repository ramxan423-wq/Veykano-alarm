package com.wakemission.alarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public final class RestoreReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c,Intent i){
        // Android does not preserve AlarmManager alarms across device restarts.
        AlarmScheduler.scheduleAll(c);
    }
}
