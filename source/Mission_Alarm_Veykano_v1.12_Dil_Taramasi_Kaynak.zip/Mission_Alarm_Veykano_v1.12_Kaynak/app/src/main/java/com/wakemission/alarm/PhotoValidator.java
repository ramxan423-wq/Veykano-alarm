package com.wakemission.alarm;

import android.content.Context;
import android.graphics.Bitmap;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.label.ImageLabeler;
import com.google.mlkit.vision.label.ImageLabeling;
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions;
import com.google.mlkit.vision.label.ImageLabel;
import java.util.Locale;

/** On-device object labels + reference-based bed scene similarity. */
public final class PhotoValidator {
    public interface Callback {void result(boolean passed,String detail);}
    public static void verify(Context context,Bitmap bitmap,String target,Callback cb){
        if(bitmap==null){cb.result(false,"Fotoğraf alınamadı.");return;}
        if(!java.util.Arrays.asList("SKY","BED","BOOK","CUP","PET","SHOE","BOTTLE","CHAIR").contains(target)){
            cb.result(false,"Bu nesne tipi tanımlı değil.");return;
        }
        if(target.equals("BED")&&!BedReferenceMatcher.available(context)){
            cb.result(false,"Önce alarm ayarlarından toplu yatağının referansını kaydet.");return;
        }
        if(target.equals("BED")){
            double score=BedReferenceMatcher.match(context,bitmap);
            cb.result(BedReferenceMatcher.accept(score),
                "Toplu yatak örneğine görsel benzerlik: %"+(int)(score*100)+
                ". Aynı açıdan tekrar çekebilirsin. Bu, yatağın gerçekten toplandığına dair kesin kanıt değildir.");
            return;
        }
        try {
            ImageLabeler labeler=ImageLabeling.getClient(new ImageLabelerOptions.Builder()
                    .setConfidenceThreshold(.35f).build());
            labeler.process(InputImage.fromBitmap(bitmap,0))
                .addOnSuccessListener(labels->{
                    boolean ok=false;StringBuilder observed=new StringBuilder();
                    for(ImageLabel label:labels){
                        String name=label.getText();
                        if(observed.length()>0)observed.append(", ");observed.append(name);
                        if(PhotoLabelMatcher.matches(target,name))ok=true;
                    }
                    if(!ok){cb.result(false,observed.length()==0?
                        "Nesne algılanamadı. İyi ışıkta, hedefi ortalayarak yeniden çek.":
                        "İstenen nesne bulunamadı. Algılanan: "+observed);return;}
                    cb.result(true,"İstenen nesne tanındı.");
                })
                .addOnFailureListener(e->cb.result(false,"Görüntü modeli çalışmadı: "+e.getClass().getSimpleName()))
                .addOnCompleteListener(t->labeler.close());
        }catch(Exception e){cb.result(false,"Görüntü modeli başlatılamadı: "+e.getClass().getSimpleName());}
    }
}
