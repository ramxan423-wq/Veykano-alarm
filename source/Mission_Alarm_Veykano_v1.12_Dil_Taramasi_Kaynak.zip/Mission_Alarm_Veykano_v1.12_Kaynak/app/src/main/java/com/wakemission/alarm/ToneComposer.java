package com.wakemission.alarm;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

/** Offline, royalty-free synthesized melodies. NOT text-to-audio artificial intelligence. */
public final class ToneComposer {
    private static final int RATE=16000;
    private ToneComposer(){}
    private static void little16(FileOutputStream o,int n)throws IOException{o.write(n&255);o.write((n>>>8)&255);}
    private static void little32(FileOutputStream o,int n)throws IOException{little16(o,n);little16(o,n>>>16);}
    public static void write(File dest,String mood)throws IOException{
        final int length=8*RATE;
        final int[] notes=mood.equals("soft")?new int[]{523,659,784,659,523,659,784,1046}:
              mood.equals("strong")?new int[]{784,988,1174,988,784,988,1174,1318}:
              new int[]{440,554,659,880,659,554,440,659};
        if(!dest.getParentFile().exists()&&!dest.getParentFile().mkdirs())throw new IOException("sound directory not created");
        try(FileOutputStream out=new FileOutputStream(dest)){
            out.write(new byte[]{'R','I','F','F'});little32(out,36+length*2);
            out.write(new byte[]{'W','A','V','E','f','m','t',' '});little32(out,16);little16(out,1);
            little16(out,1);little32(out,RATE);little32(out,RATE*2);little16(out,2);little16(out,16);
            out.write(new byte[]{'d','a','t','a'});little32(out,length*2);
            for(int i=0;i<length;i++){
                double t=i/(double)RATE;
                double phase=t%1;
                int frequency=notes[((int)t)%notes.length];
                double envelope=Math.min(1,phase*15)*Math.min(1,(1-phase)*8);
                double fundamental=Math.sin(2*Math.PI*frequency*t);
                double harmonic=.22*Math.sin(4*Math.PI*frequency*t);
                double sample=(fundamental+harmonic)*envelope*.34;
                short s=(short)Math.round(Math.max(-1,Math.min(1,sample))*32767);
                little16(out,s);
            }
        }
    }
}
