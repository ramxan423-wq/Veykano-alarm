package com.wakemission.alarm;

/** On-device, approximate 2D pose tests. NOT a medical or exact yoga-form assessment. */
public final class YogaPoseLogic {
    private YogaPoseLogic(){}
    // These joint positions match ML Kit PoseLandmark type IDs.
    public static final int LEFT_SHOULDER=11,RIGHT_SHOULDER=12,LEFT_ELBOW=13,RIGHT_ELBOW=14,
        LEFT_WRIST=15,RIGHT_WRIST=16,LEFT_HIP=23,RIGHT_HIP=24,LEFT_KNEE=25,RIGHT_KNEE=26,
        LEFT_ANKLE=27,RIGHT_ANKLE=28;
    public static final String ARMS_UP="ARMS_UP",MOUNTAIN="MOUNTAIN",WARRIOR_II="WARRIOR_II";
    public static String safePose(String pose){return MOUNTAIN.equals(pose)||WARRIOR_II.equals(pose)?pose:ARMS_UP;}
    public static String title(String pose){
        if(MOUNTAIN.equals(pose))return "Dağ Duruşu";
        if(WARRIOR_II.equals(pose))return "Savaşçı II";
        return "Kollar Yukarı";
    }
    public static final class Joint {
        public final float x,y,confidence;
        public Joint(float x,float y,float confidence){this.x=x;this.y=y;this.confidence=confidence;}
    }
    private static boolean seen(Joint[] p,int id){return p!=null && id<p.length && p[id]!=null &&
        p[id].confidence>=0.62f && Float.isFinite(p[id].x) && Float.isFinite(p[id].y);}
    private static double angle(Joint a,Joint b,Joint c){
        double ux=a.x-b.x,uy=a.y-b.y,vx=c.x-b.x,vy=c.y-b.y;
        double n=Math.hypot(ux,uy)*Math.hypot(vx,vy);
        if(n<1)return Double.NaN;
        return Math.toDegrees(Math.acos(Math.max(-1,Math.min(1,(ux*vx+uy*vy)/n))));
    }
    public static boolean matches(String mode,Joint[] p){
        int[] req={LEFT_SHOULDER,RIGHT_SHOULDER,LEFT_ELBOW,RIGHT_ELBOW,LEFT_WRIST,RIGHT_WRIST,
            LEFT_HIP,RIGHT_HIP,LEFT_KNEE,RIGHT_KNEE,LEFT_ANKLE,RIGHT_ANKLE};
        for(int joint:req)if(!seen(p,joint))return false;
        Joint ls=p[LEFT_SHOULDER],rs=p[RIGHT_SHOULDER],le=p[LEFT_ELBOW],re=p[RIGHT_ELBOW],
            lw=p[LEFT_WRIST],rw=p[RIGHT_WRIST],lh=p[LEFT_HIP],rh=p[RIGHT_HIP],
            lk=p[LEFT_KNEE],rk=p[RIGHT_KNEE],la=p[LEFT_ANKLE],ra=p[RIGHT_ANKLE];
        double torso=((lh.y+rh.y)-(ls.y+rs.y))/2.0;
        if(torso<20 || !Double.isFinite(torso))return false; // A side view or truncated body is unreliable.
        double armsL=angle(ls,le,lw),armsR=angle(rs,re,rw);
        double kneeL=angle(lh,lk,la),kneeR=angle(rh,rk,ra);
        if(!Double.isFinite(armsL)||!Double.isFinite(armsR)||!Double.isFinite(kneeL)||!Double.isFinite(kneeR))return false;
        if(WARRIOR_II.equals(mode)){
            boolean arms=armsL>145&&armsR>145 &&
                Math.abs(lw.x-ls.x)>.65*torso && Math.abs(rw.x-rs.x)>.65*torso &&
                Math.abs(lw.y-ls.y)<.55*torso && Math.abs(rw.y-rs.y)<.55*torso;
            boolean legs=(kneeL>=83&&kneeL<=143&&kneeR>150) || (kneeR>=83&&kneeR<=143&&kneeL>150);
            return arms&&legs&&Math.abs(la.x-ra.x)>1.3*torso;
        }
        if(kneeL<150||kneeR<150)return false;
        if(MOUNTAIN.equals(mode)){
            return armsL>145 && armsR>145 &&
                lw.y>lh.y-.10*torso && rw.y>rh.y-.10*torso &&
                Math.abs(lw.x-lh.x)<.8*torso && Math.abs(rw.x-rh.x)<.8*torso;
        }
        return armsL>145 && armsR>145 &&
            lw.y<ls.y-.36*torso && rw.y<rs.y-.36*torso &&
            le.y<ls.y+.14*torso && re.y<rs.y+.14*torso;
    }
}
