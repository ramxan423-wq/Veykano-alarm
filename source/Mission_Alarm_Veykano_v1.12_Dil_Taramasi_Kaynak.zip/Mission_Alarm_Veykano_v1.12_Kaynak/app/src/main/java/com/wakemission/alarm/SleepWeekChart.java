package com.wakemission.alarm;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

/** Blue/grey seven-day sleep chart from actual saved durations, without fabricated values. */
public final class SleepWeekChart extends View {
    private final int[] days;
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    public SleepWeekChart(Context c,int[] durations){super(c);days=durations.clone();}
    @Override protected void onMeasure(int w,int h){
        setMeasuredDimension(MeasureSpec.getSize(w),MeasureSpec.getMode(h)==MeasureSpec.EXACTLY?
            MeasureSpec.getSize(h):Ui.dp(getContext(),102));
    }
    @Override protected void onDraw(Canvas c){super.onDraw(c);
        float w=getWidth(),height=getHeight(),interval=(w-20)/7f;
        float barTop=Ui.dp(getContext(),10),base=height-Ui.dp(getContext(),26);
        // Mon-Sun labels based on the in-app locale.
        String[] shortDays=java.text.DateFormatSymbols.getInstance(I18n.locale(getContext())).getShortWeekdays();
        String[] labels=new String[7];
        for(int day=0;day<7;day++){
            int calDay=(day+1)%7+1;
            String label=shortDays[calDay];
            labels[day]=label==null||label.trim().isEmpty()?String.valueOf(day+1):label.trim();
        }
        p.setTextSize(Ui.dp(getContext(),10));p.setTextAlign(Paint.Align.CENTER);
        for(int i=0;i<7;i++){
            float center=interval*(i+.5f),barWidth=interval*.46f;
            if(days[i]>0){
                float blue=Math.max(Ui.dp(getContext(),5),(base-barTop)*Math.min(days[i],10)/10f);
                float grey=Math.min((base-barTop)*.25f,blue*.2f);
                p.setColor(0xFF1D376D);c.drawRoundRect(center-barWidth/2,base-blue,center+barWidth/2,base,Ui.dp(getContext(),3),Ui.dp(getContext(),3),p);
                p.setColor(0xFFABB0B6);c.drawRoundRect(center-barWidth/2,base-blue,center+barWidth/2,base-blue+grey,Ui.dp(getContext(),3),Ui.dp(getContext(),3),p);
            }
            p.setColor(Ui.MUTED);c.drawText(labels[i],center,height-Ui.dp(getContext(),5),p);
        }
        p.setTextAlign(Paint.Align.RIGHT);p.setColor(Ui.MUTED);
        c.drawText(I18n.tr(getContext(),"10h"),w,height*.18f,p);c.drawText(I18n.tr(getContext(),"5h"),w,height*.52f,p);c.drawText(I18n.tr(getContext(),"0h"),w,height*.77f,p);
    }
}
