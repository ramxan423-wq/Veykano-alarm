package com.wakemission.alarm;
import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.widget.*;
import android.view.Gravity;

/** Celebration screen appears only after a completed challenge. */
public final class SuccessActivity extends Activity {
    @Override public void onCreate(Bundle state){super.onCreate(state);AppTheme.apply(this);
        long ms=Math.max(0,getIntent().getLongExtra("duration_ms",0));
        Achievements achievement=Achievements.from(AlarmRepository.history(this));
        ScrollView sc=new ScrollView(this);sc.setBackgroundColor(Ui.BG);
        LinearLayout root=Ui.column(this);root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(Ui.dp(this,25),Ui.dp(this,90),Ui.dp(this,25),Ui.dp(this,32));sc.addView(root);
        root.addView(Ui.text(this,"☀️",66,Ui.PEACH,true));Ui.space(root,16);
        root.addView(Ui.text(this,"Güne başladın!",32,Ui.WHITE,true));Ui.space(root,14);
        root.addView(Ui.text(this,"Görev süresi: "+(ms/1000)+" saniye",18,Ui.GREEN,true));Ui.space(root,20);
        root.addView(Ui.text(this,"🔥 "+achievement.streak+" günlük seri",22,Ui.WHITE,true));
        root.addView(Ui.text(this,"Toplam "+achievement.completed+" görev tamamladın.",16,Ui.MUTED,false));
        Ui.space(root,22);root.addView(Ui.text(this,achievement.badges(),15,Ui.PEACH,true));
        Ui.space(root,24);
        Button done=Ui.button(this,"Harika, devam et!",true);root.addView(done,Ui.matchMargins(this,14));
        done.setOnClickListener(v->{startActivity(new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));finish();});
        setContentView(sc);
    }
}
