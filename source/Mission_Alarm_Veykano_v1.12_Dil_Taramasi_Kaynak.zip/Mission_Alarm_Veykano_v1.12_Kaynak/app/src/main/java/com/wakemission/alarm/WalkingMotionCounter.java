package com.wakemission.alarm;

/** Best-effort cadence detection when hardware STEP_DETECTOR/STEP_COUNTER is unavailable.
 * Uses only accelerometer magnitudes after subtracting a smoothed gravity estimate.
 * Counts repeated walking pulses, never the first isolated phone movement.
 */
public final class WalkingMotionCounter {
    private float gravityX,gravityY,gravityZ;
    private boolean initialized=false,armed=true;
    private long lastPeakNs=0;
    private int pending=0;
    public void reset(){initialized=false;armed=true;lastPeakNs=0;pending=0;gravityX=gravityY=gravityZ=0;}
    public int onSample(long timestampNs,float x,float y,float z){
        if(!initialized){gravityX=x;gravityY=y;gravityZ=z;initialized=true;return 0;}
        gravityX=0.87f*gravityX+0.13f*x;
        gravityY=0.87f*gravityY+0.13f*y;
        gravityZ=0.87f*gravityZ+0.13f*z;
        float dx=x-gravityX,dy=y-gravityY,dz=z-gravityZ;
        double impulse=Math.sqrt(dx*dx+dy*dy+dz*dz);
        if(impulse<0.65){armed=true;return 0;}
        if(!armed||impulse<1.8)return 0;
        armed=false;
        if(lastPeakNs!=0 && timestampNs-lastPeakNs<330_000_000L)return 0;
        if(lastPeakNs!=0 && timestampNs-lastPeakNs<=1_600_000_000L){
            lastPeakNs=timestampNs;
            if(pending>0){pending=0;return 2;}
            return 1;
        }
        // Require two plausible pulses to avoid counting an isolated shake.
        pending=1;lastPeakNs=timestampNs;
        return 0;
    }
}
