package com.wakemission.alarm;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.view.View;

/** The four supported palettes. Selection is local and persists between launches. */
public final class AppTheme {
    public static final String DAYBREAK="morning_cream", BORDEAUX="white_burgundy", PREMIUM="premium_white", CLASSIC="classic", NEON="neon", SPACE="space";
    public final String key, title, subtitle;
    public final int background, panel, ink, muted, primary, gradientEnd, secondary, accent, green, nav, outline, shadow;
    public final boolean light;
    private AppTheme(String key,String title,String subtitle,boolean light,String... colors){
        this.key=key;this.title=title;this.subtitle=subtitle;this.light=light;
        int[] vals=new int[colors.length];for(int i=0;i<colors.length;i++)vals[i]=Color.parseColor(colors[i]);
        background=vals[0];panel=vals[1];ink=vals[2];muted=vals[3];primary=vals[4];gradientEnd=vals[5];
        secondary=vals[6];accent=vals[7];green=vals[8];nav=vals[9];outline=vals[10];shadow=vals[11];
    }
    private static final AppTheme[] THEMES = {
        new AppTheme(DAYBREAK,"Sabah Işığı","Referans görsel • krem ve parlak sarı",true,
            "#FAF8F3","#FFFFFF","#151515","#717171","#FFCB35","#FFD84B","#F5F3ED","#FFCC32","#28B36D","#FAF9F5","#F0EEE8","#E3DACA"),
        new AppTheme(BORDEAUX,"Beyaz Bordo","Önceki beyaz-bordo alarm görünümü",true,
            "#FCFBFB","#FFFFFF","#1C181E","#736F78","#7D0C2B","#A53B51","#FBEFF1","#9B2948","#17A676","#F4F0F1","#EBE5E7","#D9C3C9"),
        new AppTheme(PREMIUM,"Modern Beyaz","Temiz beyaz • yumuşak mavi • cam alt menü",true,
            "#F8FAFD","#FFFFFF","#111B33","#7D899B","#2685FA","#53ACF9","#EDF4FC","#2E8FFD","#12A986","#EFF2F6","#E8EDF4","#C2D0DE"),
        new AppTheme(CLASSIC,"Klasik","Lacivert ve mavi",false,
            "#071C38","#102C50","#F6F9FF","#AAC0D7","#168CF6","#42B2FD","#1E3D62","#55B9FF","#3ED8AC","#173355","#2A496C","#020F24"),
        new AppTheme(NEON,"Neon","Gece siyahı • elektrik mavisi • mor",false,
            "#090C19","#141A2C","#F9FAFF","#9AA4C3","#12DAF8","#9B4DFF","#202640","#CB64FF","#38E5B4","#1C2035","#3C355D","#030511"),
        new AppTheme(SPACE,"Uzay","Koyu mor • gece gökyüzü",false,
            "#110D2D","#211A44","#FAF7FF","#B6AAD5","#815AFD","#D06FFA","#302657","#C7A2FF","#43DCB5","#271F4A","#453664","#090622")
    };
    public static AppTheme[] options(){return THEMES.clone();}
    public static String selected(Context c){return c.getSharedPreferences("display_settings",Context.MODE_PRIVATE).getString("theme",DAYBREAK);}
    public static AppTheme current(Context c){String s=selected(c);for(AppTheme t:THEMES)if(t.key.equals(s))return t;return THEMES[0];}
    public static void choose(Context c,String name){boolean valid=false;for(AppTheme t:THEMES)if(t.key.equals(name))valid=true;
        if(!valid)return;c.getSharedPreferences("display_settings",Context.MODE_PRIVATE).edit().putString("theme",name).apply();}
    public static void apply(Activity activity){
        AppTheme p=current(activity); Ui.BG=p.background;Ui.PANEL=p.panel;Ui.WHITE=p.ink;Ui.MUTED=p.muted;
        Ui.PURPLE=p.primary;Ui.PEACH=p.accent;Ui.GREEN=p.green;Ui.SECONDARY=p.secondary;
        Ui.GRADIENT_END=p.gradientEnd;Ui.NAV=p.nav;Ui.OUTLINE=p.outline;Ui.LIGHT=p.light;
        activity.getWindow().getDecorView().setLayoutDirection(I18n.isRtl(activity)?View.LAYOUT_DIRECTION_RTL:View.LAYOUT_DIRECTION_LTR);
        activity.getWindow().setStatusBarColor(p.background);activity.getWindow().setNavigationBarColor(p.background);
        if(Build.VERSION.SDK_INT>=26){int flags=activity.getWindow().getDecorView().getSystemUiVisibility();
            flags &= ~(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
            if(p.light)flags|=View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            activity.getWindow().getDecorView().setSystemUiVisibility(flags);
        }
    }
}
