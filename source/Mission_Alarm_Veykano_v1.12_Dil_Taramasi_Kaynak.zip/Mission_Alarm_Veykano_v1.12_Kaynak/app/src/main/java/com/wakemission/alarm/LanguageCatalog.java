package com.wakemission.alarm;

import java.util.Locale;
/** Stable app-language catalog. More than 100 choices; untranslated UI uses English fallback. */
public final class LanguageCatalog {
    private LanguageCatalog(){}
    public static final String[] CODES={"en","tr","es","fr","de","it","pt","pt-BR","nl","pl","ru","uk","ar","fa","hi","ur","bn","pa","gu","mr","ta","te","kn","ml","or","as","ne","si","th","vi","id","ms","fil","jv","su","my","km","lo","zh-Hans","zh-Hant","ja","ko","mn","kk","ky","uz","tk","tg","az","hy","ka","he","yi","el","bg","ro","hu","cs","sk","sl","hr","sr","bs","mk","sq","et","lv","lt","fi","sv","no","da","is","ga","cy","gd","mt","eu","ca","gl","af","sw","am","ha","yo","ig","zu","xh","st","sn","ny","so","om","rw","ti","mg","mi","sm","to","fj","eo","la","be","lb","fy","br","co","oc","ku","ps","sd","ug","bo","dz","iu","kl","fo","se","ba","tt","cv","sah","ce","av","ab","os","ckb","nn","en-GB","es-MX","fr-CA","pt-PT","zh","fr-BE","de-AT","en-IN","en-AU","en-US","nb"};
    public static String label(String tag){
        Locale l=Locale.forLanguageTag(tag);
        String nativeName=l.getDisplayName(l);
        String english=l.getDisplayName(Locale.ENGLISH);
        if(nativeName==null||nativeName.isEmpty()||nativeName.equals(tag))nativeName=english;
        if("en".equals(tag))return "English";
        return nativeName+(nativeName.equalsIgnoreCase(english)?"":" / "+english);
    }
    public static boolean isTranslated(String tag){
        return tag.startsWith("en");
    }
}
