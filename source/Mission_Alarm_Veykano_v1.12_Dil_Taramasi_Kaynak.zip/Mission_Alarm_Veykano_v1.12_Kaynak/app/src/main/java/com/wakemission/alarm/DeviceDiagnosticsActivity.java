package com.wakemission.alarm;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.speech.SpeechRecognizer;
import android.widget.*;

/** Manual phone preflight: informational only; cannot prove an alarm will ring. */
public final class DeviceDiagnosticsActivity extends Activity {
    private LinearLayout root;
    @Override public void onCreate(Bundle b){super.onCreate(b);AppTheme.apply(this);render();}
    @Override public void onResume(){super.onResume();render();}
    private void line(String label,boolean pass,String guidance){
        LinearLayout item=Ui.card(this);
        item.addView(Ui.text(this,(pass?"✓  ":"⚠  ")+label,17,pass?Ui.GREEN:Ui.PEACH,true));
        if(!pass)item.addView(Ui.text(this,guidance,13,Ui.MUTED,false));
        root.addView(item,Ui.matchMargins(this,9));
    }
    private void render(){
        ScrollView scroll=new ScrollView(this);scroll.setBackgroundColor(Ui.BG);
        root=Ui.column(this);root.setPadding(Ui.dp(this,18),Ui.dp(this,35),Ui.dp(this,18),Ui.dp(this,35));
        scroll.addView(root);
        root.addView(Ui.text(this,"Telefon uygunluk kontrolü / Phone check",26,Ui.WHITE,true));
        root.addView(Ui.text(this,"Bu liste izinleri ve sensörleri kontrol eder. Alarmın gerçekten çaldığını doğrulamak için 2 dakika test alarmını çalıştır.",14,Ui.MUTED,false));
        AlarmManager alarm=(AlarmManager)getSystemService(ALARM_SERVICE);
        line("Kesin alarm izni",alarm!=null&&(Build.VERSION.SDK_INT<31||alarm.canScheduleExactAlarms()),"Kesin alarm iznini cihaz ayarlarında aç.");
        NotificationManager notices=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        line("Bildirimler",notices!=null && notices.areNotificationsEnabled() &&
            (Build.VERSION.SDK_INT<33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED),
            "Bildirim izinlerini etkinleştir.");
        if(Build.VERSION.SDK_INT>=34)line("Tam ekran kilit alarmı",notices!=null&&notices.canUseFullScreenIntent(),
            "Ayarlar > Tam ekran bildirim iznini etkinleştir.");
        AudioManager audio=(AudioManager)getSystemService(AUDIO_SERVICE);
        line("Alarm ses seviyesi",audio!=null&&audio.getStreamVolume(AudioManager.STREAM_ALARM)>0,"Alarm sesini yükselt.");
        PowerManager power=(PowerManager)getSystemService(POWER_SERVICE);
        line("Pil optimizasyonu izni",power!=null&&power.isIgnoringBatteryOptimizations(getPackageName()),
            "Pil optimizasyonları ve üretici arka plan kısıtlamalarını ayrıca kontrol et; her cihazda muafiyet gerekmeyebilir.");
        line("Kamera",getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY) &&
            checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED,
            "Şınav veya fotoğraf görevleri için kamera iznini aç.");
        SensorManager sensors=(SensorManager)getSystemService(SENSOR_SERVICE);
        line("Adım sensörü",sensors!=null&&sensors.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR)!=null,
            "Adım sensörü olmayan cihazlarda yürüme görevini seçme.");
        line("İvmeölçer",sensors!=null&&sensors.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)!=null,
            "Sallama görevi bu cihazda çalışmayabilir.");
        line("Konuşma tanıma hizmeti",SpeechRecognizer.isRecognitionAvailable(this),
            "Sesli görev bu cihazda desteklenmeyebilir veya çevrimiçi çalışabilir.");
        Button settings=Ui.button(this,"Uygulama izinlerini aç",true);
        root.addView(settings,Ui.matchMargins(this,10));
        settings.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            .setData(android.net.Uri.parse("package:"+getPackageName()))));
        Button back=Ui.button(this,"Alarm ekranına dön",false);root.addView(back);
        back.setOnClickListener(v->finish());
        setContentView(scroll);
    }
}
