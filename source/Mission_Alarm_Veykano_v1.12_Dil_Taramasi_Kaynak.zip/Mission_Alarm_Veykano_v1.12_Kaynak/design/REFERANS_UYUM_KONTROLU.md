# WakeMission v1.1 – Referans ekran uyum notu

## Referans
`WakeMission_kullanici_referansi.png` kullanıcının gönderdiği 2 x 4 telefon ekranından oluşan görseldir (1536 x 1404 piksel). Bu görsel çalışan arayüzün yerine kullanılmaz; gerçek uygulama düzeni için karşılaştırma kaynağıdır.

## Güncellenen gerçek ekranlar
1. **Ana sayfa:** krem arka plan, WakeMission başlığı, hafta şeridi, seri kartı, siyah alarm kartı, dört beyaz hızlı işlem kartı, özel çizim ikonlar, sarı seçili alt gezinme.
2. **Alarm Kur:** orijinal beyaz/sarı editör, saat tekeri, gün seçimi, dört ayar satırı, altta kaydet. Mevcut gelişmiş özellikler korunmuştur.
3. **Görev Seç:** 8 ana görevde metin, beyaz kart ve vektör ikonlar; Şınav sarı çerçeveli. Diğer mevcut görevler kaydırılabilir altta tutulur.
4. **Şınav Görevi:** gerçek CameraX kamera görüntüsü, ML Kit canlı poz algılama, kamera ile hizalanan beyaz omuz/kol çizgileri ve eklem noktaları, 0/20 sayaç, sarı ilerleme çubuğu, duraklat ve alt tavsiye kutusu. Kamera izni gerekir. Sahte örnek insan fotoğrafı kullanılmaz.
5. **Uyku Analizi:** sarı sekmeler, ortalama uyku kartı, mavi/gri grafik, Son Kayıtlar başlığı. Gerçek uyku olayları ve mikrofon kontrolleri korunmuştur.
6. **İstatistikler:** sarı sütunlar ve 4 temel metrik kartı. Veriler cihazdaki gerçek olaylardan hesaplanır.
7. **Alarmlar:** kaydedilmiş alarmlar, sarı anahtarlar, satır detayları ve menü.
8. **Profil:** kullanıcı/seri kartı, ortak beyaz menü paneli, referansa yakın simgeler ve alt gezinme.

## İşlevsel doğrulama gerekenler
- Huawei P20 lite dahil gerçek cihazlarda Android Studio üzerinden Gradle derlemesi yap.
- Şınav kamerasını ışık ve farklı açı koşullarında test et; kamerada gövde tam görünürken beyaz nokta/çizgi omuz–dirsek–bileğe oturmalı.
- Kol inip kalkınca sayaç 0/20 → 1/20 ilerlemeli; yalnızca tam tekrarda artmalı.
- Kamera ekranında duraklat/resume çalışmalı; uygulama/ekran geri dönüşü alarm güvenliğini bozmamalı.
- 8 ekranın gerçek ekran görüntülerini **aynı Android çözünürlüğü, ekran yoğunluğu ve yazı ölçeği** ile alıp referans ile üst üste karşılaştır; her cihazda birebir piksel eşitliği test edilmemiştir.
- Veriler gerçektir. Örnekteki `7 günlük seri`, `%92` ve kayıt sayıları test cihazındaki gerçek veriye göre farklı olabilir.

## Sürüm / dağıtım
`versionCode=11`, `versionName=1.1.0`. Bu klasör Android Studio kaynak projesidir; **APK/AAB içermez**. Burada Android SDK, Gradle bağımlılıkları ve gerçek kamera cihazı bulunmadığından derleme ve kamera testi doğrulanamamıştır.
