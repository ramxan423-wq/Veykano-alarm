# WakeMission v0.9 — referans tasarım

Referans: ChatGPT içinde üretilmiş sekiz ekranlık WakeMission sarı/beyaz konsept görseli.

## Görsel şartname
- Arka plan: #FAF8F3; kart: #FFFFFF; ana yazı: #151515.
- Vurgu: #FFCB35 / #FFCC32; ikincil metin: #717171.
- Ana navigasyon: Ana Sayfa, Alarmlar, Analizler, Profil.
- Ana sayfa: haftalık şerit; günlük seri; koyu sonraki alarm kartı; 2x2 kısayol.
- Görevler: iki sütun, Şınav/Squat/Fotoğraf/Matematik/QR/Yürüme/Ses/Dokunmatik. Diğer görevler korunur.
- Alarmlar: yüksek saat, sarı anahtar, düzenleme menüsü.
- Analiz: gerçek kayıt verileri; uydurma örnek ölçümleri kullanılmaz.
- Profil: başarılar/geçmiş/ayarlar/yardım/hakkında.
- Uyku ses kaydı, kabus notu, kamera görevi ve diğer özellikler korunur.

**Not**: Görsel bir konsepttir; tam piksel eşlemesi farklı Android ekran boyutlarında ve font ölçeklerinde ayrı cihaz ekran görüntüsü testi gerektirir. Kamera arka planı konsept resmidir; kamera görevi gerçek kamerayı kullanır.
