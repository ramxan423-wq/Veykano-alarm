# WakeMission v1.4 — görev kurtarma ve diyalog düzeni

Kaynak: WakeMission v1.3 kamera referans uyumlu kaynak ZIP. Önceki tüm görev kodları ve uygulama renk paletleri korunmuştur.

## Ekran (yalnızca iki pencere)
- **Alarm Düzenle → Görev seç**: yuvarlak beyaz pencere, daha okunaklı yazı, mevcut `ReferenceIconView` simgeleri, uygulamanın mevcut sarı vurgu rengi, seçili görev vurgusu ve kaydırılabilir tam görev listesi. Her görev seçimi eski seçme/kaydetme davranışını sürdürür.
- **Uyku Analizi → Kabus kaydı**: okunaklı başlık/açıklama, yuvarlak giriş alanı, mevcut tema renkleriyle iptal/kaydet düğmeleri. Kabus kayıt yöntemi değişmedi.

## Yürüme görevi
- Donanım adım algılayıcısı varsa kullanır; yoksa kümülatif adım sayacına, o da yoksa ivmeölçer tabanlı yaklaşık yürüyüş ritim algılamasına geçer.
- Android 10+ adım izni reddedilirse ivmeölçer alternatifini sunar.
- Adımlar sayılmıyorsa alternatif algılamaya elle geçiş düğmesi sunar.
- İlk tekil sarsıntıyı adım kabul etmez. İvmeölçer sayımı **tahminidir**, özel donanım adım algılayıcısı kadar kesin olmayabilir.

## Fotoğraf görevi
- Kamera ekranı kilit ekranındaki alarmdan çağrılınca görünür kalacak şekilde ayarlandı.
- CameraX hazırlık / çekim hataları mesajlandırıldı; sistem kamera uygulaması için alternatif çekim yolu eklendi.
- Fotoğraf cihazda doğrulanır, kaydedilmiş geçici görüntü silinir; görevi fotoğraf çekmeden otomatik geçme yolu eklenmedi.
- Yerel ML Kit etiketlerinde bazı yaygın eş anlamlılar tanınır; başarısızlıklar anlaşılır geri bildirim verir.

## Doğrulama
- `tests/TaskRecoveryTest.java` JVM testleri çalıştırıldı ve geçti (fotoğraf etiket eşleştirme + ivmeölçer örnek akışı).
- Bu çalışma ortamında Android SDK/Gradle bağımlılıkları ve gerçek telefon kamerası bulunmadığından APK derlemesi ve telefonda kamera/sensör uçtan uca testi **yapılmadı**.
- **APK oluşturulmadı**; test için Android Studio'da derlenmesi ve telefonda yürüme/fotoğraf görevlerinin denenmesi gerekir.
