import com.wakemission.alarm.WalkingMotionCounter;
import com.wakemission.alarm.PhotoLabelMatcher;

public final class TaskRecoveryTest {
    private static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);}
    public static void main(String[] args){
        check(PhotoLabelMatcher.matches("SKY","Blue sky"),"sky synonym");
        check(PhotoLabelMatcher.matches("PET","Cute domestic cat"),"pet phrase");
        check(PhotoLabelMatcher.matches("CUP","Coffee cup"),"coffee cup");
        check(PhotoLabelMatcher.matches("BOOK","Bookcase") == false,"avoid unrelated substring");
        check(PhotoLabelMatcher.matches("BED","Pillow"),"bedding synonym");
        check(!PhotoLabelMatcher.matches("CHAIR","Bottle"),"reject wrong target");
        check(!PhotoLabelMatcher.matches("DOG","Dog"),"reject unsupported target");
        WalkingMotionCounter counter=new WalkingMotionCounter();
        long time=1_000_000_000L;
        int total=0;
        for(int i=0;i<80;i++)total+=counter.onSample(time+i*20_000_000L,0,0,9.81f);
        check(total==0,"static phone must not count");
        // A single isolated impulse should not count as a step.
        total+=counter.onSample(time+2_000_000_000L,0,0,14.5f);
        for(int i=0;i<30;i++)total+=counter.onSample(time+2_050_000_000L+i*20_000_000L,0,0,9.81f);
        check(total==0,"single impulse must not count");
        // Regular walking pulses should count after the first confirmed pair.
        long start=time+4_000_000_000L;
        for(int step=0;step<15;step++){
            long t=start+step*580_000_000L;
            for(int k=0;k<20;k++)total+=counter.onSample(t+k*20_000_000L,0,0,k==2?13.7f:9.81f);
        }
        check(total>=10,"normal cadence should be counted: "+total);
        counter.reset();
        check(counter.onSample(start,0,0,9.81f)==0,"reset shouldn't increment");
        System.out.println("PASS: Photo matching and walking sensor fallback");
    }
}
