import com.wakemission.alarm.AlarmTimeLogic;
import java.util.*;
public final class AlarmTimeLogicTest {
    static TimeZone zone=TimeZone.getTimeZone("Europe/Istanbul");
    static long time(int y,int month,int d,int h,int m){
        Calendar c=Calendar.getInstance(zone);c.clear();c.set(y,month-1,d,h,m,0);return c.getTimeInMillis();
    }
    static int tests=0;
    static void expect(String label,long expected,long actual){tests++;
        if(expected!=actual)throw new AssertionError(label+": expected "+new Date(expected)+", got "+new Date(actual));
    }
    public static void main(String[]args){
        // Oct 17 2026 is Saturday; next Sunday = Oct 18.
        expect("single next day",time(2026,10,18,7,0),AlarmTimeLogic.nextTriggerMillis(7,0,0,time(2026,10,17,9,0),zone));
        expect("single same day",time(2026,10,17,20,30),AlarmTimeLogic.nextTriggerMillis(20,30,0,time(2026,10,17,9,0),zone));
        expect("Sunday repeat",time(2026,10,18,8,0),AlarmTimeLogic.nextTriggerMillis(8,0,1<<0,time(2026,10,17,9,0),zone));
        expect("Monday repeat",time(2026,10,19,7,30),AlarmTimeLogic.nextTriggerMillis(7,30,1<<1,time(2026,10,17,9,0),zone));
        expect("Saturday repeat next week",time(2026,10,24,7,0),AlarmTimeLogic.nextTriggerMillis(7,0,1<<6,time(2026,10,17,9,0),zone));
        expect("Sunday and Monday",time(2026,10,18,7,0),AlarmTimeLogic.nextTriggerMillis(7,0,(1<<0)|(1<<1),time(2026,10,17,9,0),zone));
        expect("minute boundary",time(2026,10,18,7,0),AlarmTimeLogic.nextTriggerMillis(7,0,0,time(2026,10,17,7,0),zone));
        try{AlarmTimeLogic.nextTriggerMillis(25,0,0,0,zone);throw new AssertionError("Invalid time accepted");}
        catch(IllegalArgumentException good){tests++;}
        // Property checks: every computed time must be future and match requested day.
        for(String tz : new String[]{"Europe/Istanbul","America/New_York","Asia/Kolkata","Pacific/Auckland"}){
            TimeZone z=TimeZone.getTimeZone(tz);
            for(int day=1;day<=28;day++)for(int h=0;h<24;h+=3)for(int mask=0;mask<128;mask+=7){
                Calendar nowCal=Calendar.getInstance(z);nowCal.clear();
                nowCal.set(2026,Calendar.OCTOBER,day,h,47,0);
                long now=nowCal.getTimeInMillis();
                long next=AlarmTimeLogic.nextTriggerMillis(7,15,mask,now,z);
                if(next<=now || next-now>8L*24*60*60*1000)throw new AssertionError("future bound "+tz+"/"+mask);
                Calendar out=Calendar.getInstance(z);out.setTimeInMillis(next);
                if(out.get(Calendar.HOUR_OF_DAY)!=7 || out.get(Calendar.MINUTE)!=15)
                    throw new AssertionError("clock time "+tz+"/"+mask);
                if(mask!=0 && (mask&(1<<(out.get(Calendar.DAY_OF_WEEK)-1)))==0)
                    throw new AssertionError("day match "+tz+"/"+mask);
                tests++;
            }
        }
        System.out.println("PASS " + tests + " alarm time checks");
    }
}
