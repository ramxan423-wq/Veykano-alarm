import com.wakemission.alarm.ToneComposer;
import com.wakemission.alarm.ObjectHunt;
import com.wakemission.alarm.SceneSimilarity;
import java.io.File;
import java.nio.file.Files;
import java.util.Random;

public final class NewFeaturesTest {
    private static int checks=0;
    private static void check(boolean condition,String msg){checks++;if(!condition)throw new AssertionError(msg);}
    public static void main(String[] args)throws Exception{
        byte[] a=new byte[256],b=new byte[256],c=new byte[256];
        java.util.Arrays.fill(c,(byte)255);
        check(SceneSimilarity.score(a,b,256)==1,"same image should match");
        check(SceneSimilarity.score(a,c,256)==0,"opposite images should not match");
        check(SceneSimilarity.score(a,new byte[5],256)==0,"wrong length must fail");
        b[0]=(byte)255;
        check(SceneSimilarity.score(a,b,256)<1,"changed pixels should change score");
        check(SceneSimilarity.score(a,b,256)>0.9,"single pixel should not dominate scene");
        check(SceneSimilarity.score(null,c,256)==0,"null reference must fail");
        Random r=new Random(129);
        String previous="SKY";
        for(int i=0;i<20000;i++){
            String next=ObjectHunt.next(r,previous);
            check(!next.equals(previous),"target repeated");
            check(java.util.Arrays.asList("SKY","BOOK","CUP","PET","SHOE","BOTTLE","CHAIR").contains(next),"unexpected target");
            previous=next;
        }
        File folder=Files.createTempDirectory("wakemission_test").toFile();
        String[] moods={"soft","strong","classic"};
        byte[][] wav=new byte[3][];
        for(int i=0;i<moods.length;i++){
            File file=new File(folder,moods[i]+".wav");
            ToneComposer.write(file,moods[i]);wav[i]=Files.readAllBytes(file.toPath());
            check(wav[i].length==44+8*16000*2,"WAV length wrong");
            check(new String(wav[i],0,4).equals("RIFF"),"missing RIFF");
            check(new String(wav[i],8,4).equals("WAVE"),"missing WAVE");
            int nonZero=0;for(int s=44;s<wav[i].length;s++)if(wav[i][s]!=0)nonZero++;
            check(nonZero>10000,"melody silent");
            file.delete();
        }
        check(!java.util.Arrays.equals(wav[0],wav[1]),"styles must differ");
        check(!java.util.Arrays.equals(wav[1],wav[2]),"styles must differ");
        folder.delete();
        System.out.println("PASS: "+checks+" additional deterministic checks");
    }
}
