package com.wakemission.alarm;
public class TestWakeMissionV17 {
  static void eq(boolean ok, String desc){if(!ok)throw new RuntimeException("FAILED: "+desc);System.out.println("PASS "+desc);}
  static void repeat(SitupCounter c,long start){
    c.addAngle(155,start); c.addAngle(151,start+100);
    c.addAngle(90,start+320); c.addAngle(96,start+410);
    c.addAngle(155,start+750);c.addAngle(157,start+860);
  }
  public static void main(String[] args){
    SitupCounter c=new SitupCounter();
    repeat(c,1000);eq(c.count()==1,"one complete situp");
    repeat(c,3000);eq(c.count()==2,"two complete situps");
    c.addAngle(152,5000);c.addAngle(153,5100);c.addAngle(94,5300);
    c.interrupt();c.addAngle(95,5400);c.addAngle(157,6000);eq(c.count()==2,"pause cannot count unfinished situp");
    c.reset();eq(c.count()==0,"reset clears count");
    repeat(c,1000);eq(c.count()==1,"counter works after reset");
    eq(CalorieEstimate.estimate(0,70,"SITUP")==0,"zero reps zero calories");
    double a=CalorieEstimate.estimate(10,70,"SITUP");
    eq(a>0.5&&a<10,"10 situps estimated kcal sensible");
    eq(CalorieEstimate.estimate(10,90,"SITUP")>a,"heavier weight raises estimate");
    eq(CalorieEstimate.estimate(20,70,"SITUP")>a,"more reps raises estimate");
    eq(CalorieEstimate.safeGoal(99)==2 && CalorieEstimate.safeGoal(3)==3,"calorie goals bounded");
    eq(CalorieEstimate.safeWeight(400)==70&&CalorieEstimate.safeWeight(80)==80,"weight input bounded");
    eq("SITUP".equals(CalorieEstimate.safeActivity(null)),"bad exercise defaults safely");
  }
}
