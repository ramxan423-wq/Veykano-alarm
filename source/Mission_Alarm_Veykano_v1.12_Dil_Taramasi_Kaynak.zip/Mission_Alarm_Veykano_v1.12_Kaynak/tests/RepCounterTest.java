import com.wakemission.alarm.RepCounter;
public class RepCounterTest {
    static void check(boolean valid,String name){if(!valid)throw new AssertionError(name);}
    public static void main(String[] args){
        RepCounter push=new RepCounter(false);
        long at=1000;
        push.addAngle(170,at);push.addAngle(168,at+40);
        check(push.addAngle(90,at+100)==0,"single down not counted");
        check(push.addAngle(90,at+300)==0,"down must not count");
        check(push.addAngle(170,at+600)==0,"single up not counted");
        check(push.addAngle(170,at+700)==1,"full rep 1");
        check(push.addAngle(170,at+750)==1,"no double rep without down");
        push.addAngle(80,at+1100);push.addAngle(75,at+1250);
        push.addAngle(170,at+1700);
        check(push.addAngle(169,at+1750)==2,"full rep 2");
        push.addAngle(Double.NaN,at+1900);
        push.addAngle(15,at+1940);
        check(push.count()==2,"invalid angles cannot count");
        RepCounter squat=new RepCounter(true);
        squat.addAngle(175,0);squat.addAngle(80,100);squat.addAngle(80,200);
        squat.addAngle(175,500);check(squat.addAngle(175,600)==1,"squat counted");
        squat.reset();check(squat.count()==0,"reset zero");
        RepCounter paused=new RepCounter(false);
        paused.addAngle(165,1000);paused.addAngle(70,1200);paused.addAngle(70,1240);
        paused.interrupt();
        paused.addAngle(170,1600);paused.addAngle(170,1680);
        check(paused.count()==0,"resume must not count incomplete repetition");
        paused.addAngle(170,1800);paused.addAngle(70,1870);paused.addAngle(70,1950);
        paused.addAngle(170,2300);
        check(paused.addAngle(170,2400)==1,"resume counts a complete new repetition");
        paused.interrupt();check(paused.count()==1,"interrupt preserves completed repetitions");
        System.out.println("RepCounter checks passed (14 assertions)");
    }

}
