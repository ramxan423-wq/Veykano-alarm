"""Source-only regression check for the requested settings cleanup."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
source=(root/'app/src/main/java/com/wakemission/alarm/MainActivity.java').read_text(encoding='utf-8')
settings=source.split('    private void showSettings(){',1)[1].split('    private void sectionCard(',1)[0]
removed=('Kişiselleştirme','Ücretsiz özellikler','Yeni kamera ve ses görevleri','Premium durumu')
preserved=('🎨 Tema','Uyku Kayıtları','Alarm ve bildirim izinleri','App language','Telefon uygunluk kontrolü','Gizlilik','Pro seçeneklerini incele')
for label in removed: assert label not in settings, f'Settings still shows {label}'
for label in preserved: assert label in settings, f'Settings missing required item: {label}'
for role in ('missions','sleep'):
    assert f'section="{role}"' in source, f'Navigation to {role} was removed'
assert (root/'app/src/main/java/com/wakemission/alarm/CameraExerciseActivity.java').exists()
assert (root/'app/src/main/java/com/wakemission/alarm/PhotoChallengeActivity.java').exists()
print('PASS: settings cleanup, retained navigation and camera modules')
