import com.wakemission.alarm.SleepSoundClassifier;
import java.util.*;
public class TestClassifier {
    static ArrayList<short[]> signal(int mode) {
        Random r = new Random(22);
        ArrayList<short[]> chunks = new ArrayList<>();
        for(int frame=0; frame<80; frame++) {
            short[] a = new short[1600];
            boolean burst = mode==1 ? (frame>=10&&frame<18 || frame>=34&&frame<45 || frame>=60&&frame<70)
                : mode==2 ? (frame>=20&&frame<23 || frame>=55&&frame<58) : false;
            for(int i=0;i<1600;i++) {
                double sample=burst ? mode==1 ? 5000*Math.sin(2*Math.PI*110*(frame*1600+i)/16000.0)
                    : 9000*(r.nextDouble()*2-1) : 60*(r.nextDouble()*2-1);
                a[i]=(short)sample;
            }
            chunks.add(a);
        }
        return chunks;
    }
    public static void main(String[] args){
        String quiet=SleepSoundClassifier.classify(signal(0));
        String snore=SleepSoundClassifier.classify(signal(1));
        String cough=SleepSoundClassifier.classify(signal(2));
        System.out.println("quiet="+quiet+" | snore="+snore+" | cough="+cough);
        if(!quiet.equals("Diğer ses")||!snore.equals("Olası horlama")||!cough.equals("Olası öksürük")) throw new AssertionError("unexpected classifier label");
    }
}
