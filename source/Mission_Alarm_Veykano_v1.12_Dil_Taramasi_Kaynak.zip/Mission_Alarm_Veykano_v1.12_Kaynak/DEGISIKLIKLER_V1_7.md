# WakeMission v1.7 – Mekik ve Kalori Modu

- Alarm görevlerine Kamerayla Mekik (5, 10, 15, 20 tekrar) ve Kalori Modu eklendi.
- Mekik: kameranın yandan görmesi gerekir; cihaz içi ML Kit ile omuz-kalça-diz açısı ve diz bükülmesi kullanılır. Yatış/doğrulma/tekrar yatış döngüsü 2 kare ve zaman filtreleriyle sayılır. Tüm egzersizler için Güvenli durdur korunur.
- Kalori Modu: mekik, squat veya şınav seçilir; 1/2/3 kcal *tahmini* hedef, 30-250 kg ağırlık girilebilir. Cihazdaki kamera tekrarları sayar; MET ve varsayımsal hareket süresi ile kabaca kalori hesaplar. Egzersizde yakılan gerçek kaloriyi doğrudan ölçmez.
- Yeni alanlar alarm başına yerel JSON ile saklanır. Varsayılan mekik=10; kalori hedefi=2 kcal, ağırlık=70 kg, egzersiz=mekik.
- Mevcut görevler, uyku ses analizi, onaylanan modern görev penceresi, kamera işaretleri ve sarı-beyaz tema korunur.
- APK/AAB hazırlanmadı. Android SDK/gerçek telefon üzerinde kamera, alarm, poz ve hesap testleri gereklidir.
