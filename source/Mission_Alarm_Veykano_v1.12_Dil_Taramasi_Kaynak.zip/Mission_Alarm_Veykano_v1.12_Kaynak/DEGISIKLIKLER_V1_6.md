# WakeMission v1.6 — Yoga Modu

- Yeni alarm görevi: **Yoga Modu (YOGA)**. Mevcut görevler, bed referansı ve uyku ses analizi korunur.
- Üç poz: **Kollar Yukarı** (varsayılan), **Dağ Duruşu**, **Savaşçı II**; 10/20/30 saniye kesintisiz duruş seçimi. Yoga poz ve süre tercihleri alarm başına yerel JSON ile saklanır.
- CameraX + ML Kit Pose ile cihaz içinde 2D omuz/dirsek/bilek/kalça/diz/ayak işaretleri izlenir. Görüntü upload edilmez, fotoğraf kaydedilmez.
- Pozda kesinti, kamera görüşünün kaybı, duraklatma veya etkinliğin arka plana geçmesi süreyi sıfırlar.
- Mevcut kamera ekranının sarı ilerleme çubuğu, buton, kamera markerları ve tema korunur. Yoga için özel vector icon eklendi, var olan ikonlar değişmedi.
- Alarmlar güvenli biçimde durdurulabilir; sensör yanılırsa veya egzersiz zor gelirse Güvenli durdur işlevi korunur. Yoga algılaması 2D yaklaşık kontroldür, kusursuz poz veya fiziksel güvenlik doğrulaması değildir.
- **APK oluşturulmadı.** Android Studio / gerçek cihazda kamera izin, alarm bitiş, farklı pozlar, ekranın döndürülmesi ve düşük ışık testleri gereklidir.
