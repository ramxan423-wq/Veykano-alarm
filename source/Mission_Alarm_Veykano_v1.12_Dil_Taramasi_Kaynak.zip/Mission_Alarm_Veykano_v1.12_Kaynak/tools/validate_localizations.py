#!/usr/bin/env python3
"""Strictly detect missing Veykano offline translations; never mislabel fallback as translated."""
from pathlib import Path
import csv, json, argparse, re, sys, collections
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'app/src/main/java/com/wakemission/alarm'
ASSETS=ROOT/'app/src/main/assets'
CAT=(SRC/'LanguageCatalog.java').read_text()
assert (match:=re.search(r'CODES=\{(.*?)\};',CAT,re.S)), 'Missing language catalog'
CODES=re.findall(r'"([^"]+)"',match.group(1))
assert len(CODES)>=100 and len(CODES)==len(set(CODES)), 'Expected >=100 unique language codes'
en=json.loads((ASSETS/'translations_en.json').read_text(encoding='utf-8'))
assert all(isinstance(k,str) and isinstance(v,str) and v.strip() for k,v in en.items()),'English dictionary invalid'
results=[]
for tag in CODES:
    fname=ASSETS/f'translations_{tag}.json'
    base=ASSETS/f'translations_{tag.split("-")[0]}.json' if '-' in tag else None
    path=fname if fname.exists() else base if base and base.exists() else None
    data=json.loads(path.read_text(encoding='utf-8')) if path else {}
    assert all(isinstance(k,str) and isinstance(v,str) for k,v in data.items()),f'Invalid dictionary values: {tag}'
    missing=[key for key in en if key not in data or not data[key].strip()]
    if tag=='en' or tag.startswith('en-'):
        full=True
        missing=[]
    else:
        full=len(missing)==0
    results.append({'locale':tag,'entries':len(data),'required_entries':len(en),'missing':len(missing),'complete_by_keys':full,'source':path.name if path else None,'sample_missing':missing[:3]})
print('Mission Alarm Veykano: localization audit')
print('Language choices:',len(CODES))
print('English dictionary keys:',len(en))
print('Dictionaries on disk:',len(list(ASSETS.glob('translations_*.json'))))
print('Key-complete locales (not language quality certification):',sum(r['complete_by_keys'] for r in results),'/',len(CODES))
print('Selected examples:',*[(r['locale'],r['entries'],r['missing']) for r in results[:17]],sep='\n')
(ROOT/'LOCALIZATION_VALIDATION.json').write_text(json.dumps(results,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
with (ROOT/'LOCALIZATION_COVERAGE.csv').open('w',newline='',encoding='utf-8') as f:
    wr=csv.writer(f);wr.writerow(['locale','dictionary_source','entry_count','english_key_count','missing_keys','keys_complete','translation_quality_reviewed'])
    for r in results:wr.writerow([r['locale'],r['source'] or '',r['entries'],r['required_entries'],r['missing'],str(r['complete_by_keys']).lower(),'not verified'])
# Catch source string literals still missing in English dictionary; these need human review.
phrases={}
for path in SRC.glob('*.java'):
    for n,line in enumerate(path.read_text().splitlines(),1):
        for m in re.finditer(r'"((?:\\.|[^"\\])*)"',line):
            val=m.group(1)
            if re.search('[İıŞşĞğÇçÖöÜü]',val) and val not in en and len(val)>=3 and not re.search('com\\.|[A-Z_]{7}',val):
                phrases.setdefault(val,[]).append(f'{path.name}:{n}')
with (ROOT/'REMAINING_TURKISH_STRINGS.csv').open('w',newline='',encoding='utf-8') as f:
    wr=csv.writer(f);wr.writerow(['string','locations','possibly_non_ui']);
    for k,refs in sorted(phrases.items()):
        wr.writerow([k,'; '.join(refs),'requires developer review'])
print('Turkish-source literal candidates still untranslated:',len(phrases))
if '--strict' in sys.argv and not all(x['complete_by_keys'] for x in results):
    print('FAIL: Do not publish as fully translated until all dictionaries and review are complete.',file=sys.stderr)
    sys.exit(2)
