#!/usr/bin/env python3
"""Measure a real app screenshot against a cropped panel of the user reference.

Example:
  python tools/compare_reference.py --actual phone.png --reference-rect 976,22,1264,625 --actual-rect 0,0,720,1520

Rects are left,top,right,bottom coordinates. The reference collage includes
phone framing; specify the interior screen bounds for real comparisons.
"""
import argparse
from pathlib import Path
from PIL import Image, ImageChops, ImageEnhance, ImageStat

def bounds(text):
    rect=tuple(int(v.strip()) for v in text.split(','))
    if len(rect)!=4 or rect[2]<=rect[0] or rect[3]<=rect[1]:
        raise argparse.ArgumentTypeError('rectangle must be x1,y1,x2,y2')
    return rect

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--reference',default=str(Path(__file__).resolve().parent.parent/'design/WakeMission_kullanici_referansi.png'))
p.add_argument('--actual',required=True)
p.add_argument('--reference-rect',type=bounds,required=True)
p.add_argument('--actual-rect',type=bounds)
p.add_argument('--out',default='visual_diff.png')
a=p.parse_args()
ref=Image.open(a.reference).convert('RGB').crop(a.reference_rect)
real=Image.open(a.actual).convert('RGB')
if a.actual_rect:real=real.crop(a.actual_rect)
real=real.resize(ref.size,Image.Resampling.LANCZOS)
diff=ImageChops.difference(ref,real)
stats=ImageStat.Stat(diff)
mae=sum(stats.mean)/3
print(f'Comparison size: {ref.width}x{ref.height}')
print(f'Mean absolute difference (0 exact, 255 different): {mae:.3f}')
print(f'Exact image match: {diff.getbbox() is None}')
ImageEnhance.Contrast(diff).enhance(3).save(a.out)
print(f'Difference image: {a.out}')
