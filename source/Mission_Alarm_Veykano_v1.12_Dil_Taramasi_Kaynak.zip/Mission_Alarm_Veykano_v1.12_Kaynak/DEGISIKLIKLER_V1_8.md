# WakeMission v1.8 – Kamera Fotoğraf / Kilit Ekranı Düzeltmeleri

- **Fotoğraf görevi:** Sistem kamerası yedeği artık Android FileProvider üzerinden tam çözünürlüklü geçici dosyaya fotoğraf çeker. Bazı cihazların düşük kaliteli küçük önizlemesi yerine tam kare doğrulanır. Çekimin iptali, hata veya doğrulama sonrası geçici dosya temizlenir.
- **Fotoğraf yönü:** Hem dahili CameraX hem sistem kamerası fotoğrafı EXIF yönü düzeltilerek ve boyutu kısıtlanarak çözümlenir.
- **Kamera egzersizleri:** Kilit ekranındaki alarmdan şınav, squat, yoga, mekik ve kalori kamerası açıldığında ekran üstte gösterilmeye çalışılır.
- Kamera görselleri sunucuya gönderilmez. Mevcut görevler ve ayarlar korunmuştur.
- Android SDK, emülatör ve gerçek telefonda **uçtan uca derleme ve cihaz doğrulaması yapılmadı**. Sistem kamerasının FileProvider paylaşımını, farklı kamera uygulamalarını ve algılama doğruluğunu gerçek cihazda test etmek gerekir.
- Değişiklikler kaynak koddur; **APK değildir**.
