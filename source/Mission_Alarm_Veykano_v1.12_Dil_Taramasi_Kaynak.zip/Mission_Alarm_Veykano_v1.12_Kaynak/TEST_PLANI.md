# Gerçek Android telefon QA planı

Android 9, 12, 14, 15 ve 16'dan mümkün olan cihazlarda, ayrıca pil kısıtlaması agresif üretici cihazlarında dene.

- [ ] 2 dakika sonra test alarmı, ekran açıkken doğru çalıyor ve sesi duyuluyor.
- [ ] Kilit ekranında tam ekran alarm veya yüksek öncelikli bildirim gösteriliyor.
- [ ] Cihazı yeniden başlatınca tekrarlayan alarm yeniden kuruluyor.
- [ ] Saat dilimi ve yaz/kış saati değişimi doğru ele alınıyor.
- [ ] Kullanıcı bildirim, kamera, mikrofon, hareket, kesin alarm iznini reddederse anlaşılır geri dönüş var.
- [ ] Güvenli durdurma, görev hatasında alarmı gerçekten susturuyor.
- [ ] Şınav ve squat sayısı farklı aydınlatma ve vücut açılarında doğru; sahte hareket sayılmıyor.
- [ ] Fotoğraf nesne avı doğru nesneyi algılıyor; farklı nesneyi kabul etmiyor.
- [ ] Yatak için referans olmadan görev başlayamıyor; yanlış veya loş resimde güvenli yol var.
- [ ] Aynı yatağın farklı durumlarında referans sistemi yanıltıcı sonuç verebilir: gerçek model çıkana kadar bunun sınırlı olduğu belirtiliyor.
- [ ] Üç özel melodi cihazın alarm ses kanalından çalıyor ve farklı ses dosyası seçiliyor.
- [ ] Türkçe, İngilizce ve İspanyolca ekranlarda kesilen/metni çevrilmeyen öğeler tespit ediliyor.
- [ ] Play Billing ürünleri boşken satın alma düğmesi devre dışı; sahte token Pro açmıyor.
- [ ] Kayıtlı alarm, sessiz cihaz modu, pil tasarrufu, düşük pil ve uygulama yeniden açılması altında test ediliyor.

**Not:** Bu test listesi otomatik test sonucu değildir; henüz gerçek cihazda çalıştırılmadı.

## v0.6 — Uyku Kayıtları (gerçek cihazda test edilmelidir)
1. Başarılar yerine Uyku Kayıtları alt sekmesi görünüyor; eski alarmlar/görevler/istatistik çalışıyor.
2. Mikrofon izni reddedilirse kayıt başlamıyor; izin verilince Android'in mikrofon bildirimi görünüyor.
3. Kayıt başlat, telefonu kilitle; mikrofon kaydı bildirimli ön plan hizmeti olarak sürmeli.
4. Kısa gürültü oluştur; ses eşiği aşılırsa en çok 8 saniyelik WAV olayı kaydedilmeli.
5. Olayı dinle; horlama / öksürük / uykuda konuşma etiketle, ekranı kapat-aç; etiket kalmalı.
6. Kabus notu ekle; kayıtlarda saat ve not görünmeli (mikrofondan otomatik kabus analizi yok).
7. Bildirimden kaydı durdur; mikrofon kapanmalı. Kaydı silince WAV dosyası da silinmeli.
8. Çok sessiz odada yanlış pozitif ve gürültülü odada sahte tetiklemeler açısından kontrol et;
   sistem ses algılama yapar, otomatik horlama/öksürük tanıması yapmaz.
9. Android 8/9, 12, 14+ modellerde izinler ve pil optimizasyonlarını test et.
10. Uygulama zorla sonlandırıldıktan sonra eski oturum "kesildi" durumuna alınır; yeni kayıt açılabilir.


## v0.7 — Beyaz/Bordo Yeni Alarm regresyon kontrolü

1. Yeni alarm sayfasına gir: beyaz/bordo kartlar ve küçük saat alanı açılmalı,
   analog saatin büyük yuvarlak görünümü olmamalı. Saate dokunup 06:45 seç.
2. Pazartesi ve Cuma işaretle, kaydet. Alarmı tekrar açınca doğru günleri ve
   saat bilgisini göstermeli. Pazar bit-0 eşlemesi bozulmamalı.
3. Her 11 görev türünü (kamera şınav/squat dahil) seçilebilir kontrol et.
4. QR barkod okuma ve yatak referans kamerası açılmalı. Fotoğraf hedefi seçilmeli.
5. Görev sayısı/zorluk, erteleme süre/hakkı seçimleri kaydedilip tekrar açıldığında
   kalmalı; titreşim ve kademeli ses anahtarlarının durumu korunmalı.
6. Sesli görev cümlesini, kişisel alarm mesajını değiştir, yeniden açıp doğrula.
7. Alarm melodisini seç, özel melodi oluştur ve kaydet; alarm çalarken test et.
8. Alarmı kaydet sabit alt düğmesi, sağ üst onay ve alarmı sil işlevini test et.
9. Önceki Uyku Kayıtları ve diğer alarm/görev sayfalarının çalıştığını doğrula.
10. Android 9 / Android 13+ cihazlarda 7 gün kapsülünün sığdığını,
    ekran klavyesinin kaydet düğmesini kapatmadığını kontrol et.
