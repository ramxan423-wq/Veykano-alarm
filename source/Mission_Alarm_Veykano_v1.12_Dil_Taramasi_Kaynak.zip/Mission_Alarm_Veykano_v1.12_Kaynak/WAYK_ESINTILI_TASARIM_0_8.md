# WakeMission v0.8 - Sabah Işığı tasarım uyarlaması

Wayk (Dialed Labs Inc.) arayüz organizasyonu incelenerek **özgün kod ve görsellerle** yeniden düzenlendi. Wayk logosu, ikon seti, özel grafikleri ve birebir telifli görselleri kullanılmamıştır.

- Yeni varsayılan Sabah Işığı teması: kırık beyaz, yumuşak yüzeyler, amber vurgu, koyu metin, kapsül menü.
- Bugün: haftalık tamamlanmış uyanma takibi, sonraki alarm, görevler, uyku takip bağlantısı, son uyanış.
- Alt menü: Bugün, Alarmlar, Analizler, Rozetler, Ayarlar.
- Görev Seç: 11 mevcut görev iki sütunlu kartlarda, alarm editörüne görev parametresi gönderilir.
- Giriş: hedef, sabah zorluğu, görev seçimi ve kişisel plan akışı (abonelik zorunluluğu yok).
- Analiz ve rozet ekranları ayrı, mevcut geçmiş verilerini okur.
- Uyku kayıtları, kabus notları, şınav ve squat kamera görevleri, QR, matematik, fotoğraf ve diğerleri korunur.
- Kullanıcının önceki Beyaz Bordo tercihi ve eski Modern Beyaz/Klasik/Neon/Uzay temaları korunur.
- Android gerçek cihazda kamera, arka plan alarmı, bildirim ve uyku sesi kayıtları ayrıca test edilmelidir.
