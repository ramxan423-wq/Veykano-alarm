# Mission Alarm Veykano 1.11 – Introduction and language selection

1. On first launch, choose the app language from a searchable catalog of 139 options. Default is English.
2. Three new introduction pages: camera push-ups and photo missions; yoga, sit-ups, squats and calories; sleep recordings with an annotated timeline.
3. Local vector illustrations. Existing four-step alarm configuration flow is preserved.
4. Language picker available again in Settings. Selection is saved across launches.
5. English UI dictionary expanded, intro strings translated for a subset of languages, and 100+ locale architecture built.
6. **Important:** Complete, reviewed translation across 139 languages has NOT been achieved. See LOCALIZATION_STATUS.md and LOCALIZATION_COVERAGE.csv; English fallback remains.
7. No removal of camera, yoga, sit-up, calorie, sleep or other existing features. Official matte green launcher icon preserved.
8. Version code 21 / version name 1.11.0. No APK built.
