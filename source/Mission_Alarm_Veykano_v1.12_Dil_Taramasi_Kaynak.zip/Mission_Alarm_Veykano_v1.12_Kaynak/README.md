> **v1.4 (18 Ekim 2026):** Görev seç/Kabus kaydı diyaloglarının modern, sarı-beyaz temayı koruyan yazı ve düzeni; yürüme sensör alternatifleri; kamera görevinde sistem kamera yedeği ve fotoğraf etiket eşleştirmesi. Ayrıntılar için `SURUM_1_4_NOTLARI.md`. Bu paket kaynak koddur, APK değildir.

# WakeMission v1.2 — Referans Uyum Kaynak Projesi

Ayrıntılar: `design/PIKSEL_UYUM_V1_2.md`. 8 ekranlı referans `design/WakeMission_kullanici_referansi.png`.

Bu proje bir **Android Studio kaynak ZIP** paketidir; APK/AAB değildir. Mevcut alarm, görev, uyku, tema ve istatistik özellikleri korunmuştur.

**Testler:** 14 şınav tekrar sayacı, 17.032 alarm zaman mantığı ve 40.020 deterministik yardımcı test geçti. Android cihazda ekran/poz testi ve Gradle derlemesi bu çalışma ortamında doğrulanmadı.

---

# WakeMission Android v0.7 — Beyaz/Bordo Yeni Alarm ekranı

**Önceki v0.6 kaynak kodu üzerine uygulanmıştır.** Kullanıcının onayladığı beyaz–bordo
Yeni Alarm tasarımı `AlarmEditorActivity.java` içinde gerçek Android UI bileşenleriyle
uygulandı. Önceki ana sayfanın, uyku kayıtlarının, kamera şınav/squat görevlerinin,
alarmların ve diğer özelliklerin kodu korunmuştur.

**Başlıca UI değişiklikleri:** Büyük analog saat yerine saat kartı + dokununca açılan
24 saatlik saat seçici; pazartesiden pazara yedi kompakt gün kapsülü (depolanan
Pazar=bit 0 eşlemesi korunur); seçeneklerin uzun açılır kutuları yerine etiketli
modern seçim kartları; beyaz yuvarlatılmış alanlar, bordo ikon/aksiyonlar ve sabit
'Alarmı Kaydet' düğmesi. QR/barkod kaydı, fotoğraf hedefi ve yatak referansı,
sesli görev cümlesi, TTS kişisel alarm mesajı, görev sayısı/zorluğu,
erteleme süresi/hakkı, titreşim, kademeli ses, sistem alarm sesi ve cihazda
sentezlenen üç melodi eksiksiz erişilebilir durumdadır.

**Tema kapsamı:** Beyaz–bordo palet yalnızca Yeni Alarm/Alarmı Düzenle sayfasına
uygulanır; uygulamanın diğer tema seçenekleri değişmez.

**Test durumu:** Mevcut bağımsız Java mantık testleri çalıştırıldı ve geçti.
Android SDK bu çalışma ortamında bulunmadığından Gradle APK/AAB derlemesi veya
Huawei/başka Android telefonda görsel ve işlev testi yapılamadı. Kaynak ZIP,
kurulabilir bir APK değildir. Özellikle alarm kurma/silme, saat seçme, her gün
seçimi ve ses seçiciyi gerçek cihazda sınamak gerekir.

---

# WakeMission Android v0.5 — kaynak kod

**Yeni v0.5 görsel güncellemesi:** Modern Beyaz varsayılan görünüm; hafif gri, yuvarlatılmış ve yarı saydam alt gezinme kapsülü; yeni büyük dairesel alarm alanı, mavi yumuşak geçişli butonlar ve açık renkli kartlar. Ayarlar > Tema altında Modern Beyaz, Klasik, Neon, Uzay seçenekleri kaydedilir ve tüm Activity ekranlarında kullanılır. Görevler/Başarılar ayrı alt menü sayfalarıdır. Var olan v0.4 işlevleri korunmuştur.

**Durum:** Android Studio kaynak projesi. APK/AAB değil. Bu ortamda Android SDK bulunmadığı için Android Gradle derlemesi ve gerçek telefon üzerinde test yapılmadı. v0.3'ün üzerine değişiklik yapıldı; önceki alarmlar, görevler ve güvenli durdurma korundu.

## Bu sürümde eklenenler

1. **Rastgele nesne avı:** Gökyüzü, kitap, bardak, evcil hayvan, ayakkabı, şişe ve sandalye görevleri; zincirde ardışık tekrar önlenir. Görüntü ML Kit'in cihaz içi etiketleyicisinde aranır. Bu etiketler her cihaz/ışıkta doğru sonuç vermez.
2. **Toplu yatak referansı:** Alarm ayarlarında yatak topluyken bir örnek fotoğraf çek. Fotoğraf dosyası kaydedilmez; düşük çözünürlüklü görsel özellikleri cihazda saklanır. Sonraki sabah aynı açıdan fotoğraf çekince görsel benzerlik karşılaştırılır. **Bu çözüm, yatağın gerçekten toplandığını sınıflandıran eğitimli bir model değildir.** Kullanıcı aynı açı/ışıkta çekmeli. Uygulamanın gerçek semantik doğrulama yapabilmesi için eğitim verisi ve yeni ML modeli gerekir.
3. **Özel alarm melodisi:** Uygulama içinde üç farklı melodi (yumuşak / enerjik / klasik), internet veya telifli dosya gerektirmeden WAV dosyasına sentezlenir. Daha önceki metinden konuşma (TTS) alarm mesajı korunur. **Bu, generatif yapay zekâ ile ses üretimi veya ses klonlama değildir.**
4. **Arayüz dili seçimi:** Cihaz dili / Türkçe / English / Español. İngilizce ana ekran ve temel alarm ayarlarında 160+ arayüz cümlesi çevrildi, İspanyolcada temel ~45 cümle. Gelişmiş hata mesajları ve bazı birleşik metinler henüz tamamıyla çevrilmiş değil. Tanılama ekranındaki bazı açıklamalar Türkçe. Mağazaya çıkmadan önce tam dil QA gerekir.
5. **Pro satın alma güvenliği:** Google Play Billing ürün bağlantısı korunmuştur ancak ödeme düğmesi kapalıdır (`PAYMENTS_ENABLED=false`). Doğrulanmamış satın alma tokenları artık client tarafından **acknowledge** edilmez ve Pro erişimi açmaz. Üretim için kimlik doğrulamalı backend, Play Developer API `purchases.subscriptionsv2.get`, satın alma durumu/ürün eşleştirme, RTDN, entitlement depolama ve onaylama gereklidir. Kullanıcıdan ödeme alınmaz.
6. **Telefon uygunluk kontrolü:** Ayarlardan cihazda kesin alarm, tam ekran intent, bildirim, ses seviyesi, pil kısıtları, kamera, adım sensörü, ivmeölçer ve konuşma tanıma desteği görülebilir. Bu bir *ön kontrol*; gerçek uyandırma testinin yerine geçmez.
7. **Regresyon testleri:** Alarm zamanı, şınav sayacı, WAV dosyası, rastgele nesne seçimi ve görsel benzerlik hesapları.

## Korunanlar

Tek / tekrarlayan alarmlar; `setAlarmClock()`; titreşim / erteleme; kişisel ses; matematik, hafıza, yazma, sallama, adım, QR/barkod, şınav ve squat; CameraX, ML Kit poz tespiti ve genel nesne tanıma; sesli cümle; ilk açılış; başarı geçmişi, rozetler, haftalık grafik; manuel uyku günlüğü; acil güvenli durdurma.

## APK geliştirme

- Android Studio'da bu klasörü aç: Java 17, Gradle 8.14.1, Android Gradle Plugin 8.13.0, Android SDK 36.
- `./gradlew :app:assembleDebug` (Android SDK ve internet/önbellek bağımlılıkları gerekir).
- `.github/workflows/build-debug-apk.yml`: GitHub Actions'ta yalnızca **elle çalıştırılan** debug APK derlemesi. Otomatik olarak mağazaya yüklemez.
- Test komutu:
  ```sh
  mkdir -p tests/build
  javac -encoding UTF-8 -d tests/build app/src/main/java/com/wakemission/alarm/{RepCounter,AlarmTimeLogic,SceneSimilarity,ObjectHunt,ToneComposer}.java tests/{RepCounterTest,AlarmTimeLogicTest,NewFeaturesTest}.java
  java -cp tests/build RepCounterTest
  java -cp tests/build AlarmTimeLogicTest
  java -cp tests/build NewFeaturesTest
  ```

## Gerçek cihaz testi zorunluluğu

`TEST_PLANI.md` dosyasındaki adımları gerçek Android cihazlarda denemeden Google Play yayınına çıkma. Özellikle düşük ışıkta şınav sayımı, geri dönüşte alarmın kapanması, uygulama öldürülmesi, yeniden başlatma, farklı Android sürümleri ve fotoğraf doğrulama yanlış pozitif/negatif durumları test edilmelidir.

## Hâlâ eksik / haricî bağımlılık isteyenler

- Toplu/dağınık yatağı **gerçekten** ayıran eğitimli sınıflandırma modeli ve cihaz testleri.
- Prompta dayalı generatif **AI** ses modeli/servisi; mevcut melodi üretimi bunun yerine geçmez.
- Google Play ürünleri ve güvenli backend doğrulaması ile canlı Pro abonelik aktivasyonu.
- Tam İngilizce/İspanyolca yerelleştirme, erişilebilirlik ve diğer diller.
- Android SDK ile doğrulanmış APK ve çeşitli fiziksel cihaz testleri.

**Gizlilik:** Fotoğraf görevi için çekilen kareler uygulama önbelleğinde geçici tutulur, değerlendirmeden sonra silinir. Toplu yatak referansı fotoğrafı kaydedilmez; görsel özet yerel Preferences'ta tutulur. Kullanıcının kamera ve mikrofon izinleri Android tarafından yönetilir. Bildirim ve alarm izinleri kullanıcı tarafından verilir. Konuşma tanıma motoru bazı cihazlarda çevrim içi olabilir.


## 0.6.0 — Uyku Kayıtları
Alt menüde Başarılar yerine **Uyku Kayıtları** bulunur. Önceki başarı puanları İstatistikler
ve alarm başarı ekranında korunur. Kullanıcı mikrofona izin verip **Gece kaydını başlat**
dediğinde `SleepAudioService` bildirimli ön plan hizmeti olarak çalışır; yüksek ses seviyeli
bölümler kısa (yaklaşık 8 saniye) WAV ses kayıtlarına dönüştürülür ve yalnızca uygulamanın
özel depolama alanında saklanır. 80 kayıt/gece sınırı vardır. Kayıt bildirimden veya
uygulamadan durdurulabilir. Olaylar dinlenebilir, horlama / öksürük / konuşma olarak
**kullanıcı tarafından etiketlenebilir**, kayıtlar silinebilir. Kabus notu elle eklenir.
**Önemli:** Akustik eşikleme bir horlama/öksürük veya kabus sınıflandırıcı değildir;
ortam seslerini de algılayabilir. Bu sürüm uyku evresi ya da tanı çıkarmaz.
Önceki manuel uyku günlüğü ve tüm alarm/görev akışları korunmuştur.
APK üretimi ve gerçek telefon testi bu kod paketinde doğrulanmamıştır.

## v1.6 Yoga Modu

Alarm ayarlarında Görev → **Yoga modu** seç, **Yoga Pozu** (Kollar Yukarı, Dağ Duruşu, Savaşçı II) ve **Pozu Koruma Süresi** (10/20/30 saniye) seçerek kaydet. Alarm çalınca kamerayı aç, tüm vücudunu kadraja al ve pozu kesintisiz koru. Kamera algısı kesilince ilerleme sıfırlanır. Kamera görüntüsü saklanmaz. Sensör hatasında alarm ekranındaki **Güvenli durdur** düğmesini kullan. Bu sürümün Yoga takibi yaklaşık 2B geometriye dayanır; fiziksel formu veya güvenliği doğruladığı iddia edilmez. Gerçek cihazla henüz test yapılmadı.


## v1.7 Mekik ve Kalori Modu
Yeni görevler: kamerayla mekik (5, 10, 15, 20 tekrar) ve kamerayla kalori hedefi (1, 2, 3 **tahmini** kcal; mekik, squat veya şınav; kilo seçimi). Ayrıntılar DEGISIKLIKLER_V1_7.md. Gerçek kamerada/cihazda test edilmedi.
