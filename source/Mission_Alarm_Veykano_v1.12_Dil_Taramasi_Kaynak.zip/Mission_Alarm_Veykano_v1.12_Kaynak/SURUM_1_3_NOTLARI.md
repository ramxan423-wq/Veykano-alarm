# WakeMission v1.3 – Kaynak güncellemesi (18 Ekim 2026)

**Temel alınan paket:** `WakeMission_v1.2_Referans_Hassas_Uyum_Android_Kaynak.zip` (ChatGPT dosya arşivi). Google Drive içindeki v1.0 yerine bu sürüm temel alındı; v1.2 kaynak dosyaları korunur.

## Bu turda yapılanlar
- Kamera görevi uygulama ön plandayken ekranı açık tutar.
- Kamera ML Kit görüntü işleme sonlandığında Frame/ImageProxy güvenilir şekilde kapatılır; ekran kapanınca/aktivite durunca kaynakların serbest kalması sağlanır.
- Şınav/squat yarıda kesilip kameradan çıkılırsa yarım hareketin devam sayılmasına karşı sayaç durumunu sıfırlama; tamamlanmış tekrarlar korunur.
- Kısa süreli iskelet kaybında eksik hareket tam sayılmaz. Squat uyarıları ayrı gösterilir.
- Görev Seç ekranına gerçek kamerada **20 şınav testini** açan kısayol eklendi.
- Sürüm kodu 13, sürüm adı 1.3.0 oldu.

## v1.2'den korunanlar
- Canlı kamera, poz noktaları/beyaz eklem çizgileri ve kameraya hizalı ViewPort dönüşümü, sayaç, sarı ilerleme çubuğu, duraklat/devam et.
- Sekiz ekranlık sarı/beyaz referans tasarım; özel vektör simgeler, alarmlar ve alarm düzenleme ekranı.
- Uyku kayıtları, horlama/öksürme/uykuda konuşma ses olayları için manuel etiketleme, kabus notu, yerel WAV dosyaları.
- Diğer alarm görevleri, tema seçenekleri, geçmiş ve diğer ayarlar. Hiçbir özellik bilinçli olarak silinmedi.

## Doğrulama sınırları
- Bağımsız saf Java mantık testleri çalıştırıldı.
- Android SDK ve çalışan bir telefon/emülatör bu ortamda bulunmadığı için APK/AAB **oluşturulmadı**; Android Gradle derlemesi ve gerçek kamera testi yapılmadı.
- Görselin gerçek Make uygulamasıyla piksel piksel eşleştiği iddia edilmez: bu, orijinal referans ekranlar ve aynı çözünürlükte gerçek cihaz ekran görüntüleriyle ayrıca test edilmelidir.
- Ses kayıt sistemi ses yükseldiğinde WAV klip oluşturur; otomatik olarak horlama/öksürüğü güvenilir biçimde sınıflandıran tıbbi model yoktur. Kullanıcı ses olaylarını dinleyip etiketleyebilir.
- Kamera poz algılama kalitesi açı, ışık ve tüm vücut görünürlüğüne bağlıdır.
