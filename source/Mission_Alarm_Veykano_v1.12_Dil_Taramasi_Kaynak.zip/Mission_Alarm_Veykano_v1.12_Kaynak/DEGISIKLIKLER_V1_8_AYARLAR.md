# WakeMission v1.8 – Ayarlar sadeleştirmesi

- Ayarlardan şu tanıtım/bilgi kartları kaldırıldı: Ücretsiz özellikler, Yeni kamera ve ses görevleri, Premium durumu.
- Ayarlar sayfasındaki Kişiselleştirme başlığı ile bu başlık altındaki yinelenen Görev Seç ve Uyku Günlüğü hızlı bağlantıları kaldırıldı.
- Tema ayarı, Uyku Kayıtları, izin kontrolü, dil, telefon uygunluğu, gizlilik ve Pro seçeneklerine erişim **korundu**.
- Alarm görevleri, kamera/ses özellikleri, uyku kaydı, Pro altyapısı ve geçmiş ekranları kaldırılmadı.
- Sürüm etiketi, versionCode=18 ve versionName=1.8.0 olarak güncellendi.
- Android SDK ve cihaz testi yapılamadığı için bu ZIP kurulabilir APK değildir.
