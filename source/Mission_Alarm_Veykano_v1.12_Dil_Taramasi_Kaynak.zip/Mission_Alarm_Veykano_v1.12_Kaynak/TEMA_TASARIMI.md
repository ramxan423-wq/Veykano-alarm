# WakeMission v0.5 — Tema kılavuzu

Kullanıcı onayı: bir önceki **temiz beyaz ve mavi** ekran düzeni; son mor/mavi geçişli düzen değil. Alt menü Wayk stilinden esinlenen fakat özgün kodla çizilen, ince **yarı saydam gri oval** kapsül olacak.

| Tema | Arka plan | Kart | Birincil | Metin |
|---|---|---|---|---|
| Modern Beyaz (varsayılan) | #F8FAFD | #FFFFFF | #2685FA | #111B33 |
| Klasik | #071C38 | #102C50 | #168CF6 | #F6F9FF |
| Neon | #090C19 | #141A2C | #12DAF8 | #F9FAFF |
| Uzay | #110D2D | #211A44 | #815AFD | #FAF7FF |

**Yol:** Ayarlar > Tema > tema kartı. Tema dokunur dokunmaz kaydedilir. Uygulamayı yeniden açınca kalır.

**Alt menü:** 5 sekme: Ana Sayfa, Görevler, İstatistikler, Başarılar, Ayarlar. Kaydırılabilir içerikten bağımsız, ekranın en altında, yaklaşık 70dp yüksekliğinde, 30dp köşeli, hafif gölgeli, saydam gri zemin.

**Teknik:** Java, tamamen cihaz içi ve ağ çağrısı olmadan; fotoğraf ve alarmların diğer işlevleri değiştirilmedi. API 26+. Tema kullanıcı bazlı yerel SharedPreferences ile tutulur.

**Sınırlama:** Kod seviyesinde kontrol yapılmıştır fakat Android SDK ve fiziksel cihaz olmadığından bu sürümde derleme ve görsel çalışma testi yapılamadı.
